import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { STATION_MAP, findTrack } from '../data/mockNetwork';
import { buildSegmentLookup, controlPointFor, sampleSegmentLookup } from '../utils/trackGeometry';

/**
 * Builds cumulative-arc-length geometry for a train's full route by
 * chaining together the *real* curved track segments it actually rides —
 * never a straight line between arbitrary path stations. Each leg is
 * looked up from mockNetwork's TRACKS via findTrack(); a route that
 * references a track that doesn't exist is a data error, not something
 * this hook silently papers over, so it's dropped with a console warning
 * rather than making the train cut across open space.
 */
function buildRouteGeometry(path) {
  const segments = [];
  let totalLength = 0;

  for (let i = 0; i < path.length - 1; i++) {
    const fromId = path[i];
    const toId = path[i + 1];
    const from = STATION_MAP[fromId];
    const to = STATION_MAP[toId];
    const track = findTrack(fromId, toId);

    if (!from || !to || !track) {
      // eslint-disable-next-line no-console
      console.warn(`useTrainSimulation: no track between ${fromId} and ${toId} — skipping leg`);
      continue;
    }

    // The track's curve control point is defined once, independent of
    // travel direction; buildSegmentLookup(from, control, to) below rides
    // it start-to-end for *this* train's direction, whether that matches
    // the track's own stored source->target or runs the opposite way.
    const control = controlPointFor(track, STATION_MAP[track.source], STATION_MAP[track.target]);
    const lookup = buildSegmentLookup(from, control, to);

    segments.push({
      fromId,
      toId,
      trackId: track.id,
      lookup,
      length: lookup.length,
      startDistance: totalLength,
    });
    totalLength += lookup.length;
  }

  return { segments, totalLength: totalLength || 1 };
}

function sampleRoute(geometry, distance) {
  const { segments, totalLength } = geometry;
  if (!segments.length) {
    return { x: 0, y: 0, angle: 0, edgeId: null, fromId: null, toId: null, segmentProgress: 0, segmentIndex: -1 };
  }
  let d = distance % totalLength;
  if (d < 0) d += totalLength;

  let index = segments.length - 1;
  let seg = segments[index];
  for (let i = 0; i < segments.length; i++) {
    if (d <= segments[i].startDistance + segments[i].length) {
      seg = segments[i];
      index = i;
      break;
    }
  }

  const localDistance = d - seg.startDistance;
  const { x, y, angle } = sampleSegmentLookup(seg.lookup, localDistance);
  return {
    x,
    y,
    angle,
    edgeId: seg.trackId,
    fromId: seg.fromId,
    toId: seg.toId,
    segmentProgress: Math.min(1, Math.max(0, localDistance / seg.length)),
    segmentIndex: index,
  };
}

/**
 * Drives continuous, on-track motion for a fleet of trains using
 * requestAnimationFrame. Pure UI simulation: no backend, no real
 * scheduling logic — just smooth, route-faithful position math for the
 * demo. `speedMultiplier` scales every train's px/s speed uniformly
 * (1x / 2x / 5x playback), `playing` pauses the clock entirely.
 */
export default function useTrainSimulation(trains, options = {}) {
  const { speedMultiplier = 1, playing = true } = options;

  const geometries = useMemo(() => {
    const map = {};
    trains.forEach((t) => {
      map[t.id] = buildRouteGeometry(t.path);
    });
    return map;
  }, [trains]);

  const elapsedRef = useRef(0);
  const lastFrameRef = useRef(null);
  const playingRef = useRef(playing);
  const speedRef = useRef(speedMultiplier);
  const rafRef = useRef(null);
  const [, forceTick] = useState(0);

  useEffect(() => {
    playingRef.current = playing;
  }, [playing]);

  useEffect(() => {
    speedRef.current = speedMultiplier;
  }, [speedMultiplier]);

  useEffect(() => {
    function frame(now) {
      if (lastFrameRef.current == null) lastFrameRef.current = now;
      const dt = now - lastFrameRef.current;
      lastFrameRef.current = now;
      if (playingRef.current) {
        elapsedRef.current += (dt / 1000) * speedRef.current;
        forceTick((v) => (v + 1) % 1_000_000);
      }
      rafRef.current = requestAnimationFrame(frame);
    }
    rafRef.current = requestAnimationFrame(frame);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      lastFrameRef.current = null;
    };
  }, []);

  const seekTo = useCallback((seconds) => {
    elapsedRef.current = seconds;
  }, []);

  const reset = useCallback(() => {
    elapsedRef.current = 0;
  }, []);

  const positions = useMemo(() => {
    const out = {};
    trains.forEach((train, index) => {
      const geometry = geometries[train.id];
      // Small per-train phase offset (based on index) keeps the initial
      // formation visually staggered rather than every train starting at
      // the same point along its own route.
      const distance = elapsedRef.current * train.speed + index * 47;
      out[train.id] = sampleRoute(geometry, distance);
    });
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trains, geometries, elapsedRef.current]);

  return {
    positions,
    elapsedSeconds: elapsedRef.current,
    seekTo,
    reset,
  };
}
