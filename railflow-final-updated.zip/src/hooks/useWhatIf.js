// hooks/useWhatIf.js
//
// PHASE 2 CHUNK 16 (FINAL INTEGRATION) — the data-fetching half for the
// What-If panel, added because WhatIfPanel.jsx was still mock-only (it
// mutated local component state to fake a scenario and never called the
// backend). Mirrors useOptimization.js's/useSimulationData.js's existing
// fetch/loading/error contract exactly, so this is a same-shape sibling
// of an already-reviewed hook, not a new pattern:
//
//   User clicks "Simulate Scenario" -> POST /api/simulation/what-if ->
//   useWhatIf -> WhatIfPanel.jsx (presentation only)

import { useCallback, useEffect, useRef, useState } from 'react';

const DEFAULT_API_BASE_URL = 'http://localhost:4000';

function resolveApiBaseUrl() {
  try {
    const envUrl = import.meta.env?.VITE_API_BASE_URL;
    if (envUrl) return envUrl;
  } catch {
    // import.meta.env not available in this build/runtime — fall through
    // to the default rather than failing.
  }
  return DEFAULT_API_BASE_URL;
}

const WHATIF_ENDPOINT = `${resolveApiBaseUrl()}/api/simulation/what-if`;

/**
 * @returns {{
 *   result: null | object,
 *   loading: boolean,
 *   error: Error | null,
 *   runWhatIf: (intervention: object) => Promise<object>,
 *   reset: () => void,
 * }}
 */
export default function useWhatIf() {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const runWhatIf = useCallback(async (intervention) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(WHATIF_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(intervention || {}),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || `POST /api/simulation/what-if responded with status ${res.status}`);
      }

      const data = await res.json();
      if (mountedRef.current) {
        setResult(data);
      }
      return data;
    } catch (err) {
      const normalized = err instanceof Error ? err : new Error(String(err));
      // Backend unreachable / not running / bad response. Log for
      // debugging but never throw out of the hook — the caller (the
      // panel) is expected to render `error` instead of crashing.
      // eslint-disable-next-line no-console
      console.warn('useWhatIf: could not reach POST /api/simulation/what-if', normalized);
      if (mountedRef.current) {
        setError(normalized);
      }
      throw normalized;
    } finally {
      if (mountedRef.current) setLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setResult(null);
    setError(null);
  }, []);

  return { result, loading, error, runWhatIf, reset };
}
