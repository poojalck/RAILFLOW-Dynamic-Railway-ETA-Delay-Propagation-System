// hooks/useSimulationData.js
//
// PHASE 2 CHUNK 10 (FRONTEND: REAL TRAIN DATA) — the data-fetching half
// of the architecture:
//
//   Backend Engine -> GET /api/simulation -> useSimulationData -> ...
//
// This hook is purely a data source: it fetches the backend's complete
// current engine simulation result once on mount (and, optionally, on a
// polling interval) and exposes it alongside loading/error state. It has
// no opinion about visual position/animation (that remains
// useTrainSimulation.js's separate job — see that file) and no opinion
// about how the raw `trains`/`etas` should be merged for display (see
// utils/simulationMapping.js for that).
//
// Fails gracefully: if the backend is unreachable, slow to start, or
// returns a bad response, this hook never throws — it surfaces `error`
// and leaves `simulation` at its last-known value (or `null` if it never
// loaded), so callers can fall back to their own default/mock data
// instead of the UI crashing.

import { useCallback, useEffect, useRef, useState } from 'react';

// Backend base URL. Overridable via VITE_API_BASE_URL (e.g. for a
// deployed backend); defaults to the local dev server address the Phase
// 2 backend listens on (see backend/server.js).
const DEFAULT_API_BASE_URL = 'http://localhost:4000';

function resolveApiBaseUrl() {
  try {
    const envUrl = import.meta.env?.VITE_API_BASE_URL;
    if (envUrl) return envUrl;
  } catch {
    // import.meta.env not available in this build/runtime — fall through
    // to the default rather than failing.
  }
  return DEFAULT_API_BASE_URL;
}

const SIMULATION_ENDPOINT = `${resolveApiBaseUrl()}/api/simulation`;

/**
 * @param {{pollIntervalMs?: number, enabled?: boolean}} [options]
 *   `pollIntervalMs` - when > 0, re-fetches on that interval (default:
 *   0, i.e. fetch once on mount only). `enabled` - set false to skip
 *   fetching entirely (default: true).
 * @returns {{
 *   simulation: null | object,
 *   loading: boolean,
 *   error: Error | null,
 *   refresh: () => void,
 * }}
 */
export default function useSimulationData(options = {}) {
  const { pollIntervalMs = 0, enabled = true } = options;

  const [simulation, setSimulation] = useState(null);
  const [loading, setLoading] = useState(enabled);
  const [error, setError] = useState(null);
  const mountedRef = useRef(true);

  const fetchSimulation = useCallback(async () => {
    if (!enabled) return;
    setLoading(true);
    try {
      const res = await fetch(SIMULATION_ENDPOINT);
      if (!res.ok) {
        throw new Error(`GET /api/simulation responded with status ${res.status}`);
      }
      const data = await res.json();
      if (!mountedRef.current) return;
      setSimulation(data);
      setError(null);
    } catch (err) {
      // Backend unreachable / not running / bad response. Log for
      // debugging but never throw — callers are expected to fall back
      // to their own default data when `error` is set.
      // eslint-disable-next-line no-console
      console.warn('useSimulationData: could not fetch /api/simulation', err);
      if (mountedRef.current) {
        setError(err instanceof Error ? err : new Error(String(err)));
      }
    } finally {
      if (mountedRef.current) setLoading(false);
    }
  }, [enabled]);

  useEffect(() => {
    mountedRef.current = true;
    fetchSimulation();

    let intervalId = null;
    if (pollIntervalMs > 0) {
      intervalId = setInterval(fetchSimulation, pollIntervalMs);
    }

    return () => {
      mountedRef.current = false;
      if (intervalId) clearInterval(intervalId);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pollIntervalMs, enabled]);

  return { simulation, loading, error, refresh: fetchSimulation };
}
