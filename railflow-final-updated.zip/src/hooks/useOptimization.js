// hooks/useOptimization.js
//
// PHASE 2 CHUNK 15 (OPTIMIZATION FRONTEND UI) — the data-fetching half
// for the Optimize panel:
//
//   User clicks "Run Optimization" -> POST /api/simulation/optimize ->
//   useOptimization -> OptimizePanel.jsx (presentation only)
//
// Mirrors useSimulationData.js's existing fetch/loading/error pattern
// (same base-URL resolution, same "never throw out of the hook, surface
// `error` instead" contract) so this reads as part of the existing
// architecture rather than a new one. Unlike useSimulationData, this is
// POST-triggered by the user, not fetched automatically on mount — the
// optimizer does real work (What-If simulation per candidate) and should
// only run when asked.

import { useCallback, useEffect, useRef, useState } from 'react';

const DEFAULT_API_BASE_URL = 'http://localhost:4000';

function resolveApiBaseUrl() {
  try {
    const envUrl = import.meta.env?.VITE_API_BASE_URL;
    if (envUrl) return envUrl;
  } catch {
    // import.meta.env not available in this build/runtime — fall through
    // to the default rather than failing.
  }
  return DEFAULT_API_BASE_URL;
}

const OPTIMIZE_ENDPOINT = `${resolveApiBaseUrl()}/api/simulation/optimize`;

/**
 * @returns {{
 *   result: null | object,
 *   loading: boolean,
 *   error: Error | null,
 *   runOptimization: (candidates?: Array<object>) => Promise<object>,
 *   reset: () => void,
 * }}
 */
export default function useOptimization() {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const runOptimization = useCallback(async (candidates) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(OPTIMIZE_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(candidates && candidates.length > 0 ? { candidates } : {}),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || `POST /api/simulation/optimize responded with status ${res.status}`);
      }

      const data = await res.json();
      if (mountedRef.current) {
        setResult(data);
      }
      return data;
    } catch (err) {
      const normalized = err instanceof Error ? err : new Error(String(err));
      // Backend unreachable / not running / bad response. Log for
      // debugging but never throw out of the hook — the caller (the
      // panel) is expected to render `error` instead of crashing.
      // eslint-disable-next-line no-console
      console.warn('useOptimization: could not reach POST /api/simulation/optimize', normalized);
      if (mountedRef.current) {
        setError(normalized);
      }
      throw normalized;
    } finally {
      if (mountedRef.current) setLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setResult(null);
    setError(null);
  }, []);

  return { result, loading, error, runOptimization, reset };
}
