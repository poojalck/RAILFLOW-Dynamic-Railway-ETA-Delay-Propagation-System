import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Header from './components/Header';
import TrainMonitor from './components/TrainMonitor';
import RailwayNetwork from './components/RailwayNetwork';
import AlertsPanel from './components/AlertsPanel';
import ConflictAlert from './components/ConflictAlert';
import SelectedTrainPanel from './components/SelectedTrainPanel';
import NetworkStats from './components/NetworkStats';
import SimulationControls from './components/SimulationControls';
import WhatIfPanel from './components/WhatIfPanel';
import OptimizePanel from './components/OptimizePanel';
import DelayRipple from './components/DelayRipple';
import { INITIAL_TRAINS } from './data/mockTrains';
import { INITIAL_ALERTS, DEMO_STAGES, RIPPLE_CHAIN } from './data/mockAlerts';
import { addMinutesToTimeString } from './utils/time';
import useSimulationData from './hooks/useSimulationData';
import { mapSimulationToDisplayTrains } from './utils/simulationMapping';

export default function App() {
  // Backend Engine -> GET /api/simulation -> useSimulationData -> (below)
  // -> train display/dashboard -> existing visual animation
  // (useTrainSimulation, inside RailwayNetwork). The animation layer is
  // untouched: it still just receives a plain `trains` array with
  // `id`/`path`/`speed` and drives its own on-track position math.
  //
  // If the backend is unavailable, `simulation` simply stays `null` and
  // the UI keeps using the local mock fleet below — no crash, no blank
  // screen.
  const { simulation, error: simulationError } = useSimulationData();

  // The "real" baseline fleet: engine-backed once /api/simulation has
  // loaded, otherwise the original mock fleet. Demo Scenario / What-If
  // still mutate `trains` locally from here exactly as before — this
  // only changes *where the starting data comes from*, not the existing
  // local-state interaction model.
  const backendTrains = useMemo(() => mapSimulationToDisplayTrains(simulation), [simulation]);
  // Real backend conflicts, straight from GET /api/simulation's
  // `conflicts` array (engine/conflictDetector.js) — the sole source of
  // truth for ConflictAlert below. No local invention/mock fallback: if
  // the backend hasn't loaded yet or reports none, the list is simply
  // empty and ConflictAlert renders its own "no conflicts" state.
  const realConflicts = simulation?.conflicts || [];
  const baselineTrains = backendTrains || INITIAL_TRAINS;
  const baselineTrainsRef = useRef(baselineTrains);
  useEffect(() => {
    baselineTrainsRef.current = baselineTrains;
  }, [baselineTrains]);

  const [trains, setTrains] = useState(INITIAL_TRAINS);

  // Once the real backend fleet arrives, adopt it as the displayed
  // fleet. Runs once per successful fetch (this hook fetches once on
  // mount by default), so it won't fight with in-progress Demo
  // Scenario / What-If mutations afterward.
  useEffect(() => {
    if (backendTrains) {
      setTrains(backendTrains);
    }
  }, [backendTrains]);
  // No train is selected by default — the map should open in its neutral
  // state, with every track in its normal color. Selection (and the blue
  // route highlight that comes with it) only happens on explicit click.
  const [selectedTrainId, setSelectedTrainId] = useState(null);
  const [selectedSegment, setSelectedSegment] = useState(null);
  const [alerts, setAlerts] = useState(INITIAL_ALERTS);
  const [playing, setPlaying] = useState(true);
  const [speedMultiplier, setSpeedMultiplier] = useState(1);
  const [activeMode, setActiveMode] = useState('live');
  const [conflictState, setConflictState] = useState({ junction: 'normal', platform: 'normal' });
  const [demoRunning, setDemoRunning] = useState(false);
  const [rippleStep, setRippleStep] = useState(-1);

  const timeoutsRef = useRef([]);

  const selectedTrain = useMemo(() => trains.find((t) => t.id === selectedTrainId) || null, [trains, selectedTrainId]);

  const handleSelectTrain = useCallback((id) => {
    setSelectedTrainId((prev) => (prev === id ? null : id));
    setSelectedSegment(null);
  }, []);

  const clearTimeouts = () => {
    timeoutsRef.current.forEach((id) => clearTimeout(id));
    timeoutsRef.current = [];
  };

  useEffect(() => clearTimeouts, []);

  const resetToBaseline = useCallback(() => {
    setTrains(baselineTrainsRef.current);
    setAlerts(INITIAL_ALERTS);
    setConflictState({ junction: 'normal', platform: 'normal' });
    setRippleStep(-1);
  }, []);

  const pushAlert = useCallback((alert) => {
    setAlerts((prev) => [{ id: `${alert.title}-${Date.now()}`, ...alert }, ...prev].slice(0, 6));
  }, []);

  const runDemoScenario = useCallback(() => {
    if (demoRunning) return;
    clearTimeouts();
    setDemoRunning(true);
    resetToBaseline();
    setActiveMode('live');

    DEMO_STAGES.forEach((stage) => {
      const t = setTimeout(() => {
        switch (stage.id) {
          case 2: {
            setTrains((prev) =>
              prev.map((tr) =>
                tr.id === '12601'
                  ? { ...tr, delay: 15, status: 'delayed', predictedETA: addMinutesToTimeString(tr.scheduledETA, 15) }
                  : tr
              )
            );
            pushAlert({ level: 'delay', title: 'Delay Risk', detail: 'Train 12601 +15 min expected' });
            break;
          }
          case 3: {
            setConflictState((prev) => ({ ...prev, junction: 'warning' }));
            pushAlert({ level: 'danger', title: 'Predicted Conflict', detail: 'Junction J1 in 3 min' });
            break;
          }
          case 4: {
            setTrains((prev) =>
              prev.map((tr) =>
                tr.id === '12602'
                  ? { ...tr, status: 'atRisk', delay: 9, predictedETA: addMinutesToTimeString(tr.scheduledETA, 9) }
                  : tr
              )
            );
            pushAlert({ level: 'delay', title: 'Delay Risk', detail: 'Train 12602 +9 min expected' });
            break;
          }
          case 5: {
            setConflictState((prev) => ({ ...prev, platform: 'warning' }));
            pushAlert({ level: 'warning', title: 'Platform Risk', detail: 'Platform P3 possible overlap' });
            break;
          }
          case 6: {
            setConflictState((prev) => ({ ...prev, junction: 'danger' }));
            setTrains((prev) =>
              prev.map((tr) => (tr.id === '16722' ? { ...tr, status: 'conflict', delay: Math.max(tr.delay, 6) } : tr))
            );
            pushAlert({ level: 'danger', title: 'Network Impact', detail: 'Cascading delay affecting 3 services' });
            break;
          }
          case 7: {
            setActiveMode('ripple');
            RIPPLE_CHAIN.forEach((_, idx) => {
              const rt = setTimeout(() => setRippleStep(idx), idx * 550);
              timeoutsRef.current.push(rt);
            });
            const finish = setTimeout(() => setDemoRunning(false), RIPPLE_CHAIN.length * 550 + 400);
            timeoutsRef.current.push(finish);
            break;
          }
          default:
            break;
        }
      }, stage.delayMs);
      timeoutsRef.current.push(t);
    });
  }, [demoRunning, pushAlert, resetToBaseline]);

  const stats = useMemo(() => {
    const networkDelay = trains.reduce((sum, t) => sum + t.delay, 0);
    const affectedTrains = trains.filter((t) => t.delay > 0).length;
    const predictedConflicts = (conflictState.junction !== 'normal' ? 1 : 0) + (conflictState.platform !== 'normal' ? 1 : 0);
    const networkHealth = Math.max(0, Math.min(100, 100 - affectedTrains * 3 - predictedConflicts * 9 - Math.min(networkDelay, 20)));
    return { networkDelay, affectedTrains, predictedConflicts, networkHealth };
  }, [trains, conflictState]);

  return (
    <div className="flex h-screen w-screen flex-col overflow-hidden bg-base-950 font-body text-ink">
      <Header backendConnected={!simulationError} />

      <div className="flex min-h-0 flex-1">
        <TrainMonitor trains={trains} selectedTrainId={selectedTrainId} onSelectTrain={handleSelectTrain} />

        <main className="flex min-w-0 flex-1 flex-col">
          <div className="relative min-h-0 flex-1">
            <RailwayNetwork
              trains={trains}
              selectedTrainId={selectedTrainId}
              onSelectTrain={handleSelectTrain}
              conflictState={conflictState}
              playing={playing}
              speedMultiplier={speedMultiplier}
              onSelectedTrainSegment={setSelectedSegment}
            />
          </div>

          <div className="shrink-0 border-t border-line bg-base-900/80">
            <NetworkStats stats={stats} />
            <SimulationControls
              playing={playing}
              onTogglePlay={() => setPlaying((v) => !v)}
              onReset={resetToBaseline}
              activeMode={activeMode}
              onModeChange={setActiveMode}
              onRunDemo={runDemoScenario}
              demoRunning={demoRunning}
              speedMultiplier={speedMultiplier}
              onSpeedChange={setSpeedMultiplier}
            />
            {activeMode === 'whatif' && <WhatIfPanel trains={trains} onClose={() => setActiveMode('live')} />}
            {activeMode === 'optimize' && <OptimizePanel onClose={() => setActiveMode('live')} />}
            {activeMode === 'ripple' && <DelayRipple chain={RIPPLE_CHAIN} activeStep={rippleStep} />}
          </div>
        </main>

        <aside className="flex w-[300px] shrink-0 flex-col border-l border-line bg-base-900/60">
          <AlertsPanel alerts={alerts} />
          <ConflictAlert conflicts={realConflicts} />
          <SelectedTrainPanel train={selectedTrain} currentSegment={selectedSegment} />
        </aside>
      </div>
    </div>
  );
}
