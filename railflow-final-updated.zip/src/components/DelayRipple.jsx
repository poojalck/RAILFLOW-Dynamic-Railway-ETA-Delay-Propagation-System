import React from 'react';
import { TrainFront, Radio, ArrowDown, Waves } from 'lucide-react';

const ICONS = { train: TrainFront, junction: Radio, platform: Radio };

export default function DelayRipple({ chain, activeStep }) {
  return (
    <div className="animate-fadeUp border-t border-line bg-base-900/95 px-5 py-4">
      <div className="mb-3 flex items-center gap-2">
        <Waves size={14} className="text-signal-delay" />
        <h3 className="text-[12px] font-semibold tracking-wide text-ink">DELAY RIPPLE PROPAGATION</h3>
        <span className="text-[10.5px] text-ink-faint">— cascading impact across the affected network path</span>
      </div>

      <div className="flex flex-col items-center gap-1 sm:flex-row sm:justify-center sm:gap-0">
        {chain.map((node, i) => {
          const Icon = ICONS[node.kind] || TrainFront;
          const isLit = i <= activeStep;
          return (
            <React.Fragment key={node.id}>
              <div
                className={`flex items-center gap-2 rounded-lg border px-3 py-2 transition-all duration-500 ${
                  isLit ? 'border-signal-delay/50 bg-signal-delay/10' : 'border-line bg-base-800/40 opacity-40'
                }`}
              >
                <Icon size={14} className={isLit ? 'text-signal-delay' : 'text-ink-faint'} />
                <span className={`text-[11.5px] font-medium ${isLit ? 'text-ink' : 'text-ink-faint'}`}>{node.label}</span>
              </div>
              {i < chain.length - 1 && (
                <div className="flex items-center justify-center px-1 py-1 sm:rotate-[-90deg]">
                  <ArrowDown
                    size={14}
                    className={`transition-colors duration-500 ${i < activeStep ? 'text-signal-delay' : 'text-ink-faint'}`}
                  />
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}
