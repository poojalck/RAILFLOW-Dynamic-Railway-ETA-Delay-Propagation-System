import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';

const centerHandleStyle = {
  opacity: 0,
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  pointerEvents: 'none',
};

function StationNode({ data }) {
  const { label, code, highlighted, dimmed } = data;

  return (
    <div
      className={`relative flex flex-col items-center transition-opacity duration-300 ${
        dimmed ? 'opacity-30' : 'opacity-100'
      }`}
    >
      <Handle type="target" position={Position.Top} style={centerHandleStyle} />
      <Handle type="source" position={Position.Top} style={centerHandleStyle} />

      {/* Small platform: a stub perpendicular to the track with a marker
          post, so a station reads as "a stop on the line" rather than a
          bare graph-node dot. */}
      <svg width="26" height="18" viewBox="0 0 26 18" style={{ overflow: 'visible' }}>
        <rect
          x="4"
          y="9"
          width="18"
          height="4"
          rx="1"
          fill={highlighted ? '#182740' : '#151C29'}
          stroke={highlighted ? '#4C8CFF' : '#2A3548'}
          strokeWidth="0.8"
        />
        <circle
          cx="13"
          cy="6"
          r="3.2"
          fill={highlighted ? '#4C8CFF' : '#182131'}
          stroke={highlighted ? '#4C8CFF' : '#2A3548'}
          strokeWidth="1.4"
        />
        {highlighted && <circle cx="13" cy="6" r="6" fill="#4C8CFF" opacity="0.18" />}
      </svg>

      <div
        className={`mt-1 rounded border px-2 py-1 text-center leading-none shadow-panel ${
          highlighted ? 'border-signal-active/40 bg-signal-active/10' : 'border-line bg-base-850/90'
        }`}
      >
        <div className={`font-mono text-[10px] font-semibold tracking-wide ${highlighted ? 'text-signal-active' : 'text-ink-muted'}`}>
          {code}
        </div>
        <div className="whitespace-nowrap text-[9.5px] text-ink-faint">{label}</div>
      </div>
    </div>
  );
}

export default memo(StationNode);
