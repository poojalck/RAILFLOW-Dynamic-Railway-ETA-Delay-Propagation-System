import React from 'react';
import { CircleDot, TriangleAlert, Clock } from 'lucide-react';
import { STATUS_META } from '../data/mockTrains';

const DOT_COLOR = {
  onTime: 'bg-signal-normal',
  delayed: 'bg-signal-delay',
  atRisk: 'bg-signal-warning',
  conflict: 'bg-signal-danger',
};

const TEXT_COLOR = {
  onTime: 'text-signal-normal',
  delayed: 'text-signal-delay',
  atRisk: 'text-signal-warning',
  conflict: 'text-signal-danger',
};

export default function TrainCard({ train, isSelected, onSelect }) {
  const meta = STATUS_META[train.status];

  return (
    <button
      onClick={() => onSelect(train.id)}
      className={`group w-full rounded-lg border px-3 py-2.5 text-left transition-all duration-200 ${
        isSelected
          ? 'border-signal-active/50 bg-signal-active/10 shadow-glow'
          : 'border-transparent bg-base-800/50 hover:border-line-bright hover:bg-base-800'
      }`}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className={`h-1.5 w-1.5 rounded-full ${DOT_COLOR[train.status]}`} />
          <span className="font-mono text-[13px] font-semibold tracking-wide text-ink">{train.id}</span>
        </div>
        <div className="flex items-center gap-1">
          {train.status === 'atRisk' && <TriangleAlert size={11} className="text-signal-warning" />}
          {train.status === 'conflict' && <TriangleAlert size={11} className="text-signal-danger" />}
          <span className={`text-[10px] font-semibold tracking-wider ${TEXT_COLOR[train.status]}`}>
            {meta.label}
          </span>
        </div>
      </div>

      <p className="mt-1.5 truncate text-[11.5px] text-ink-muted">{train.routeLabel}</p>

      <div className="mt-2 flex items-center justify-between">
        <div className="flex items-center gap-1 text-ink-faint">
          <Clock size={11} />
          <span className="font-mono text-[11px] tabular">{train.predictedETA}</span>
        </div>
        <span
          className={`rounded px-1.5 py-0.5 font-mono text-[10.5px] tabular ${
            train.delay > 0 ? `${TEXT_COLOR[train.status]} bg-base-900` : 'text-ink-faint'
          }`}
        >
          {train.delay > 0 ? `+${train.delay} min` : '+0 min'}
        </span>
      </div>
    </button>
  );
}
