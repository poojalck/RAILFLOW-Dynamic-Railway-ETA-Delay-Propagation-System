import React, { useEffect, useState } from 'react';
import { TrainFront, Radio, Wifi } from 'lucide-react';

function formatClock(date) {
  return date.toLocaleTimeString('en-IN', { hour12: false });
}

export default function Header({ backendConnected = true }) {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <header className="flex h-16 shrink-0 items-center justify-between border-b border-line bg-base-900/80 px-5 backdrop-blur-sm">
      <div className="flex items-center gap-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-signal-active/15 ring-1 ring-signal-active/30">
          <TrainFront size={18} className="text-signal-active" strokeWidth={2.25} />
        </div>
        <div className="flex flex-col leading-tight">
          <div className="flex items-baseline gap-2">
            <span className="font-display text-[15px] font-semibold tracking-wide text-ink">RAILFLOW</span>
            <span className="hidden text-[11px] text-ink-faint sm:inline">Railway Network Intelligence</span>
          </div>
          <span className="text-[11px] text-ink-muted">Vijayawada Junction &middot; Simplified Demo Network</span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 rounded-full border border-signal-normal/30 bg-signal-normal/10 px-2.5 py-1">
          <span className="relative flex h-1.5 w-1.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-signal-normal opacity-60" />
            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-signal-normal" />
          </span>
          <span className="text-[10px] font-semibold tracking-widest text-signal-normal">LIVE</span>
        </div>

        <div className="hidden items-center gap-1.5 text-ink-muted md:flex">
          <Radio size={13} />
          <span className="font-mono text-xs tabular">{formatClock(now)} IST</span>
        </div>

        <div className="flex items-center gap-1.5 rounded-md border border-line bg-base-800 px-2 py-1 text-ink-muted">
          <Wifi size={13} className={backendConnected ? 'text-signal-normal' : 'text-signal-warning'} />
          <span className="hidden text-[11px] sm:inline">
            {backendConnected ? 'Simulation link stable' : 'Backend offline \u2014 demo fallback'}
          </span>
        </div>
      </div>
    </header>
  );
}
