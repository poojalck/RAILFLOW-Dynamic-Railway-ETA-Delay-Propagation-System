import React from 'react';
import { AlertOctagon, TriangleAlert, CircleAlert, BellRing } from 'lucide-react';

const LEVEL_STYLE = {
  danger: { icon: AlertOctagon, color: 'text-signal-danger', bg: 'bg-signal-danger/10', border: 'border-signal-danger/30' },
  delay: { icon: TriangleAlert, color: 'text-signal-delay', bg: 'bg-signal-delay/10', border: 'border-signal-delay/30' },
  warning: { icon: CircleAlert, color: 'text-signal-warning', bg: 'bg-signal-warning/10', border: 'border-signal-warning/30' },
};

export default function AlertsPanel({ alerts }) {
  return (
    <div className="border-b border-line">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <BellRing size={14} className="text-ink-muted" />
          <h2 className="text-[12px] font-semibold tracking-wide text-ink">ACTIVE ALERTS</h2>
        </div>
        <span className="rounded-full bg-base-800 px-1.5 py-0.5 text-[10px] text-ink-faint">{alerts.length}</span>
      </div>

      <div className="max-h-[220px] space-y-1.5 overflow-y-auto px-3 pb-3">
        {alerts.length === 0 && (
          <p className="rounded-md border border-line-soft bg-base-800/40 px-3 py-4 text-center text-[11px] text-ink-faint">
            No active alerts. Network nominal.
          </p>
        )}
        {alerts.map((alert) => {
          const style = LEVEL_STYLE[alert.level] || LEVEL_STYLE.warning;
          const Icon = style.icon;
          return (
            <div
              key={alert.id}
              className={`animate-fadeUp rounded-md border ${style.border} ${style.bg} px-3 py-2`}
            >
              <div className="flex items-start gap-2">
                <Icon size={13} className={`mt-[1px] shrink-0 ${style.color}`} />
                <div className="min-w-0">
                  <p className={`text-[11.5px] font-semibold ${style.color}`}>{alert.title}</p>
                  <p className="truncate text-[11px] text-ink-muted">{alert.detail}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
