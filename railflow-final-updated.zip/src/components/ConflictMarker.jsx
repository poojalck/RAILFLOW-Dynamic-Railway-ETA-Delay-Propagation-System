import React from 'react';

/**
 * Pulsing ring overlay used to indicate a predicted/active conflict on a
 * junction, platform, or other shared resource. `level` is one of
 * 'normal' | 'warning' | 'danger'.
 */
export default function ConflictMarker({ level = 'normal' }) {
  if (level === 'normal') return null;

  const ringColor = level === 'danger' ? 'bg-signal-danger' : 'bg-signal-warning';

  return (
    <span className="pointer-events-none absolute inset-0 flex items-center justify-center">
      <span className={`absolute h-8 w-8 rounded-full ${ringColor} opacity-40 animate-pulseRing`} />
      <span
        className={`absolute h-8 w-8 rounded-full ${ringColor} opacity-30 animate-pulseRing`}
        style={{ animationDelay: '0.5s' }}
      />
    </span>
  );
}
