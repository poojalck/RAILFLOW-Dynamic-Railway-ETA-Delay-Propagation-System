import React, { useEffect, useMemo, useRef } from 'react';
import ReactFlow, { ReactFlowProvider, Background, Controls, useViewport, BackgroundVariant } from 'reactflow';
import { STATIONS, STATION_MAP, TRACKS } from '../data/mockNetwork';
import { controlPointFor } from '../utils/trackGeometry';
import StationNode from './StationNode';
import JunctionNode from './JunctionNode';
import TrackEdge from './TrackEdge';
import TrainMarker from './TrainMarker';
import useTrainSimulation from '../hooks/useTrainSimulation';

const nodeTypes = { station: StationNode, junction: JunctionNode };
const edgeTypes = { track: TrackEdge };

function unorderedMatch(a, b, c, d) {
  return (a === c && b === d) || (a === d && b === c);
}

function TrainOverlay({ trains, positions, selectedTrainId, onSelectTrain }) {
  const { x, y, zoom } = useViewport();
  return (
    <div
      className="pointer-events-none absolute left-0 top-0 h-full w-full overflow-hidden"
      style={{ zIndex: 5 }}
    >
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          transform: `translate(${x}px, ${y}px) scale(${zoom})`,
          transformOrigin: '0 0',
        }}
      >
        {trains.map((train) => {
          const pos = positions[train.id];
          if (!pos) return null;
          const isSelected = train.id === selectedTrainId;
          const isDimmed = selectedTrainId && !isSelected;
          return (
            <div key={train.id} className="pointer-events-auto">
              <TrainMarker
                x={pos.x}
                y={pos.y}
                angle={pos.angle}
                train={train}
                isSelected={isSelected}
                isDimmed={isDimmed}
                fromId={pos.fromId}
                toId={pos.toId}
                onClick={() => onSelectTrain(train.id)}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function RailwayNetwork({
  trains,
  selectedTrainId,
  onSelectTrain,
  conflictState,
  playing,
  speedMultiplier,
  onSelectedTrainSegment,
}) {
  const { positions } = useTrainSimulation(trains, { playing, speedMultiplier });

  const selectedTrain = useMemo(() => trains.find((t) => t.id === selectedTrainId), [trains, selectedTrainId]);

  const lastSegmentRef = useRef(null);
  useEffect(() => {
    if (!selectedTrain) {
      lastSegmentRef.current = null;
      return;
    }
    const pos = positions[selectedTrain.id];
    if (!pos) return;
    const key = `${pos.fromId}-${pos.toId}`;
    if (key !== lastSegmentRef.current) {
      lastSegmentRef.current = key;
      onSelectedTrainSegment?.({ fromId: pos.fromId, toId: pos.toId });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedTrain?.id, positions[selectedTrain?.id]?.fromId, positions[selectedTrain?.id]?.toId]);

  const pathPairs = useMemo(() => {
    if (!selectedTrain) return [];
    const pairs = [];
    for (let i = 0; i < selectedTrain.path.length - 1; i++) {
      pairs.push([selectedTrain.path[i], selectedTrain.path[i + 1]]);
    }
    return pairs;
  }, [selectedTrain]);

  const currentSegmentIndex = useMemo(() => {
    if (!selectedTrain) return -1;
    const pos = positions[selectedTrain.id];
    if (!pos) return -1;
    return pathPairs.findIndex(([a, b]) => unorderedMatch(a, b, pos.fromId, pos.toId));
  }, [selectedTrain, positions, pathPairs]);

  const highlightedStationIds = useMemo(() => new Set(selectedTrain ? selectedTrain.path : []), [selectedTrain]);

  const nodes = useMemo(
    () =>
      STATIONS.map((s) => ({
        id: s.id,
        type: s.kind === 'junction' ? 'junction' : 'station',
        position: { x: s.x, y: s.y },
        draggable: false,
        selectable: false,
        data: {
          label: s.name,
          code: s.short,
          platforms: s.platforms,
          highlighted: highlightedStationIds.has(s.id),
          dimmed: selectedTrainId ? !highlightedStationIds.has(s.id) : false,
          conflictLevel: s.kind === 'junction' ? conflictState.junction : 'normal',
        },
      })),
    [highlightedStationIds, selectedTrainId, conflictState.junction]
  );

  const edges = useMemo(
    () =>
      TRACKS.map((t) => {
        const pairIndex = pathPairs.findIndex(([a, b]) => unorderedMatch(a, b, t.source, t.target));
        // Highlighting is opt-in only: a track lights up blue if and only
        // if it's part of the *currently selected* train's route. With no
        // selection, pathPairs is empty, pairIndex is always -1, and every
        // track renders in its normal neutral color.
        const isOnRoute = Boolean(selectedTrainId) && pairIndex !== -1;
        const isPassed = isOnRoute && currentSegmentIndex !== -1 && pairIndex < currentSegmentIndex;
        const touchesVJA = t.source === 'VJA' || t.target === 'VJA';
        return {
          id: t.id,
          source: t.source,
          target: t.target,
          type: 'track',
          selectable: false,
          data: {
            kind: t.kind,
            control: controlPointFor(t, STATION_MAP[t.source], STATION_MAP[t.target]),
            highlighted: isOnRoute && !isPassed,
            passed: isPassed,
            dimmed: selectedTrainId ? !isOnRoute : false,
            conflictPulse: touchesVJA && conflictState.junction !== 'normal',
          },
        };
      }),
    [pathPairs, currentSegmentIndex, selectedTrainId, conflictState.junction]
  );

  return (
    <ReactFlowProvider>
      <div className="relative h-full w-full">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          edgeTypes={edgeTypes}
          fitView
          fitViewOptions={{ padding: 0.25 }}
          minZoom={0.4}
          maxZoom={2}
          proOptions={{ hideAttribution: true }}
          nodesDraggable={false}
          nodesConnectable={false}
          panOnScroll
        >
          <Background variant={BackgroundVariant.Dots} gap={28} size={1} color="#161D29" />
          <Controls showInteractive={false} position="bottom-right" />
        </ReactFlow>
        <TrainOverlay trains={trains} positions={positions} selectedTrainId={selectedTrainId} onSelectTrain={onSelectTrain} />
      </div>
    </ReactFlowProvider>
  );
}
