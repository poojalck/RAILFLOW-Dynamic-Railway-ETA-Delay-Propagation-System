import React, { useEffect, useRef, useState } from 'react';
import { Gauge, TrainFront, AlertTriangle, HeartPulse } from 'lucide-react';

function useAnimatedNumber(target, duration = 500) {
  const [value, setValue] = useState(target);
  const fromRef = useRef(target);
  const startRef = useRef(null);

  useEffect(() => {
    fromRef.current = value;
    startRef.current = null;
    let raf;
    function step(ts) {
      if (startRef.current === null) startRef.current = ts;
      const progress = Math.min(1, (ts - startRef.current) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(fromRef.current + (target - fromRef.current) * eased);
      if (progress < 1) raf = requestAnimationFrame(step);
    }
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target, duration]);

  return value;
}

function Metric({ icon: Icon, label, value, suffix, colorClass }) {
  const animated = useAnimatedNumber(value);
  const display = Number.isInteger(value) ? Math.round(animated) : animated.toFixed(0);

  return (
    <div className="flex items-center gap-3 px-4 py-2.5">
      <div className={`flex h-8 w-8 items-center justify-center rounded-md bg-base-800 ${colorClass}`}>
        <Icon size={14} />
      </div>
      <div className="leading-tight">
        <p className="text-[9.5px] font-medium tracking-wider text-ink-faint">{label}</p>
        <p className="font-mono text-[16px] font-semibold tabular text-ink">
          {display}
          {suffix}
        </p>
      </div>
    </div>
  );
}

export default function NetworkStats({ stats }) {
  return (
    <div className="flex divide-x divide-line">
      <Metric icon={Gauge} label="NETWORK DELAY" value={stats.networkDelay} suffix=" min" colorClass="text-signal-delay" />
      <Metric icon={TrainFront} label="AFFECTED TRAINS" value={stats.affectedTrains} suffix="" colorClass="text-signal-warning" />
      <Metric icon={AlertTriangle} label="PREDICTED CONFLICTS" value={stats.predictedConflicts} suffix="" colorClass="text-signal-danger" />
      <Metric icon={HeartPulse} label="NETWORK HEALTH" value={stats.networkHealth} suffix="%" colorClass="text-signal-normal" />
    </div>
  );
}
