import React from 'react';
import { Play, Pause, RotateCcw, Sparkles } from 'lucide-react';

const MODES = [
  { id: 'live', label: 'LIVE MODE' },
  { id: 'ripple', label: 'DELAY RIPPLE' },
  { id: 'whatif', label: 'WHAT-IF' },
  { id: 'optimize', label: 'OPTIMIZE' },
];

const SPEEDS = [1, 2, 5];

export default function SimulationControls({
  playing,
  onTogglePlay,
  onReset,
  activeMode,
  onModeChange,
  onRunDemo,
  demoRunning,
  speedMultiplier = 1,
  onSpeedChange,
}) {
  return (
    <div className="flex items-center justify-between px-4 py-2.5">
      <div className="flex items-center gap-1.5">
        <button
          onClick={onTogglePlay}
          className="flex h-8 w-8 items-center justify-center rounded-md border border-line bg-base-800 text-ink transition-colors hover:border-signal-active/40 hover:text-signal-active"
          title={playing ? 'Pause simulation' : 'Start simulation'}
        >
          {playing ? <Pause size={14} /> : <Play size={14} />}
        </button>
        <button
          onClick={onReset}
          className="flex h-8 w-8 items-center justify-center rounded-md border border-line bg-base-800 text-ink-muted transition-colors hover:border-line-bright hover:text-ink"
          title="Reset simulation"
        >
          <RotateCcw size={13} />
        </button>
        {onSpeedChange && (
          <div className="ml-1 flex items-center rounded-md border border-line bg-base-800/60 p-0.5">
            {SPEEDS.map((s) => (
              <button
                key={s}
                onClick={() => onSpeedChange(s)}
                className={`rounded px-2 py-1 font-mono text-[10.5px] font-semibold tabular transition-colors ${
                  speedMultiplier === s ? 'bg-signal-active/15 text-signal-active' : 'text-ink-faint hover:text-ink-muted'
                }`}
                title={`${s}x speed`}
              >
                {s}x
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="flex items-center rounded-lg border border-line bg-base-800/60 p-1">
        {MODES.map((mode) => (
          <button
            key={mode.id}
            onClick={() => onModeChange(mode.id)}
            className={`rounded-md px-3 py-1.5 text-[10.5px] font-semibold tracking-wide transition-colors ${
              activeMode === mode.id ? 'bg-signal-active/15 text-signal-active shadow-glow' : 'text-ink-faint hover:text-ink-muted'
            }`}
          >
            {mode.label}
          </button>
        ))}
      </div>

      <button
        onClick={onRunDemo}
        disabled={demoRunning}
        className="flex items-center gap-1.5 rounded-md border border-signal-delay/40 bg-signal-delay/10 px-3 py-1.5 text-[11px] font-semibold text-signal-delay transition-colors hover:bg-signal-delay/20 disabled:cursor-not-allowed disabled:opacity-50"
      >
        <Sparkles size={13} />
        {demoRunning ? 'RUNNING…' : 'DEMO SCENARIO'}
      </button>
    </div>
  );
}
