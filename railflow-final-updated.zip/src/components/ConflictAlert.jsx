import React from 'react';
import { AlertOctagon, TriangleAlert, Radio } from 'lucide-react';

// PHASE 2 CHUNK 11 (REAL CONFLICT VISUALIZATION) —
//
//   GET /api/simulation -> conflicts -> ConflictAlert (this component)
//
// Pure presentation: renders whatever conflict records the backend's
// engine (engine/conflictDetector.js) actually produced. It has no
// opinion about *which* resources or trains can conflict — it only reads
// the fields conflictDetector.js documents on each record (resourceId,
// trainIds, startTime, endTime, severity, reason) and never assumes a
// specific id exists. If `conflicts` is empty, that's a legitimate
// "network nominal" state, not something this component tries to work
// around.
//
// Styling deliberately mirrors AlertsPanel.jsx (same border/bg/color
// conventions, same rounded-md card shape, same fadeUp entrance) so this
// reads as part of the existing dashboard rather than a new design.

const SEVERITY_STYLE = {
  capacity: {
    icon: AlertOctagon,
    color: 'text-signal-danger',
    bg: 'bg-signal-danger/10',
    border: 'border-signal-danger/30',
    label: 'CAPACITY',
  },
  headway: {
    icon: TriangleAlert,
    color: 'text-signal-warning',
    bg: 'bg-signal-warning/10',
    border: 'border-signal-warning/30',
    label: 'HEADWAY',
  },
};

function styleFor(severity) {
  return SEVERITY_STYLE[severity] || SEVERITY_STYLE.headway;
}

export default function ConflictAlert({ conflicts = [] }) {
  return (
    <div className="border-b border-line">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <Radio size={14} className="text-ink-muted" />
          <h2 className="text-[12px] font-semibold tracking-wide text-ink">RESOURCE CONFLICTS</h2>
        </div>
        <span className="rounded-full bg-base-800 px-1.5 py-0.5 text-[10px] text-ink-faint">{conflicts.length}</span>
      </div>

      <div className="max-h-[220px] space-y-1.5 overflow-y-auto px-3 pb-3">
        {conflicts.length === 0 && (
          <p className="rounded-md border border-line-soft bg-base-800/40 px-3 py-4 text-center text-[11px] text-ink-faint">
            No resource conflicts. Network nominal.
          </p>
        )}
        {conflicts.map((conflict) => {
          const style = styleFor(conflict.severity);
          const Icon = style.icon;
          const key = `${conflict.resourceId}-${(conflict.trainIds || []).join('-')}-${conflict.severity}`;
          return (
            <div key={key} className={`animate-fadeUp rounded-md border ${style.border} ${style.bg} px-3 py-2`}>
              <div className="flex items-start gap-2">
                <Icon size={13} className={`mt-[1px] shrink-0 ${style.color}`} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className={`text-[11.5px] font-semibold ${style.color}`}>{conflict.resourceId}</p>
                    <span className={`shrink-0 text-[9.5px] font-semibold tracking-wide ${style.color}`}>
                      {style.label}
                    </span>
                  </div>
                  <p className="truncate text-[11px] text-ink-muted">
                    Trains {(conflict.trainIds || []).join(' & ')}
                  </p>
                  <p className="truncate text-[10.5px] text-ink-faint">
                    {conflict.startTime}–{conflict.endTime}
                  </p>
                  <p className="mt-0.5 text-[10.5px] leading-snug text-ink-faint">{conflict.reason}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
