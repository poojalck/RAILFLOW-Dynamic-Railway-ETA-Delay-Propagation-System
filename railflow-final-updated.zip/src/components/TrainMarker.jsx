import React, { useState } from 'react';
import { TriangleAlert } from 'lucide-react';
import { STATION_MAP } from '../data/mockNetwork';
import { STATUS_META } from '../data/mockTrains';

const BODY_COLOR = {
  onTime: '#2FD584',
  delayed: '#FF9A4D',
  atRisk: '#F0C043',
  conflict: '#F1454F',
};

const DIM_BODY = {
  onTime: '#1E9C61',
  delayed: '#CC7A38',
  atRisk: '#BD9433',
  conflict: '#C23640',
};

/**
 * Unmistakably-a-train marker: a locomotive followed by two short coaches,
 * rendered as a single SVG unit that rotates as one rigid body to face the
 * direction of travel. Positioned absolutely by the parent overlay at
 * (x, y) in flow-space coordinates; `angle` (degrees, atan2 convention)
 * orients the whole assembly along the current track segment.
 */
export default function TrainMarker({ x, y, angle, train, isSelected, isDimmed, fromId, toId, onClick }) {
  const [hovered, setHovered] = useState(false);
  const color = BODY_COLOR[train.status] || BODY_COLOR.onTime;
  const dimColor = DIM_BODY[train.status] || DIM_BODY.onTime;
  const showConflict = train.status === 'conflict';
  const meta = STATUS_META[train.status];

  // Flip the whole assembly when travelling "backwards" (into the left
  // half-plane) so the locomotive nose always leads, instead of the coach
  // silhouette getting mirrored oddly by a > 90deg / < -90deg rotation.
  const facingLeft = angle > 90 || angle < -90;
  const bodyRotation = facingLeft ? angle - 180 : angle;

  const scale = isSelected ? 1.28 : 1;
  const currentName = fromId ? STATION_MAP[fromId]?.name : undefined;
  const nextName = toId ? STATION_MAP[toId]?.name : undefined;

  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="absolute cursor-pointer select-none"
      style={{
        left: x,
        top: y,
        transform: 'translate(-50%, -50%)',
        opacity: isDimmed ? 0.25 : 1,
        transition: 'opacity 300ms ease',
        zIndex: isSelected ? 30 : hovered ? 25 : 10,
      }}
    >
      {/* Conflict halo — pulses around the train, never recolors the body */}
      {showConflict && (
        <span className="pointer-events-none absolute left-1/2 top-1/2 h-9 w-9 -translate-x-1/2 -translate-y-1/2 rounded-full bg-signal-danger/40 animate-pulseRing" />
      )}
      {isSelected && (
        <span className="pointer-events-none absolute left-1/2 top-1/2 h-8 w-8 -translate-x-1/2 -translate-y-1/2 rounded-full bg-signal-active/20 blur-[3px]" />
      )}

      <div className="flex flex-col items-center">
        {/* Label: id + delay badge, stays upright, moves with the train */}
        <div className="mb-[3px] flex items-center gap-1">
          <span
            className={`rounded px-1 font-mono text-[9px] font-semibold tabular ${
              isSelected ? 'bg-signal-active text-base-950' : 'bg-base-900/85 text-ink-muted'
            }`}
          >
            {train.id}
          </span>
          {train.delay > 0 && (
            <span
              className="rounded px-1 py-[1px] font-mono text-[8.5px] font-semibold tabular shadow"
              style={{ backgroundColor: `${color}22`, color, border: `1px solid ${color}55` }}
            >
              +{train.delay}m
            </span>
          )}
        </div>

        {/* The train itself: one rigid rotating SVG unit */}
        <div
          style={{
            transform: `rotate(${bodyRotation}deg) scale(${scale})`,
            transformOrigin: 'center center',
            transition: 'transform 120ms linear',
            filter: isSelected
              ? 'drop-shadow(0 0 5px rgba(76,140,255,0.55)) drop-shadow(0 3px 6px rgba(0,0,0,0.6))'
              : 'drop-shadow(0 2px 5px rgba(0,0,0,0.55))',
          }}
        >
          <svg width="40" height="16" viewBox="0 0 40 16" style={{ overflow: 'visible' }}>
            <defs>
              <linearGradient id={`trainBody-${train.id}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity="1" />
                <stop offset="100%" stopColor={dimColor} stopOpacity="1" />
              </linearGradient>
            </defs>

            {/* Selection outline, drawn behind everything, follows body shape */}
            {isSelected && (
              <rect x="0.5" y="1.5" width="38" height="13" rx="3" fill="none" stroke="#4C8CFF" strokeWidth="1.4" opacity="0.85" />
            )}

            {/* Coach 2 (rearmost) */}
            <rect x="1" y="4" width="9.5" height="8.5" rx="1.4" fill={`url(#trainBody-${train.id})`} stroke="#080B10" strokeWidth="0.5" />
            <rect x="2.4" y="6" width="2.6" height="2.6" rx="0.5" fill="#0B0F16" opacity="0.75" />
            <rect x="6.4" y="6" width="2.6" height="2.6" rx="0.5" fill="#0B0F16" opacity="0.75" />
            <rect x="1" y="12" width="9.5" height="1" fill="#080B10" opacity="0.5" />

            {/* Inter-coach coupler gap */}
            <rect x="10.5" y="7.5" width="1.4" height="1.8" fill="#080B10" opacity="0.6" />

            {/* Coach 1 */}
            <rect x="12" y="3.6" width="10.5" height="9" rx="1.4" fill={`url(#trainBody-${train.id})`} stroke="#080B10" strokeWidth="0.5" />
            <rect x="13.6" y="5.6" width="2.8" height="2.8" rx="0.5" fill="#0B0F16" opacity="0.75" />
            <rect x="17.8" y="5.6" width="2.8" height="2.8" rx="0.5" fill="#0B0F16" opacity="0.75" />
            <rect x="12" y="12.4" width="10.5" height="1" fill="#080B10" opacity="0.5" />

            {/* Coupler */}
            <rect x="22.5" y="7.2" width="1.4" height="1.8" fill="#080B10" opacity="0.6" />

            {/* Locomotive body */}
            <path
              d="M24 2.6 H33.4 C35 2.6 36.2 3.4 37.2 4.8 L39.2 7.6 C39.7 8.3 39.7 9.4 39.1 10 L37.5 11.7 C36.5 12.7 35.2 13.2 33.8 13.2 H24 C23.2 13.2 22.6 12.6 22.6 11.8 V4 C22.6 3.2 23.2 2.6 24 2.6 Z"
              fill={`url(#trainBody-${train.id})`}
              stroke="#080B10"
              strokeWidth="0.6"
            />
            {/* Cab windshield (leading edge) */}
            <path d="M35.4 5 L37.6 7.6 L35.4 10.3 C35 10.7 34.4 10.9 33.9 10.9 H32.5 V5 H33.9 C34.4 5 35 5.2 35.4 5 Z" fill="#0B0F16" opacity="0.8" />
            {/* Body window band */}
            <rect x="25" y="5.2" width="6.6" height="2.4" rx="0.5" fill="#0B0F16" opacity="0.7" />
            {/* Headlight */}
            <circle cx="38.3" cy="7.8" r="1.05" fill="#FFE9B8" opacity="0.95" />
            <circle cx="38.3" cy="7.8" r="2.1" fill="#FFE9B8" opacity="0.22" />
            {/* Undercarriage strip along whole train */}
            <rect x="1" y="13.1" width="38.4" height="0.9" rx="0.45" fill="#080B10" opacity="0.55" />
          </svg>
        </div>

        {showConflict && (
          <div className="pointer-events-none absolute" style={{ top: -14, left: '50%', transform: 'translateX(-50%)' }}>
            <TriangleAlert size={11} className="text-signal-danger" strokeWidth={2.5} />
          </div>
        )}
      </div>

      {/* Hover tooltip */}
      {hovered && !isDimmed && (
        <div
          className="glass-panel pointer-events-none absolute left-1/2 z-40 -translate-x-1/2 whitespace-nowrap rounded-lg px-2.5 py-1.5 text-[10.5px] shadow-panel"
          style={{ bottom: 30 }}
        >
          <div className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ backgroundColor: color }} />
            <span className="font-mono font-bold text-ink">{train.id}</span>
            <span className="text-ink-faint">·</span>
            <span className="font-semibold tracking-wide" style={{ color }}>
              {meta?.label}
            </span>
          </div>
          {(currentName || nextName) && (
            <div className="mt-0.5 text-ink-muted">
              {currentName || '—'} <span className="text-ink-faint">→</span> {nextName || '—'}
            </div>
          )}
          <div className="mt-0.5 flex items-center gap-2 text-ink-muted">
            <span>
              ETA <span className="font-mono tabular text-ink">{train.predictedETA}</span>
            </span>
            <span>{train.delay > 0 ? <span style={{ color }}>+{train.delay}m late</span> : 'On schedule'}</span>
          </div>
        </div>
      )}
    </div>
  );
}
