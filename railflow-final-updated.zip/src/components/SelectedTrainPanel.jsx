import React, { useState } from 'react';
import { ChevronDown, TrainFront, MapPin, ArrowRight, HelpCircle } from 'lucide-react';
import { STATION_MAP } from '../data/mockNetwork';
import { STATUS_META } from '../data/mockTrains';

const TEXT_COLOR = {
  onTime: 'text-signal-normal',
  delayed: 'text-signal-delay',
  atRisk: 'text-signal-warning',
  conflict: 'text-signal-danger',
};

export default function SelectedTrainPanel({ train, currentSegment }) {
  const [expanded, setExpanded] = useState(true);

  if (!train) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-2 px-6 py-10 text-center">
        <TrainFront size={22} className="text-ink-faint" />
        <p className="text-[11.5px] text-ink-faint">Select a train from the monitor or map to inspect its live forecast.</p>
      </div>
    );
  }

  const meta = STATUS_META[train.status];
  const color = TEXT_COLOR[train.status];
  const currentName = currentSegment?.fromId ? STATION_MAP[currentSegment.fromId]?.name : STATION_MAP[train.path[0]]?.name;
  const nextName = currentSegment?.toId ? STATION_MAP[currentSegment.toId]?.name : STATION_MAP[train.path[1]]?.name;

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="font-mono text-[15px] font-bold text-ink">{train.id}</span>
          <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold tracking-wide ${color} bg-base-800`}>
            {meta.label}
          </span>
        </div>
      </div>
      <p className="mt-0.5 text-[11px] text-ink-muted">{train.routeLabel}</p>

      <div className="mt-3 flex items-center gap-2 rounded-lg border border-line bg-base-800/60 px-3 py-2.5">
        <div className="flex flex-1 items-center gap-1.5 text-ink">
          <MapPin size={12} className="text-signal-active" />
          <span className="truncate text-[12px] font-medium">{currentName}</span>
        </div>
        <ArrowRight size={12} className="shrink-0 text-ink-faint" />
        <div className="flex flex-1 items-center gap-1.5 text-ink">
          <span className="truncate text-[12px] font-medium">{nextName}</span>
        </div>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2">
        <div className="rounded-lg border border-line bg-base-800/40 px-3 py-2">
          <p className="text-[10px] text-ink-faint">SCHEDULED ETA</p>
          <p className="mt-0.5 font-mono text-[14px] tabular text-ink">{train.scheduledETA}</p>
        </div>
        <div className="rounded-lg border border-line bg-base-800/40 px-3 py-2">
          <p className="text-[10px] text-ink-faint">PREDICTED ETA</p>
          <p className={`mt-0.5 font-mono text-[14px] tabular ${color}`}>{train.predictedETA}</p>
        </div>
      </div>

      <div className="mt-2 flex items-center justify-between rounded-lg border border-line bg-base-800/40 px-3 py-2">
        <span className="text-[10px] text-ink-faint">DELAY</span>
        <span className={`font-mono text-[13px] font-semibold tabular ${color}`}>
          {train.delay > 0 ? `+${train.delay} min` : 'On schedule'}
        </span>
      </div>

      <button
        onClick={() => setExpanded((v) => !v)}
        className="mt-3 flex w-full items-center justify-between rounded-lg border border-line bg-base-800/60 px-3 py-2 transition-colors hover:bg-base-800"
      >
        <div className="flex items-center gap-1.5">
          <HelpCircle size={13} className="text-signal-active" />
          <span className="text-[11.5px] font-semibold text-ink">WHY?</span>
        </div>
        <ChevronDown size={14} className={`text-ink-faint transition-transform ${expanded ? 'rotate-180' : ''}`} />
      </button>

      {expanded && (
        <div className="mt-2 animate-fadeUp rounded-lg border border-line-soft bg-base-900/60 px-3 py-2.5 text-[11.5px] leading-relaxed text-ink-muted">
          {train.status === 'onTime'
            ? 'No conflicts predicted along the remaining route. Forecast holds at scheduled arrival.'
            : `Predicted conflict at Junction J1 is expected to add ${train.delay} min to this service's arrival.`}
        </div>
      )}
    </div>
  );
}
