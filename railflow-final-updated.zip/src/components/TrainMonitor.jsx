import React from 'react';
import { ListFilter, TrainFront } from 'lucide-react';
import TrainCard from './TrainCard';

export default function TrainMonitor({ trains, selectedTrainId, onSelectTrain }) {
  return (
    <aside className="flex w-[300px] shrink-0 flex-col border-r border-line bg-base-900/60">
      <div className="flex items-center justify-between border-b border-line px-4 py-3">
        <div className="flex items-center gap-2">
          <TrainFront size={14} className="text-ink-muted" />
          <h2 className="text-[12px] font-semibold tracking-wide text-ink">TRAIN MONITOR</h2>
        </div>
        <span className="rounded-md p-1 text-ink-faint" title="All active services shown">
          <ListFilter size={14} />
        </span>
      </div>

      <div className="flex items-center gap-3 border-b border-line px-4 py-2 text-[10.5px] text-ink-faint">
        <span>{trains.length} active services</span>
        <span className="h-1 w-1 rounded-full bg-line-bright" />
        <span>Vijayawada sector</span>
      </div>

      <div className="flex-1 space-y-1.5 overflow-y-auto px-2.5 py-2.5">
        {trains.map((train) => (
          <TrainCard
            key={train.id}
            train={train}
            isSelected={train.id === selectedTrainId}
            onSelect={onSelectTrain}
          />
        ))}
      </div>
    </aside>
  );
}
