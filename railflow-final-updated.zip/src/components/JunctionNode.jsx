import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';
import ConflictMarker from './ConflictMarker';

const centerHandleStyle = {
  opacity: 0,
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  pointerEvents: 'none',
};

// Track stubs radiating out from the hub, angled to roughly match the
// three arms + convergence at Vijayawada (north to Eluru, south-west to
// Guntur, south-east to Tenali) so the node itself reads as "tracks
// converging on a junction" rather than a generic icon.
const SPOKE_ANGLES_DEG = [-90, -140, -40, 150, 30];

function JunctionNode({ data }) {
  const { label, code, highlighted, dimmed, conflictLevel, platforms } = data;

  const strokeColor = conflictLevel === 'danger' ? '#F1454F' : conflictLevel === 'warning' ? '#F0C043' : '#4C8CFF';
  const fillDim = conflictLevel === 'danger' ? '#3B1A1D' : conflictLevel === 'warning' ? '#3B3319' : '#121826';

  return (
    <div className={`relative flex flex-col items-center transition-opacity duration-300 ${dimmed ? 'opacity-30' : 'opacity-100'}`}>
      <Handle type="target" position={Position.Top} style={centerHandleStyle} />
      <Handle type="source" position={Position.Top} style={centerHandleStyle} />

      <div className="relative flex h-16 w-16 items-center justify-center">
        <ConflictMarker level={conflictLevel} />

        {/* Converging/diverging track spokes + platform block — the
            junction hub itself, not a status icon. */}
        <svg width="64" height="64" viewBox="-32 -32 64 64" style={{ overflow: 'visible' }}>
          {SPOKE_ANGLES_DEG.map((deg) => {
            const rad = (deg * Math.PI) / 180;
            const x1 = Math.cos(rad) * 13;
            const y1 = Math.sin(rad) * 13;
            const x2 = Math.cos(rad) * 22;
            const y2 = Math.sin(rad) * 22;
            return <line key={deg} x1={x1} y1={y1} x2={x2} y2={y2} stroke={strokeColor} strokeWidth="1.6" opacity="0.7" strokeLinecap="round" />;
          })}
          {/* Platform / station building block */}
          <rect x="-13" y="-9" width="26" height="18" rx="3" fill={fillDim} stroke={strokeColor} strokeWidth="1.8" />
          <rect x="-9.5" y="-2.5" width="19" height="3" rx="1" fill={strokeColor} opacity="0.35" />
          {/* Signal / junction marker */}
          <circle cx="0" cy="-9" r="2.6" fill={strokeColor} />
        </svg>
      </div>

      <div
        className={`mt-1.5 rounded-md border px-3 py-1.5 text-center leading-none shadow-panel ${
          conflictLevel === 'danger'
            ? 'border-signal-danger/50 bg-signal-danger/10'
            : conflictLevel === 'warning'
            ? 'border-signal-warning/50 bg-signal-warning/10'
            : 'border-signal-active/40 bg-signal-active/10'
        }`}
      >
        <div
          className={`font-mono text-[12px] font-bold tracking-wide ${
            conflictLevel === 'danger' ? 'text-signal-danger' : conflictLevel === 'warning' ? 'text-signal-warning' : 'text-signal-active'
          }`}
        >
          {code}
        </div>
        <div className="whitespace-nowrap text-[10.5px] font-semibold uppercase tracking-wide text-ink">{label}</div>
        {platforms && (
          <div className="mt-1 flex justify-center gap-0.5">
            {platforms.map((p) => (
              <span key={p} className="rounded-sm bg-base-900 px-1 text-[8px] text-ink-faint">
                {p}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default memo(JunctionNode);
