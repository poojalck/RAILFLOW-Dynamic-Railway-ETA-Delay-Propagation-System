import React, { useState } from 'react';
import { AlertCircle, FlaskConical, Loader2, Minus, Plus, X } from 'lucide-react';

// PHASE 2 CHUNK 16 (FINAL INTEGRATION) —
//
//   User picks a train + delay -> useWhatIf (POST
//   /api/simulation/what-if) -> this panel renders the REAL response:
//   base vs. what-if network delay, the delta, and which trains/
//   conflicts actually changed.
//
// This replaces the previous mock-only version (it faked a scenario by
// mutating local component/App state and never called the backend — see
// git history / CHUNK 15 handoff notes). Field set, style, and slot in
// App.jsx are otherwise unchanged: same TRAIN selector, same +/- delay
// stepper, same panel chrome as before and as OptimizePanel.jsx. The one
// removed field is "AFFECTED RESOURCE": it was UI-only decoration wired
// to a mock resource list (data/mockNetwork.js's RESOURCES) that the
// backend's What-If vocabulary (engine/whatIf.js's 'delay' | 'hold' |
// 'priority') has no place for, so it could never do anything real.
import useWhatIf from '../hooks/useWhatIf';

function StatCell({ label, value, colorClass = 'text-ink' }) {
  return (
    <div className="rounded-md border border-line-soft bg-base-800/50 px-3 py-2.5">
      <p className="text-[9.5px] font-medium tracking-wider text-ink-faint">{label}</p>
      <p className={`mt-0.5 font-mono text-[15px] font-semibold tabular ${colorClass}`}>{value}</p>
    </div>
  );
}

export default function WhatIfPanel({ trains, onClose }) {
  const [trainId, setTrainId] = useState(trains[0]?.id || '');
  const [extraDelay, setExtraDelay] = useState(15);
  const { result, loading, error, runWhatIf } = useWhatIf();

  const handleSimulate = () => {
    if (!trainId) return;
    runWhatIf({ type: 'delay', trainId, minutes: extraDelay }).catch(() => {
      // error state already captured by the hook; nothing further to do
    });
  };

  return (
    <div className="animate-fadeUp border-t border-line bg-base-900/95 px-5 py-4">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FlaskConical size={14} className="text-signal-active" />
          <h3 className="text-[12px] font-semibold tracking-wide text-ink">WHAT IF?</h3>
        </div>
        <button onClick={onClose} className="rounded-md p-1 text-ink-faint hover:bg-base-800 hover:text-ink">
          <X size={14} />
        </button>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-[10px] text-ink-faint">TRAIN</label>
          <select
            value={trainId}
            onChange={(e) => setTrainId(e.target.value)}
            className="w-full rounded-md border border-line bg-base-800 px-2.5 py-1.5 text-[12px] text-ink outline-none focus:border-signal-active/50"
          >
            {trains.map((t) => (
              <option key={t.id} value={t.id}>
                {t.id} &middot; {t.routeLabel}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="mb-1 block text-[10px] text-ink-faint">ADDITIONAL DELAY</label>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setExtraDelay((v) => Math.max(1, v - 5))}
              className="flex h-7 w-7 items-center justify-center rounded-md border border-line bg-base-800 text-ink-muted hover:text-ink"
            >
              <Minus size={12} />
            </button>
            <span className="w-16 text-center font-mono text-[13px] tabular text-ink">{extraDelay} min</span>
            <button
              onClick={() => setExtraDelay((v) => v + 5)}
              className="flex h-7 w-7 items-center justify-center rounded-md border border-line bg-base-800 text-ink-muted hover:text-ink"
            >
              <Plus size={12} />
            </button>
          </div>
        </div>
      </div>

      <button
        onClick={handleSimulate}
        disabled={loading || !trainId}
        className="mt-4 flex items-center gap-1.5 rounded-md bg-signal-active/90 px-6 py-2 text-[12px] font-semibold tracking-wide text-base-950 transition-colors hover:bg-signal-active disabled:cursor-not-allowed disabled:opacity-50"
      >
        {loading && <Loader2 size={13} className="animate-spin" />}
        {loading ? 'SIMULATING…' : 'SIMULATE SCENARIO'}
      </button>

      {error && !loading && (
        <div className="mt-3 flex items-start gap-2 rounded-md border border-signal-danger/30 bg-signal-danger/10 px-3 py-2.5">
          <AlertCircle size={14} className="mt-[1px] shrink-0 text-signal-danger" />
          <p className="text-[11.5px] leading-snug text-signal-danger">
            Could not reach the simulator: {error.message}
          </p>
        </div>
      )}

      {result && !loading && !error && (
        <div className="mt-4 space-y-2">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
            <StatCell label="DELAY BEFORE" value={`${result.base.networkDelay} min`} colorClass="text-ink-muted" />
            <StatCell label="ADDED DELAY" value={`+${result.intervention.minutes} min`} colorClass="text-signal-delay" />
            <StatCell label="DELAY AFTER" value={`${result.whatIf.networkDelay} min`} colorClass="text-signal-delay" />
            <StatCell
              label="NET CHANGE"
              value={`${result.impact.additionalDelay > 0 ? '+' : ''}${result.impact.additionalDelay} min`}
              colorClass={result.impact.additionalDelay > 0 ? 'text-signal-delay' : 'text-signal-normal'}
            />
            <StatCell
              label="CONFLICT CHANGE"
              value={`${result.impact.conflictChange > 0 ? '+' : ''}${result.impact.conflictChange}`}
              colorClass={result.impact.conflictChange > 0 ? 'text-signal-danger' : 'text-signal-normal'}
            />
          </div>
          <p className="text-[10.5px] leading-snug text-ink-faint">
            {result.impact.changedTrains.length > 0
              ? `Trains affected: ${result.impact.changedTrains.join(', ')}`
              : 'No train ETAs changed under this scenario.'}
          </p>
        </div>
      )}
    </div>
  );
}
