import React from 'react';
import { AlertCircle, CheckCircle2, Loader2, TrendingDown, Wand2, X } from 'lucide-react';
import useOptimization from '../hooks/useOptimization';

// PHASE 2 CHUNK 15 (OPTIMIZATION FRONTEND UI) —
//
//   User clicks "Run Optimization" -> useOptimization (POST
//   /api/simulation/optimize) -> this panel renders the REAL response:
//   the best intervention the existing optimizer found, network delay
//   before/after, improvement, how many candidates it evaluated, and a
//   plain-language explanation of the recommendation.
//
// Pure presentation + one fetch trigger: no scoring/candidate-generation
// logic lives here — everything numeric comes straight from the
// backend's engine/optimization/optimizer.js by way of
// services/simulationService.js's getOptimizationRun(). Styling mirrors
// WhatIfPanel.jsx (same slot in App.jsx, same border/spacing/animation
// conventions) so this reads as part of the existing dashboard.

function describeIntervention(intervention) {
  if (!intervention) {
    return 'No candidate intervention improved on the current schedule — the network is already running at its best achievable delay.';
  }
  if (intervention.type === 'hold') {
    const minutes = intervention.minutes;
    return `Hold train ${intervention.trainId} for ${minutes} minute${minutes === 1 ? '' : 's'} so the train it currently conflicts with can clear the shared resource first.`;
  }
  if (intervention.type === 'priority') {
    return `Raise train ${intervention.trainId} to priority ${intervention.priority}, giving it precedence over the train it currently conflicts with at the shared resource.`;
  }
  return `Apply a "${intervention.type}" intervention on train ${intervention.trainId}.`;
}

function interventionLabel(intervention) {
  if (!intervention) return 'NO CHANGE';
  if (intervention.type === 'hold') return `HOLD ${intervention.trainId} · +${intervention.minutes} MIN`;
  if (intervention.type === 'priority') return `PRIORITY ${intervention.trainId} · P${intervention.priority}`;
  return `${(intervention.type || 'UNKNOWN').toUpperCase()} ${intervention.trainId || ''}`.trim();
}

function StatCell({ label, value, colorClass = 'text-ink' }) {
  return (
    <div className="rounded-md border border-line-soft bg-base-800/50 px-3 py-2.5">
      <p className="text-[9.5px] font-medium tracking-wider text-ink-faint">{label}</p>
      <p className={`mt-0.5 font-mono text-[15px] font-semibold tabular ${colorClass}`}>{value}</p>
    </div>
  );
}

export default function OptimizePanel({ onClose }) {
  const { result, loading, error, runOptimization } = useOptimization();

  const handleRun = () => {
    runOptimization().catch(() => {
      // error state already captured by the hook; nothing further to do
    });
  };

  return (
    <div className="animate-fadeUp border-t border-line bg-base-900/95 px-5 py-4">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Wand2 size={14} className="text-signal-active" />
          <h3 className="text-[12px] font-semibold tracking-wide text-ink">OPTIMIZE</h3>
        </div>
        <button onClick={onClose} className="rounded-md p-1 text-ink-faint hover:bg-base-800 hover:text-ink">
          <X size={14} />
        </button>
      </div>

      {!result && !loading && !error && (
        <div className="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="max-w-md text-[11.5px] leading-snug text-ink-muted">
            Evaluate candidate interventions against the current network state and recommend the change that
            reduces total delay the most.
          </p>
          <button
            onClick={handleRun}
            className="flex shrink-0 items-center gap-1.5 rounded-md bg-signal-active/90 px-4 py-2 text-[12px] font-semibold tracking-wide text-base-950 transition-colors hover:bg-signal-active"
          >
            <Wand2 size={13} />
            RUN OPTIMIZATION
          </button>
        </div>
      )}

      {loading && (
        <div className="flex items-center gap-2 py-3 text-[12px] text-ink-muted">
          <Loader2 size={14} className="animate-spin text-signal-active" />
          Evaluating candidate interventions against the current schedule…
        </div>
      )}

      {error && !loading && (
        <div className="flex flex-col gap-2 rounded-md border border-signal-danger/30 bg-signal-danger/10 px-3 py-2.5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-2">
            <AlertCircle size={14} className="mt-[1px] shrink-0 text-signal-danger" />
            <p className="text-[11.5px] leading-snug text-signal-danger">
              Could not reach the optimizer: {error.message}
            </p>
          </div>
          <button
            onClick={handleRun}
            className="shrink-0 rounded-md border border-signal-danger/40 px-3 py-1.5 text-[11px] font-semibold text-signal-danger transition-colors hover:bg-signal-danger/10"
          >
            RETRY
          </button>
        </div>
      )}

      {result && !loading && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <StatCell label="DELAY BEFORE" value={`${result.base.networkDelay} min`} colorClass="text-signal-delay" />
            <StatCell label="DELAY AFTER" value={`${result.result.networkDelay} min`} colorClass="text-signal-normal" />
            <StatCell
              label="IMPROVEMENT"
              value={`${result.improvement > 0 ? '−' : ''}${Math.abs(result.improvement)} min`}
              colorClass={result.improvement > 0 ? 'text-signal-normal' : 'text-ink-muted'}
            />
            <StatCell label="CANDIDATES EVALUATED" value={result.candidatesEvaluated} colorClass="text-ink" />
          </div>

          <div
            className={`rounded-md border px-3 py-2.5 ${
              result.improved
                ? 'border-signal-active/30 bg-signal-active/10'
                : 'border-line-soft bg-base-800/40'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                {result.improved ? (
                  <TrendingDown size={13} className="text-signal-active" />
                ) : (
                  <CheckCircle2 size={13} className="text-ink-faint" />
                )}
                <span className="text-[10px] font-semibold tracking-wide text-ink-faint">
                  {result.improved ? 'BEST INTERVENTION' : 'NO CHANGE RECOMMENDED'}
                </span>
              </div>
              <span
                className={`rounded-full px-2 py-0.5 font-mono text-[10px] font-semibold tabular ${
                  result.improved ? 'bg-signal-active/15 text-signal-active' : 'bg-base-800 text-ink-faint'
                }`}
              >
                {interventionLabel(result.bestIntervention)}
              </span>
            </div>
            <p className="mt-1.5 text-[11.5px] leading-snug text-ink-muted">
              {describeIntervention(result.bestIntervention)}
            </p>
          </div>

          <button
            onClick={handleRun}
            className="rounded-md border border-line bg-base-800 px-3 py-1.5 text-[11px] font-semibold text-ink-muted transition-colors hover:border-line-bright hover:text-ink"
          >
            RUN AGAIN
          </button>
        </div>
      )}
    </div>
  );
}
