import React from 'react';
import { BaseEdge } from 'reactflow';
import { offsetPolyline, pointAt, polylinePathD, quadPathD } from '../utils/trackGeometry';

const COLORS = {
  default: '#3A4560',
  highlighted: '#4C8CFF',
  passed: '#2A3548',
  conflict: '#F1454F',
};

const RAIL_OFFSET = 4.5; // gap between the two parallel rails of a main line
const SLEEPER_COUNT = 16;

export default function TrackEdge({ sourceX, sourceY, targetX, targetY, data }) {
  const { kind = 'main', control, highlighted, dimmed, passed, conflictPulse } = data || {};

  const from = { x: sourceX, y: sourceY };
  const to = { x: targetX, y: targetY };
  const ctrl = control || { x: (sourceX + targetX) / 2, y: (sourceY + targetY) / 2 };

  const centerPath = quadPathD(from, ctrl, to);
  const isMain = kind === 'main';

  const color = conflictPulse ? COLORS.conflict : highlighted ? COLORS.highlighted : passed ? COLORS.passed : COLORS.default;
  const opacity = dimmed ? 0.18 : 1;
  const railWidth = isMain ? 2.4 : 1.8;

  const railA = isMain ? offsetPolyline(from, ctrl, to, RAIL_OFFSET) : null;
  const railB = isMain ? offsetPolyline(from, ctrl, to, -RAIL_OFFSET) : null;

  // Sleeper ties: short perpendicular strokes between the two rails,
  // evenly spaced along the curve — this is what reads as "railway track"
  // rather than "graph edge" at a glance.
  const sleepers = isMain
    ? Array.from({ length: SLEEPER_COUNT + 1 }, (_, i) => {
        const t = i / SLEEPER_COUNT;
        const p = pointAt(from, ctrl, to, t);
        const rad = (p.angle * Math.PI) / 180;
        const nx = -Math.sin(rad);
        const ny = Math.cos(rad);
        const half = RAIL_OFFSET + 1.6;
        return {
          x1: p.x + nx * half,
          y1: p.y + ny * half,
          x2: p.x - nx * half,
          y2: p.y - ny * half,
        };
      })
    : [];

  const arrowStops = [0.3, 0.65];

  return (
    <g style={{ opacity, transition: 'opacity 300ms ease' }}>
      {/* Wide invisible hit area so React Flow keeps the edge selectable/hoverable */}
      <BaseEdge path={centerPath} style={{ stroke: 'transparent', strokeWidth: 18 }} />

      {isMain ? (
        <>
          {sleepers.map((s, i) => (
            <line key={i} x1={s.x1} y1={s.y1} x2={s.x2} y2={s.y2} stroke={color} strokeWidth={1.1} opacity={0.55} strokeLinecap="round" />
          ))}
          <path d={polylinePathD(railA)} stroke={color} strokeWidth={railWidth} fill="none" strokeLinecap="round" />
          <path d={polylinePathD(railB)} stroke={color} strokeWidth={railWidth} fill="none" strokeLinecap="round" />
        </>
      ) : (
        <path d={centerPath} stroke={color} strokeWidth={railWidth} fill="none" strokeDasharray="2 6" strokeLinecap="round" />
      )}

      {highlighted && !conflictPulse && (
        <path d={centerPath} stroke={COLORS.highlighted} strokeWidth={2} fill="none" className="track-flow-anim" strokeLinecap="round" />
      )}

      {conflictPulse && (
        <path d={centerPath} stroke={COLORS.conflict} strokeWidth={2.2} fill="none" className="track-flow-anim" strokeLinecap="round" opacity={0.85} />
      )}

      {arrowStops.map((t) => {
        const p = pointAt(from, ctrl, to, t);
        return (
          <polygon
            key={t}
            points="-3.5,-3.5 4.5,0 -3.5,3.5"
            transform={`translate(${p.x},${p.y}) rotate(${p.angle})`}
            fill={dimmed ? COLORS.passed : color}
            opacity={highlighted || conflictPulse ? 0.95 : 0.5}
          />
        );
      })}
    </g>
  );
}
