export const INITIAL_ALERTS = [
  {
    id: 'a1',
    level: 'warning',
    title: 'Platform Risk',
    detail: 'Platform P3 possible overlap in 12 min',
  },
];

// Staged mock event sequence for the "DEMO SCENARIO" button.
// Each stage is applied a few seconds after the previous one.
export const DEMO_STAGES = [
  { id: 1, delayMs: 0, label: 'Network stable' },
  { id: 2, delayMs: 2200, label: 'Train 12601 receives +15 min' },
  { id: 3, delayMs: 4400, label: 'Junction J1 enters warning state' },
  { id: 4, delayMs: 6600, label: 'Train 12602 becomes at-risk' },
  { id: 5, delayMs: 8800, label: 'Platform P3 enters warning state' },
  { id: 6, delayMs: 11000, label: 'Network delay metrics increase' },
  { id: 7, delayMs: 13200, label: 'Delay ripple propagation visualised' },
];

export const RIPPLE_CHAIN = [
  { id: 'r1', kind: 'train', label: 'Train 12601' },
  { id: 'r2', kind: 'junction', label: 'Junction J1' },
  { id: 'r3', kind: 'train', label: 'Train 12602' },
  { id: 'r4', kind: 'platform', label: 'Platform P3' },
  { id: 'r5', kind: 'train', label: 'Train 16722' },
];
