// Simplified fictional network inspired by the real Vijayawada railway network.
// Coordinates are arbitrary flow-space units consumed directly by React Flow
// (no map projection). This is a schematic demo layout, not a signalling diagram.
//
// Shape (matches the requested schematic):
//
//                         RJY
//                        /
//                     ELR
//                      |
//        GNT ————————— VJA ————————— GDV
//              \                /
//               \              /
//                \            /
//              (via VJA)    TEL —— GDV (secondary chord)
//                              |
//                             BPT
//                              |
//                             CLX
//
// Vijayawada (VJA) is the sole central junction: Eluru (north), Guntur
// (south-west) and Tenali (south-east) are its three primary arms. Bapatla
// and Chirala hang off the Tenali corridor, not off Vijayawada directly.

export const STATIONS = [
  { id: 'VJA', name: 'Vijayawada Jn', short: 'VJA', x: 620, y: 460, kind: 'junction', platforms: ['P1', 'P2', 'P3', 'P4'] },
  { id: 'ELR', name: 'Eluru', short: 'ELR', x: 620, y: 150, kind: 'station' },
  { id: 'RJY', name: 'Rajahmundry', short: 'RJY', x: 880, y: 30, kind: 'station' },
  { id: 'GNT', name: 'Guntur', short: 'GNT', x: 230, y: 680, kind: 'station' },
  { id: 'MTM', name: 'Machilipatnam', short: 'MTM', x: 40, y: 780, kind: 'station' },
  { id: 'TEL', name: 'Tenali Jn', short: 'TEL', x: 1010, y: 680, kind: 'station' },
  { id: 'GDV', name: 'Gudivada', short: 'GDV', x: 1240, y: 430, kind: 'station' },
  { id: 'BPT', name: 'Bapatla', short: 'BPT', x: 1010, y: 900, kind: 'station' },
  { id: 'CLX', name: 'Chirala', short: 'CLX', x: 1010, y: 1090, kind: 'station' },
];

export const STATION_MAP = STATIONS.reduce((acc, s) => {
  acc[s.id] = s;
  return acc;
}, {});

// Physical tracks. `kind: 'main'` renders as a heavier double-rail trunk
// route, `kind: 'branch'` as a lighter single dashed line. `curve` is an
// optional Bezier control point (flow-space coords) that bends the track;
// omit it for a dead-straight segment. Every consecutive pair in every
// train's `path` (see mockTrains.js) MUST correspond to exactly one track
// here — that correspondence is what keeps trains physically on-rail.
export const TRACKS = [
  // Three primary arms of the Vijayawada junction.
  { id: 'VJA-ELR', source: 'VJA', target: 'ELR', kind: 'main' },
  { id: 'VJA-GNT', source: 'VJA', target: 'GNT', kind: 'main', curve: { x: 400, y: 520 } },
  { id: 'VJA-TEL', source: 'VJA', target: 'TEL', kind: 'main', curve: { x: 840, y: 520 } },

  // Tenali corridor continues south to Bapatla / Chirala.
  { id: 'TEL-BPT', source: 'TEL', target: 'BPT', kind: 'main' },
  { id: 'BPT-CLX', source: 'BPT', target: 'CLX', kind: 'branch' },

  // Secondary branches off the three main arms.
  { id: 'ELR-RJY', source: 'ELR', target: 'RJY', kind: 'branch', curve: { x: 820, y: 60 } },
  { id: 'VJA-MTM', source: 'VJA', target: 'MTM', kind: 'branch', curve: { x: 260, y: 560 } },
  { id: 'VJA-GDV', source: 'VJA', target: 'GDV', kind: 'branch', curve: { x: 1000, y: 380 } },
  { id: 'TEL-GDV', source: 'TEL', target: 'GDV', kind: 'branch', curve: { x: 1160, y: 600 } },
];

export const TRACK_MAP = TRACKS.reduce((acc, t) => {
  acc[`${t.source}|${t.target}`] = t;
  acc[`${t.target}|${t.source}`] = t;
  return acc;
}, {});

export function findTrack(fromId, toId) {
  return TRACK_MAP[`${fromId}|${toId}`] || null;
}

// Junctions / shared resources tracked for conflict simulation.
export const RESOURCES = [
  { id: 'J1', label: 'Junction J1', stationId: 'VJA', type: 'junction' },
  { id: 'P3', label: 'Platform P3', stationId: 'VJA', type: 'platform' },
];
