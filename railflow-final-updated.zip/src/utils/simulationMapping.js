// utils/simulationMapping.js
//
// PHASE 2 CHUNK 10 (FRONTEND: REAL TRAIN DATA) — pure mapping helper.
//
// The backend's GET /api/simulation returns the raw fleet (`trains`,
// straight from data/trains.js) separately from the engine's computed
// per-train result (`etas`: scheduledETA/predictedETA/totalDelay, keyed
// by trainId — see backend/engine/etaCalculator.js). This module merges
// the two into the flat per-train shape the existing frontend components
// already expect (the same shape mockTrains.js's INITIAL_TRAINS uses):
//
//   { id, routeLabel, path, speed, delay, status, scheduledETA,
//     predictedETA, priority, ... }
//
// No scheduling/engine logic lives here — `statusForDelay` intentionally
// mirrors the same simple rule the backend's own services/trainService.js
// already applies (delay > 0 -> 'delayed', else 'onTime'), purely so the
// two stay visually consistent; this file does not invent any new
// classification of its own.

/**
 * @param {number} totalDelay
 * @returns {'onTime'|'delayed'}
 */
function statusForDelay(totalDelay) {
  return totalDelay > 0 ? 'delayed' : 'onTime';
}

/**
 * Merge one simulation result's `trains` + `etas` into the flat display
 * shape the frontend train components consume.
 *
 * @param {{trains?: Array<object>, etas?: Array<{trainId:string, scheduledETA:string, predictedETA:string, totalDelay:number}>}|null} simulation
 *   - the object returned by GET /api/simulation (see
 *   backend/services/simulationService.js).
 * @returns {Array<object>|null} the merged, display-ready train list, or
 *   `null` when `simulation` doesn't (yet) contain a usable train list —
 *   callers should fall back to their own default/mock data in that case
 *   rather than rendering nothing.
 */
export function mapSimulationToDisplayTrains(simulation) {
  if (!simulation || !Array.isArray(simulation.trains) || simulation.trains.length === 0) {
    return null;
  }

  const etaByTrainId = new Map((simulation.etas || []).map((eta) => [eta.trainId, eta]));

  return simulation.trains.map((train) => {
    const eta = etaByTrainId.get(train.id);
    if (!eta) return train; // no engine ETA output for this train (shouldn't happen); leave it as-is

    return {
      ...train,
      scheduledETA: eta.scheduledETA,
      predictedETA: eta.predictedETA,
      delay: eta.totalDelay,
      status: statusForDelay(eta.totalDelay),
    };
  });
}
