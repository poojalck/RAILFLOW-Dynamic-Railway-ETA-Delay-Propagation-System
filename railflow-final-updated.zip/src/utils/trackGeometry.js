// Shared curved-track geometry.
//
// Every physical track is a quadratic Bezier from one station to another.
// This module is the single source of truth for that curve's shape, used
// both to draw the SVG rail path (TrackEdge) and to drive train motion
// (useTrainSimulation) — so a train's marker is mathematically guaranteed
// to sit on the same curve that's rendered, never a straight-line shortcut
// between the two station dots.

const ARC_SAMPLES = 48; // resolution of the arc-length lookup table

function quadPoint(from, control, to, t) {
  const mt = 1 - t;
  return {
    x: mt * mt * from.x + 2 * mt * t * control.x + t * t * to.x,
    y: mt * mt * from.y + 2 * mt * t * control.y + t * t * to.y,
  };
}

function quadTangent(from, control, to, t) {
  const mt = 1 - t;
  return {
    dx: 2 * mt * (control.x - from.x) + 2 * t * (to.x - control.x),
    dy: 2 * mt * (control.y - from.y) + 2 * t * (to.y - control.y),
  };
}

/** Control point for a track: its own defined bend, or a dead-straight midpoint. */
export function controlPointFor(track, from, to) {
  if (track && track.curve) return track.curve;
  return { x: (from.x + to.x) / 2, y: (from.y + to.y) / 2 };
}

/**
 * Samples the curve into an arc-length lookup table: a flat list of
 * {x, y, dist} points where `dist` is the cumulative distance travelled
 * along the curve up to that point. Given any distance 0..length, this
 * lets both the renderer and the simulation find the *actual* (x, y)
 * point on the curve — not an approximation from raw endpoints.
 */
export function buildSegmentLookup(from, control, to) {
  const points = [];
  let length = 0;
  let prev = quadPoint(from, control, to, 0);
  points.push({ x: prev.x, y: prev.y, dist: 0 });
  for (let i = 1; i <= ARC_SAMPLES; i++) {
    const t = i / ARC_SAMPLES;
    const pt = quadPoint(from, control, to, t);
    length += Math.hypot(pt.x - prev.x, pt.y - prev.y);
    points.push({ x: pt.x, y: pt.y, dist: length });
    prev = pt;
  }
  return { points, length: length || 1 };
}

/** Constant-speed (x, y, angle) at `distance` along a prebuilt lookup table. */
export function sampleSegmentLookup(lookup, distance) {
  const { points, length } = lookup;
  const d = Math.min(Math.max(distance, 0), length);
  let i = 1;
  while (i < points.length - 1 && points[i].dist < d) i++;
  const a = points[i - 1];
  const b = points[i];
  const span = b.dist - a.dist || 1;
  const t = (d - a.dist) / span;
  const x = a.x + (b.x - a.x) * t;
  const y = a.y + (b.y - a.y) * t;
  const angle = (Math.atan2(b.y - a.y, b.x - a.x) * 180) / Math.PI;
  return { x, y, angle };
}

/** Full SVG `d` path for the curve — used directly to draw the rails. */
export function quadPathD(from, control, to) {
  return `M ${from.x} ${from.y} Q ${control.x} ${control.y} ${to.x} ${to.y}`;
}

/**
 * Samples the curve into a polyline, each point offset perpendicular to
 * the curve's local tangent by `offset` — used to draw the two parallel
 * rails of a "main" track so they stay parallel through the bend, not
 * just at the two endpoints.
 */
export function offsetPolyline(from, control, to, offset, steps = 28) {
  const pts = [];
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const p = quadPoint(from, control, to, t);
    const tan = quadTangent(from, control, to, t);
    const len = Math.hypot(tan.dx, tan.dy) || 1;
    const nx = -tan.dy / len;
    const ny = tan.dx / len;
    pts.push({ x: p.x + nx * offset, y: p.y + ny * offset });
  }
  return pts;
}

export function polylinePathD(points) {
  return points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
}

/** Point + tangent angle (degrees) at parameter t (0..1) along the curve. */
export function pointAt(from, control, to, t) {
  const p = quadPoint(from, control, to, t);
  const tan = quadTangent(from, control, to, t);
  return { x: p.x, y: p.y, angle: (Math.atan2(tan.dy, tan.dx) * 180) / Math.PI };
}
