// services/simulationService.js
//
// PHASE 2 CHUNK 9 (SIMULATION API) — exposes the complete current engine
// simulation result as a single structured object:
//
//   Engine simulation
//        |
//   trains + events + occupancy + conflicts + propagatedDelays + etas
//        |                                          (engine/index.js)
//        |
//   resourceState                    (engine/resourceStateBuilder.js,
//        |                            reused as-is from Chunk 8)
//        |
//   GET /api/simulation
//
// This mirrors the exact pattern trainService.js / alertService.js /
// networkService.js already use to connect to the engine: build the
// railway state from the existing static data (data/trains.js,
// data/network.js), run it through the engine orchestrator
// (simulateRailwayState, engine/index.js), and forward its outputs. No
// engine algorithm lives in this file, and no separate simulation
// implementation is created — this simply exposes the one existing
// orchestrator's output plus the existing resource-state aggregator's
// output, side by side.

import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';
import { simulateRailwayState } from '../engine/index.js';
import { buildResourceStates } from '../engine/resourceStateBuilder.js';
import { runWhatIfSimulation, validateIntervention } from '../engine/whatIf.js';
import { compareWhatIfResults, computeNetworkDelay } from '../engine/whatIfComparison.js';
import { optimize } from '../engine/optimization/optimizer.js';

/**
 * Build the railway state the engine needs from the existing static
 * data. Pure assembly only — no algorithm lives here. Identical shape to
 * trainService.js / alertService.js / networkService.js's
 * buildRailwayState().
 * @returns {{trains: Array<object>, resources: Array<object>, findTrack: Function}}
 */
function buildRailwayState() {
  return {
    trains: INITIAL_TRAINS,
    resources: RESOURCES,
    findTrack,
  };
}

/**
 * Run the engine once over the current railway state and assemble the
 * complete simulation result: every stage's output from
 * simulateRailwayState, plus the derived per-resource state (reusing the
 * same aggregator GET /api/network already relies on) and the raw fleet
 * the simulation ran against.
 *
 * @returns {{
 *   trains: Array<object>,
 *   events: Array<object>,
 *   occupancy: Array<object>,
 *   conflicts: Array<object>,
 *   propagatedDelays: {perConflict: Array<object>, delaysByTrain: Object<string, number>},
 *   etas: Array<object>,
 *   resourceState: Array<object>
 * }}
 */
export function getSimulationResult() {
  const state = buildRailwayState();
  const { events, occupancy, conflicts, propagatedDelays, etas } = simulateRailwayState(state);
  const resourceState = buildResourceStates({ resources: RESOURCES, occupancy, conflicts });

  return {
    trains: INITIAL_TRAINS,
    events,
    occupancy,
    conflicts,
    propagatedDelays,
    etas,
    resourceState,
  };
}

// ---------------------------------------------------------------------
// PHASE 2 CHUNK 12B — WHAT-IF RESULT COMPARISON.
//
// Reuses the same buildRailwayState() as getSimulationResult() above for
// the base side, and the existing What-If core (engine/whatIf.js,
// untouched from Chunk 12A) for the hypothetical side. The only new
// logic here is assembling the two engine results plus the derived
// `impact` summary (engine/whatIfComparison.js) into the response shape
// POST /api/simulation/what-if returns. No scheduling/conflict/
// propagation/ETA algorithm is duplicated anywhere in this function.
// ---------------------------------------------------------------------

/**
 * Run a single hypothetical intervention against the current railway
 * state and compare it with the current (base) simulation result.
 *
 * @param {object} intervention - { type: 'delay'|'hold', trainId, minutes }
 *   or { type: 'priority', trainId, priority }. Validated by
 *   engine/whatIf.js's runWhatIfSimulation (throws InvalidInterventionError
 *   on bad input — left to the caller/controller to catch).
 * @returns {{
 *   intervention: object,
 *   base: {etas: Array<object>, conflicts: Array<object>, networkDelay: number},
 *   whatIf: {etas: Array<object>, conflicts: Array<object>, networkDelay: number},
 *   impact: {changedTrains: Array<string>, additionalDelay: number, conflictChange: number}
 * }}
 */
export function getWhatIfComparison(intervention) {
  // The base railway state is only ever read here — runWhatIfSimulation
  // (engine/whatIf.js) clones it internally before applying the
  // intervention, so INITIAL_TRAINS/RESOURCES are never mutated and the
  // real base railway state remains unchanged.
  const state = buildRailwayState();

  const baseResult = simulateRailwayState(state);
  const whatIfResult = runWhatIfSimulation(intervention, state);

  const impact = compareWhatIfResults(baseResult, whatIfResult);
  const baseNetworkDelay = computeNetworkDelay(baseResult.etas);

  return {
    intervention,
    base: {
      etas: baseResult.etas,
      conflicts: baseResult.conflicts,
      networkDelay: baseNetworkDelay,
    },
    whatIf: {
      etas: whatIfResult.etas,
      conflicts: whatIfResult.conflicts,
      // PHASE 2 CHUNK 19 FIX — deliberately NOT computeNetworkDelay(whatIfResult.etas):
      // that would sum each train's totalDelay against the WHAT-IF run's
      // OWN (possibly shifted-by-the-intervention) scheduledETA, which
      // silently absorbs the requested delay/hold minutes into the new
      // baseline instead of showing them (see engine/whatIfComparison.js).
      // `networkDelay` here is defined so it always equals
      // `base.networkDelay + impact.additionalDelay` — i.e. "before" plus
      // the real net impact (requested delay + any propagated effect) —
      // which is what the What-If UI's DELAY AFTER is meant to show.
      networkDelay: baseNetworkDelay + impact.additionalDelay,
    },
    impact,
  };
}

// ---------------------------------------------------------------------
// PHASE 2 CHUNK 14 — OPTIMIZATION API (POST /api/simulation/optimize).
//
// Reuses the same buildRailwayState() as getSimulationResult()/
// getWhatIfComparison() above for the base side, and the EXISTING
// optimization foundation (engine/optimization/optimizer.js's optimize(),
// untouched from Chunks 13A/13B — which itself only calls the existing
// engine orchestrator, the existing What-If core, and the existing
// candidateGenerator.js) for candidate generation, evaluation, and
// selection. The only new logic here is: (1) validating any
// caller-supplied candidate list up front via the existing
// validateIntervention() so a bad candidate is rejected with a clear
// error instead of silently skipped, and (2) assembling optimize()'s
// outcome plus one extra base-state read into the response shape POST
// /api/simulation/optimize returns. No scheduling/conflict/occupancy/
// delay/ETA/What-If/scoring algorithm is duplicated anywhere in this
// function.
// ---------------------------------------------------------------------

/**
 * Run the existing optimization pass (generate candidates -> evaluate via
 * What-If -> score -> select best) over the current railway state, and
 * assemble the result into the API's response shape.
 *
 * @param {Array<object>} [candidates] - optional caller-supplied candidate
 *   interventions to evaluate instead of the auto-generated set. Each one
 *   must already be a valid What-If intervention (see
 *   WHAT_IF_INTERVENTION_TYPES in engine/whatIf.js) referencing a real
 *   train id; validated with the existing validateIntervention() before
 *   any simulation runs. When omitted, engine/optimization/optimizer.js's
 *   optimize() falls back to its own candidateGenerator.js-based set, as
 *   it already does for GET /api/optimization.
 * @returns {{
 *   base: {networkDelay: number, conflicts: Array<object>},
 *   bestIntervention: object|null,
 *   result: {networkDelay: number, conflicts: Array<object>},
 *   score: number,
 *   improvement: number,
 *   candidatesEvaluated: number,
 *   improved: boolean
 * }}
 * @throws {InvalidInterventionError} if any caller-supplied candidate is
 *   invalid (unknown type, unknown trainId, bad minutes/priority, etc).
 */
export function getOptimizationRun(candidates) {
  // The base railway state is only ever read here — validateIntervention
  // performs no mutation, optimize() (engine/optimization/optimizer.js)
  // evaluates every candidate via runWhatIfSimulation, which clones
  // state.trains internally, and simulateRailwayState() below is the same
  // pure read every other endpoint already uses. INITIAL_TRAINS/RESOURCES
  // are never mutated.
  const state = buildRailwayState();

  if (candidates !== undefined) {
    for (const candidate of candidates) {
      validateIntervention(candidate, state);
    }
  }

  const baseResult = simulateRailwayState(state);
  const outcome = optimize(state, candidates && candidates.length > 0 ? { candidates } : {});
  const bestResult = outcome.best.result;

  return {
    base: {
      networkDelay: computeNetworkDelay(baseResult.etas),
      conflicts: baseResult.conflicts,
    },
    bestIntervention: outcome.best.intervention,
    result: {
      networkDelay: outcome.best.score,
      conflicts: bestResult.conflicts,
    },
    score: outcome.best.score,
    improvement: outcome.baseline.score - outcome.best.score,
    candidatesEvaluated: outcome.candidatesEvaluated,
    improved: outcome.improved,
  };
}
