// services/networkService.js
//
// PHASE 1: returns the static topology.
//
// PHASE 2 CHUNK 8 (NETWORK STATE) — also connects the engine's computed
// resource occupancy/conflict output to this endpoint, alongside the
// unchanged static topology:
//
//   Engine simulation -> occupancy + conflicts -> resource-state
//   aggregation (engine/resourceStateBuilder.js) -> GET /api/network
//
// This mirrors the exact pattern trainService.js / alertService.js
// already use to connect to the engine: build the railway state from
// the existing static data (data/trains.js, data/network.js), run it
// through the engine orchestrator (simulateRailwayState, engine/index.js),
// and hand the relevant slice of its output to a pure aggregator. No
// occupancy/conflict algorithm lives in this file — it only assembles
// inputs and forwards outputs.
//
// Existing fields (stations, tracks, resources) are untouched; the
// computed `resourceState` is added alongside them, not in place of them.

import { STATIONS, TRACKS, RESOURCES, findTrack } from '../data/network.js';
import { INITIAL_TRAINS } from '../data/trains.js';
import { simulateRailwayState } from '../engine/index.js';
import { buildResourceStates } from '../engine/resourceStateBuilder.js';

/**
 * Build the railway state the engine needs from the existing static
 * data. Pure assembly only — no algorithm lives here. Identical shape to
 * trainService.js / alertService.js's buildRailwayState().
 * @returns {{trains: Array<object>, resources: Array<object>, findTrack: Function}}
 */
function buildRailwayState() {
  return {
    trains: INITIAL_TRAINS,
    resources: RESOURCES,
    findTrack,
  };
}

/**
 * Run the engine over the current railway state and derive the
 * per-resource status summary from its occupancy/conflict output.
 * @returns {Array<object>} one entry per static resource (see
 *   engine/resourceStateBuilder.js for the exact shape).
 */
function computeResourceState() {
  const state = buildRailwayState();
  const { occupancy, conflicts } = simulateRailwayState(state);
  return buildResourceStates({ resources: RESOURCES, occupancy, conflicts });
}

export function getNetworkTopology() {
  return {
    stations: STATIONS,
    tracks: TRACKS,
    resources: RESOURCES,
    resourceState: computeResourceState(),
  };
}
