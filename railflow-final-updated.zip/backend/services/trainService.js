// services/trainService.js
//
// Business-logic layer between the API routes and the underlying data /
// engine.
//
// PHASE 2 CHUNK 6 — connected to the engine:
//   `getAllTrains()` / `getTrainById()` no longer just hand back the
//   static seed fleet's `delay`/`status`/`predictedETA` values. Instead
//   this module builds the railway state the engine needs (trains +
//   resources + the network's `findTrack` lookup) from the existing
//   static data (data/trains.js, data/network.js), runs it through the
//   engine orchestrator (`simulateRailwayState`, engine/index.js), and
//   merges the computed ETA/delay back onto each train.
//
// The shape returned to callers is unchanged from Phase 1 — the same
// fields are present on every train, so the controller/routes above this
// layer did not need to change. This module contains no engine algorithm
// of its own; it only assembles inputs for `simulateRailwayState` and
// maps its output back onto the existing train records.

import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';
import { simulateRailwayState } from '../engine/index.js';

// Status rule (kept intentionally simple for this chunk): a train with
// zero engine-computed total delay is 'onTime'; any positive total delay
// makes it 'delayed'. This does not yet use the richer 'atRisk'/
// 'conflict' statuses defined in STATUS_META — that classification is
// future work, once the engine surfaces things like an unresolved/
// still-building conflict versus an already-resolved one.
function statusForDelay(totalDelay) {
  return totalDelay > 0 ? 'delayed' : 'onTime';
}

/**
 * Build the railway state the engine needs from the existing static
 * data. Pure assembly only — no algorithm lives here.
 * @returns {{trains: Array<object>, resources: Array<object>, findTrack: Function}}
 */
function buildRailwayState() {
  return {
    trains: INITIAL_TRAINS,
    resources: RESOURCES,
    findTrack,
  };
}

/**
 * Run the engine over the current railway state and index its per-train
 * ETA output by trainId for quick lookup.
 * @returns {Map<string, {trainId:string, scheduledETA:string, predictedETA:string, totalDelay:number}>}
 */
function computeEtaByTrainId() {
  const state = buildRailwayState();
  const { etas } = simulateRailwayState(state);
  return new Map(etas.map((eta) => [eta.trainId, eta]));
}

/**
 * Merge one train's engine-computed ETA/delay/status onto a copy of its
 * static record, preserving every other existing field (id, routeLabel,
 * path, speed, priority, scheduledDeparture, stops, ...) exactly as-is.
 * @param {object} train - a record from INITIAL_TRAINS
 * @param {{scheduledETA:string, predictedETA:string, totalDelay:number}|undefined} eta
 * @returns {object}
 */
function mergeEta(train, eta) {
  if (!eta) return train; // no engine output for this train (shouldn't happen); leave it untouched
  return {
    ...train,
    scheduledETA: eta.scheduledETA,
    predictedETA: eta.predictedETA,
    delay: eta.totalDelay,
    status: statusForDelay(eta.totalDelay),
  };
}

export function getAllTrains() {
  const etaByTrainId = computeEtaByTrainId();
  return INITIAL_TRAINS.map((train) => mergeEta(train, etaByTrainId.get(train.id)));
}

export function getTrainById(id) {
  const train = INITIAL_TRAINS.find((t) => t.id === id) || null;
  if (!train) return null;

  const etaByTrainId = computeEtaByTrainId();
  return mergeEta(train, etaByTrainId.get(id));
}
