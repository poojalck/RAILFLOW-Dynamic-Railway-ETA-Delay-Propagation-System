// services/optimizationService.js
//
// PHASE 2 CHUNK 13B (COMPLETE OPTIMIZATION) — exposes the engine's
// optimization pass as a single structured object:
//
//   Current railway state (data/trains.js, data/network.js)
//        |
//   optimize()                       (engine/optimization/optimizer.js,
//        |                            reusing candidateGenerator.js +
//        |                            evaluateIntervention/scoreResult
//        |                            from Chunk 13A, and — underneath
//        |                            all of that — the unmodified engine
//        |                            orchestrator + What-If core)
//        |
//   GET /api/optimization
//
// This mirrors the exact pattern simulationService.js already uses to
// connect to the engine: build the railway state from the existing
// static data, run it through the existing engine layer, and forward its
// output. No scheduling/conflict/occupancy/delay/ETA/optimization
// algorithm lives in this file — it is assembled entirely from existing
// modules.

import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';
import { optimize } from '../engine/optimization/optimizer.js';

/**
 * Build the railway state the engine needs from the existing static
 * data. Pure assembly only — no algorithm lives here. Identical shape to
 * simulationService.js's buildRailwayState().
 * @returns {{trains: Array<object>, resources: Array<object>, findTrack: Function}}
 */
function buildRailwayState() {
  return {
    trains: INITIAL_TRAINS,
    resources: RESOURCES,
    findTrack,
  };
}

/**
 * Run the full CHUNK 13B optimization pass over the current railway
 * state and return its result: the baseline (no-intervention) score,
 * every candidate intervention that was evaluated with its score, and
 * whichever one was selected as best (or `null` when no candidate beat
 * doing nothing).
 *
 * @returns {{
 *   baseline: {score: number},
 *   candidatesEvaluated: number,
 *   evaluations: Array<{intervention: object, score: number}>,
 *   best: {
 *     intervention: object|null,
 *     score: number,
 *     etas: Array<object>,
 *     conflicts: Array<object>
 *   },
 *   improved: boolean
 * }}
 */
export function getOptimizationResult() {
  // The base railway state is only ever read here — optimize()
  // (engine/optimization/optimizer.js) evaluates every candidate via
  // runWhatIfSimulation, which clones state.trains internally, so
  // INITIAL_TRAINS/RESOURCES are never mutated.
  const state = buildRailwayState();
  const outcome = optimize(state);

  return {
    baseline: outcome.baseline,
    candidatesEvaluated: outcome.candidatesEvaluated,
    evaluations: outcome.evaluations,
    best: {
      intervention: outcome.best.intervention,
      score: outcome.best.score,
      etas: outcome.best.result.etas,
      conflicts: outcome.best.result.conflicts,
    },
    improved: outcome.improved,
  };
}
