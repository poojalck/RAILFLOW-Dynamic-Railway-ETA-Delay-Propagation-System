// services/alertService.js
//
// PHASE 2 CHUNK 6 (ALERTS) — alerts are now generated from the current
// engine simulation:
//
//   Engine simulation -> conflicts + propagated delays -> alert
//   generation (engine/alertGenerator.js) -> GET /api/alerts
//
// This mirrors the exact pattern trainService.js already uses to connect
// to the engine: build the railway state from the existing static data
// (data/trains.js, data/network.js), run it through the engine
// orchestrator (simulateRailwayState, engine/index.js), and hand the
// result to the pure alert generator. No engine/alert algorithm lives in
// this file — it only assembles inputs and forwards outputs.
//
// Backwards compatibility: if the current simulation has nothing to
// report (no conflicts, no significant propagated delay), we fall back
// to the original static INITIAL_ALERTS seed rather than the endpoint
// silently going empty for every caller that still expects Phase 1's
// illustrative alert. Once the engine has something real to say, its
// output fully replaces the seed.

import { INITIAL_ALERTS } from '../data/alerts.js';
import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';
import { simulateRailwayState } from '../engine/index.js';
import { generateAlerts } from '../engine/alertGenerator.js';

/**
 * Build the railway state the engine needs from the existing static
 * data. Pure assembly only — no algorithm lives here. Identical shape to
 * trainService.js's buildRailwayState().
 * @returns {{trains: Array<object>, resources: Array<object>, findTrack: Function}}
 */
function buildRailwayState() {
  return {
    trains: INITIAL_TRAINS,
    resources: RESOURCES,
    findTrack,
  };
}

/**
 * Run the engine over the current railway state and convert its
 * conflict/delay output into alerts.
 * @returns {Array<object>} engine-generated alerts (may be empty).
 */
function computeEngineAlerts() {
  const state = buildRailwayState();
  const simulationResult = simulateRailwayState(state);
  return generateAlerts(simulationResult);
}

export function getAllAlerts() {
  const engineAlerts = computeEngineAlerts();
  if (engineAlerts.length > 0) {
    return engineAlerts;
  }
  // Nothing currently detected by the engine — fall back to the seed
  // alert(s) for backward compatibility rather than returning nothing.
  return INITIAL_ALERTS;
}
