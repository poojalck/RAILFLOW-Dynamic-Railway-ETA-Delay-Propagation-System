// utils/router.js
//
// A minimal, zero-dependency HTTP router built on Node's core `http` module.
//
// WHY NOT EXPRESS: Express would be the normal default here (see README),
// but this router intentionally avoids ANY npm dependency so the backend
// runs with nothing but `node server.js` — no `npm install` step, no
// version drift, no risk of a broken/offline registry. The API surface
// (app.get/app.post/app.use, req.params, req.query, req.body, res.json/
// res.status) deliberately mirrors Express so the code reads the same way
// and could be ported to real Express in five minutes if ever desired.
//
// Supported features:
//   - app.get(path, handler) / app.post(path, handler)
//   - path params: '/api/trains/:id' -> req.params.id
//   - query string parsing -> req.query
//   - JSON body parsing for POST/PUT -> req.body
//   - app.use(corsMiddleware) style global middleware (very small subset)
//   - res.json(obj), res.status(code), res.send(text)

import http from 'node:http';
import { URL } from 'node:url';

function compilePath(path) {
  const paramNames = [];
  const pattern = path
    .split('/')
    .filter(Boolean)
    .map((segment) => {
      if (segment.startsWith(':')) {
        paramNames.push(segment.slice(1));
        return '([^/]+)';
      }
      return segment.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    })
    .join('/');
  return { regex: new RegExp(`^/${pattern}/?$`), paramNames };
}

export function createApp() {
  const routes = { GET: [], POST: [] };
  const middlewares = [];

  const app = {
    use(mw) {
      middlewares.push(mw);
    },
    get(path, handler) {
      routes.GET.push({ ...compilePath(path), handler });
    },
    post(path, handler) {
      routes.POST.push({ ...compilePath(path), handler });
    },
    listen(port, cb) {
      const server = http.createServer((req, res) => handleRequest(req, res, routes, middlewares));
      return server.listen(port, cb);
    },
  };

  return app;
}

function send(res, status, body) {
  res.statusCode = status;
  if (body === undefined) {
    res.end();
    return;
  }
  const payload = typeof body === 'string' ? body : JSON.stringify(body, null, 2);
  res.setHeader('Content-Type', typeof body === 'string' ? 'text/plain' : 'application/json');
  res.end(payload);
}

async function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 5_000_000) {
        req.destroy();
        reject(new Error('Request body too large'));
      }
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch {
        reject(new Error('Invalid JSON body'));
      }
    });
    req.on('error', reject);
  });
}

async function handleRequest(req, res, routes, middlewares) {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const method = req.method === 'HEAD' ? 'GET' : req.method;

  res.json = (body) => send(res, res.statusCode && res.statusCode !== 200 ? res.statusCode : 200, body);
  res.status = (code) => {
    res.statusCode = code;
    return res;
  };
  res.send = (body) => send(res, res.statusCode || 200, body);

  for (const mw of middlewares) {
    let shortCircuited = false;
    await mw(req, res, () => {});
    if (res.writableEnded) shortCircuited = true;
    if (shortCircuited) return;
  }

  const candidates = routes[method] || [];
  for (const route of candidates) {
    const match = route.regex.exec(url.pathname);
    if (!match) continue;
    const params = {};
    route.paramNames.forEach((name, i) => {
      params[name] = decodeURIComponent(match[i + 1]);
    });
    req.params = params;
    req.query = Object.fromEntries(url.searchParams.entries());

    if (method === 'POST') {
      try {
        req.body = await readJsonBody(req);
      } catch (err) {
        return send(res, 400, { error: err.message });
      }
    }

    try {
      await route.handler(req, res);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error(`Unhandled error in ${method} ${url.pathname}:`, err);
      if (!res.writableEnded) send(res, 500, { error: 'Internal server error', message: err.message });
    }
    return;
  }

  send(res, 404, { error: `No route for ${method} ${url.pathname}` });
}

export function cors() {
  return (req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') {
      res.statusCode = 204;
      res.end();
      return;
    }
    next();
  };
}
