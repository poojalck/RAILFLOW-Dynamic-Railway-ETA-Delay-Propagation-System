// engine/whatIfComparison.js
//
// PHASE 2 CHUNK 12B — WHAT-IF RESULT COMPARISON.
//
// Pure: takes two EXISTING engine results (a base simulateRailwayState()
// result and a hypothetical runWhatIfSimulation() result — see
// engine/index.js and engine/whatIf.js) and reduces them to a small
// impact summary. This module contains NO scheduling/conflict/
// occupancy/delay/ETA algorithm of its own — it only reads the `etas`
// and `conflicts` fields both results already carry.
//
//   BASE RESULT
//         +
//   WHAT-IF RESULT
//         |
//       COMPARE            (this module)
//         |
//       IMPACT
//
// No API endpoint is wired up here — see services/simulationService.js
// and controllers/simulationController.js for the endpoint that calls
// this module.
//
// PHASE 2 CHUNK 19 FIX — `additionalDelay` below is computed from the
// absolute predicted arrival time of every train (`predictedETA`), not
// from each side's `totalDelay`. Reusing `totalDelay` alone breaks for
// any intervention that shifts the target train's OWN
// `scheduledDeparture` (a 'delay'/'hold' intervention, engine/whatIf.js) 
// because `totalDelay` is measured against that same run's
// `scheduledETA` (engine/etaCalculator.js) — which moves by the same
// amount, so the requested delay cancels itself out of the sum and only
// incidental conflict/propagation changes remain. Comparing
// `predictedETA` (an absolute clock time, unaffected by which run's
// schedule it came from) against the SAME base timetable for both sides
// fixes this: for the intervened train the difference is the requested
// delay plus any propagated change; for every other train it is the
// propagated change alone.

import { parseTime } from './timeUtils.js';

/**
 * Sum the total delay (minutes) carried across an entire fleet's ETAs.
 * Used as the network-wide delay figure for both the base and What-If
 * side of a comparison.
 *
 * @param {Array<{trainId:string, scheduledETA:string, predictedETA:string, totalDelay:number}>} etas -
 *   the `etas` array from a simulateRailwayState()/runWhatIfSimulation() result.
 * @returns {number} sum of every train's `totalDelay`.
 */
export function computeNetworkDelay(etas) {
  if (!Array.isArray(etas)) {
    throw new Error('computeNetworkDelay: etas must be an array');
  }
  return etas.reduce((sum, eta) => sum + (Number(eta.totalDelay) || 0), 0);
}

/**
 * Sum, across every train present in both ETA lists, the change in
 * absolute predicted arrival time (`predictedETA`, parsed to
 * minutes-since-midnight). Unlike `computeNetworkDelay`, this is stable
 * under a `scheduledDeparture` shift on the intervened train: that
 * train's own predicted arrival simply moves by the requested delay
 * (plus/minus whatever conflicts appear or clear), instead of that
 * delay being invisible because it also shifted the run's own
 * `scheduledETA` baseline.
 *
 * @param {Array<{trainId:string, predictedETA:string}>} baseEtas
 * @param {Array<{trainId:string, predictedETA:string}>} whatIfEtas
 * @returns {number} net change in total network arrival time (minutes).
 */
function computeNetArrivalImpact(baseEtas, whatIfEtas) {
  const baseMinutesByTrain = new Map(baseEtas.map((eta) => [eta.trainId, parseTime(eta.predictedETA)]));
  return whatIfEtas.reduce((sum, eta) => {
    const baseMinutes = baseMinutesByTrain.get(eta.trainId);
    if (baseMinutes === undefined) return sum; // train not present in base; nothing to compare
    return sum + (parseTime(eta.predictedETA) - baseMinutes);
  }, 0);
}

/**
 * Compare a base engine result against a What-If engine result and
 * produce the three required impact values.
 *
 * @param {{etas: Array<object>, conflicts: Array<object>}} baseResult -
 *   output of simulateRailwayState() over the real railway state.
 * @param {{etas: Array<object>, conflicts: Array<object>}} whatIfResult -
 *   output of runWhatIfSimulation() over the same state plus one
 *   hypothetical intervention.
 * @returns {{changedTrains: Array<string>, additionalDelay: number, conflictChange: number}}
 *   - changedTrains: train IDs whose predictedETA differs between the
 *     two results (id order follows whatIfResult.etas).
 *   - additionalDelay: net change in total network arrival time
 *     (whatIf predictedETAs minus base predictedETAs, summed across every
 *     train) — the real-world impact of the What-If scenario: the
 *     requested delay/hold itself plus any additional propagated impact
 *     from conflicts it causes or clears. Can be negative if the
 *     intervention improves things overall.
 *   - conflictChange: number of conflicts in whatIf minus number of
 *     conflicts in base. Can be negative.
 */
export function compareWhatIfResults(baseResult, whatIfResult) {
  if (!baseResult || !Array.isArray(baseResult.etas) || !Array.isArray(baseResult.conflicts)) {
    throw new Error('compareWhatIfResults: baseResult must have etas[] and conflicts[]');
  }
  if (!whatIfResult || !Array.isArray(whatIfResult.etas) || !Array.isArray(whatIfResult.conflicts)) {
    throw new Error('compareWhatIfResults: whatIfResult must have etas[] and conflicts[]');
  }

  const baseETAByTrain = new Map(baseResult.etas.map((eta) => [eta.trainId, eta.predictedETA]));

  const changedTrains = whatIfResult.etas
    .filter((eta) => baseETAByTrain.get(eta.trainId) !== eta.predictedETA)
    .map((eta) => eta.trainId);

  const additionalDelay = computeNetArrivalImpact(baseResult.etas, whatIfResult.etas);
  const conflictChange = whatIfResult.conflicts.length - baseResult.conflicts.length;

  return { changedTrains, additionalDelay, conflictChange };
}
