// engine/optimization/optimizer.js
//
// PHASE 2 CHUNK 13A — OPTIMIZATION FOUNDATION.
// PHASE 2 CHUNK 13B — COMPLETE OPTIMIZATION (search + selection), added
// below the CHUNK 13A section without modifying it.
//
// Pure: provides the small, reusable structure the optimization layer
// searches over — "given a candidate intervention, run it through the
// EXISTING What-If simulation and reduce the result to a single
// comparable score," and, per CHUNK 13B, "generate several candidates
// this way, evaluate every one, and pick whichever produces the lowest
// overall network delay." This module contains NO scheduling/conflict/
// occupancy/delay/ETA algorithm of its own — it only calls
// engine/whatIf.js (which itself only calls the unmodified engine
// orchestrator, engine/index.js), engine/whatIfComparison.js's existing
// network-delay reducer, and (for 13B) this package's own
// candidateGenerator.js.
//
//   BASE STATE
//        |
//   Generate candidate interventions   (candidateGenerator.js ->
//        |                              generateCandidates — reads the
//        |                              EXISTING engine's conflicts for
//        |                              baseState, proposes 'hold'/
//        |                              'priority' candidates)
//        |
//   Evaluate each candidate
//        |
//   Existing What-If simulation        (engine/whatIf.js ->
//        |                              runWhatIfSimulation, untouched)
//        |
//   Score each result                  (this module -> scoreResult,
//        |                              reusing computeNetworkDelay)
//        |
//   Select best intervention           (this module -> optimize)
//        |
//   Optimization result
//
// Scope (CHUNK 13A, unchanged): evaluateIntervention(...) runs ONE
// caller-supplied candidate through What-If and returns
// { intervention, result, score }; scoreResult(...) reduces an engine
// result to a single deterministic number (lower = better).
//
// Scope (CHUNK 13B, added below): optimize(...) generates candidates for
// a base state (via candidateGenerator.js), evaluates every one with the
// unchanged evaluateIntervention(...), and selects whichever produces the
// lowest score — falling back to "no intervention" when nothing beats the
// base state's own score. No new intervention types are introduced, no
// frontend/UI work is included, and the existing engine/What-If/13A code
// paths are reused as-is rather than re-implemented.
//
// Guarantees carried over from engine/whatIf.js (and relied on, not
// re-implemented, here): the base railway state is never mutated —
// runWhatIfSimulation() always operates on a deep clone of
// baseState.trains — and invalid intervention data is rejected by the
// existing validateIntervention()/InvalidInterventionError path before
// any simulation runs. CHUNK 13B's own candidate generation only ever
// proposes candidates built from real conflict data, so in practice they
// pass that same validation, but a candidate that somehow fails it is
// simply skipped during search (see optimize()) rather than aborting the
// whole search.

import { simulateRailwayState } from '../index.js';
import { runWhatIfSimulation, InvalidInterventionError } from '../whatIf.js';
import { computeNetworkDelay } from '../whatIfComparison.js';
import { generateCandidates } from './candidateGenerator.js';

// Re-exported so callers of this module don't need to reach into
// engine/whatIf.js separately just to catch validation failures.
export { InvalidInterventionError };

/**
 * Reduce a single engine result (base or What-If) to one deterministic
 * optimization score. Lower is better.
 *
 * For CHUNK 13A this is deliberately the simplest useful metric: total
 * network delay, in minutes, summed across every train's ETA — reusing
 * whatIfComparison.js's existing `computeNetworkDelay` rather than
 * re-deriving it here.
 *
 * @param {{etas: Array<{trainId:string, totalDelay:number}>}} result -
 *   output of simulateRailwayState() or runWhatIfSimulation().
 * @returns {number} the network delay score (minutes). Lower = better.
 */
export function scoreResult(result) {
  if (!result || !Array.isArray(result.etas)) {
    throw new Error('scoreResult: result.etas must be an array');
  }
  return computeNetworkDelay(result.etas);
}

/**
 * Evaluate a single candidate intervention against a base railway state:
 * run it through the existing What-If simulation and score the result.
 * `baseState` is never mutated (runWhatIfSimulation/applyIntervention
 * always operate on a deep clone of `baseState.trains`).
 *
 * This function intentionally evaluates exactly one candidate. Searching
 * across multiple candidates and/or selecting the best one is out of
 * scope for CHUNK 13A (see 13B).
 *
 * @param {object} candidate - a single What-If intervention, using one of
 *   the existing intervention types (see WHAT_IF_INTERVENTION_TYPES in
 *   engine/whatIf.js): { type: 'delay'|'hold', trainId, minutes } or
 *   { type: 'priority', trainId, priority }. No new intervention types
 *   are introduced by this module.
 * @param {{trains: Array<object>, resources: Array<object>, findTrack: Function}} baseState
 * @returns {{
 *   intervention: object,
 *   result: {events: Array<object>, occupancy: Array<object>, conflicts: Array<object>, propagatedDelays: object, etas: Array<object>},
 *   score: number
 * }}
 * @throws {InvalidInterventionError} if `candidate` fails the existing
 *   What-If validation (unknown type, unknown trainId, bad minutes/priority, etc).
 */
export function evaluateIntervention(candidate, baseState) {
  const result = runWhatIfSimulation(candidate, baseState);
  const score = scoreResult(result);
  return { intervention: candidate, result, score };
}

// ===========================================================================
// PHASE 2 CHUNK 13B — COMPLETE OPTIMIZATION (search across candidates and
// select the best one). Everything above this line is unmodified CHUNK 13A.
// ===========================================================================

// Floating-point-safe margin: a candidate must beat the current best score
// by more than this to be considered a genuine improvement, not noise from
// summing/rounding minutes across many trains.
const IMPROVEMENT_EPSILON = 1e-9;

/**
 * Run the EXISTING engine once over `baseState` and score that result the
 * same way any candidate's result is scored — i.e. the "do nothing" option
 * the search always compares every candidate against.
 *
 * @param {{trains: Array<object>, resources: Array<object>, findTrack: Function}} baseState
 * @returns {{result: object, score: number}}
 */
function evaluateBaseline(baseState) {
  const result = simulateRailwayState(baseState);
  return { result, score: scoreResult(result) };
}

/**
 * Evaluate every candidate intervention against `baseState`, reusing the
 * unmodified evaluateIntervention(...) for each one. A candidate that fails
 * What-If validation (InvalidInterventionError) is skipped rather than
 * aborting the whole search — candidateGenerator.js is not expected to ever
 * produce one, but a caller-supplied `candidates` list might.
 *
 * @param {Array<object>} candidates
 * @param {{trains: Array<object>, resources: Array<object>, findTrack: Function}} baseState
 * @returns {Array<{intervention: object, result: object, score: number}>}
 */
function evaluateAll(candidates, baseState) {
  const evaluations = [];
  for (const candidate of candidates) {
    try {
      evaluations.push(evaluateIntervention(candidate, baseState));
    } catch (err) {
      if (err instanceof InvalidInterventionError) continue;
      throw err;
    }
  }
  return evaluations;
}

/**
 * Select whichever evaluation has the lowest score, starting from a
 * "no intervention" baseline. Ties (within IMPROVEMENT_EPSILON) keep the
 * earliest-found option — which favors the baseline over any candidate,
 * and otherwise favors whichever candidate candidateGenerator.js listed
 * first — so results are deterministic and never prefer an intervention
 * that doesn't measurably help.
 *
 * @param {{intervention: null, result: object, score: number}} baseline
 * @param {Array<{intervention: object, result: object, score: number}>} evaluations
 * @returns {{intervention: object|null, result: object, score: number}}
 */
function selectBest(baseline, evaluations) {
  let best = baseline;
  for (const evaluation of evaluations) {
    if (evaluation.score < best.score - IMPROVEMENT_EPSILON) {
      best = evaluation;
    }
  }
  return best;
}

/**
 * Full CHUNK 13B optimization pass: generate candidate interventions for
 * `baseState` (candidateGenerator.js -> generateCandidates, reading the
 * EXISTING engine's conflicts), evaluate every one of them plus the
 * "no intervention" baseline (each via the unmodified evaluateIntervention/
 * simulateRailwayState), and select whichever produces the lowest overall
 * network delay.
 *
 * `baseState` is never mutated — every evaluation goes through
 * runWhatIfSimulation(), which always operates on a deep clone of
 * baseState.trains.
 *
 * @param {{trains: Array<object>, resources: Array<object>, findTrack: Function}} baseState
 * @param {{candidates?: Array<object>}} [options] - optional pre-supplied
 *   candidate list, to evaluate a caller's own interventions instead of
 *   (or in addition to needing) freshly generated ones. Defaults to
 *   generateCandidates(baseState, baseline.result).
 * @returns {{
 *   baseline: {score: number},
 *   candidatesEvaluated: number,
 *   evaluations: Array<{intervention: object, score: number}>,
 *   best: {intervention: object|null, result: object, score: number},
 *   improved: boolean
 * }}
 */
export function optimize(baseState, options = {}) {
  if (!baseState || !Array.isArray(baseState.trains)) {
    throw new Error('optimize: baseState.trains must be an array');
  }

  const baselineEval = evaluateBaseline(baseState);
  const baseline = { intervention: null, result: baselineEval.result, score: baselineEval.score };

  const candidates =
    Array.isArray(options.candidates) && options.candidates.length > 0
      ? options.candidates
      : generateCandidates(baseState, baselineEval.result);

  const evaluations = evaluateAll(candidates, baseState);
  const best = selectBest(baseline, evaluations);

  return {
    baseline: { score: baseline.score },
    candidatesEvaluated: evaluations.length,
    evaluations: evaluations.map((e) => ({ intervention: e.intervention, score: e.score })),
    best,
    improved: best.intervention !== null,
  };
}
