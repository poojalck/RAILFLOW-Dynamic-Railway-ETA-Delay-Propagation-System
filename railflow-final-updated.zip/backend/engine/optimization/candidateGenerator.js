// engine/optimization/candidateGenerator.js
//
// PHASE 2 CHUNK 13B — CANDIDATE GENERATION.
//
// Pure: looks at the EXISTING engine's conflict output for a base railway
// state (engine/index.js -> simulateRailwayState, untouched) and proposes
// a small set of candidate What-If interventions (engine/whatIf.js's
// existing vocabulary only — 'hold' and 'priority'; no new intervention
// type is introduced) that a caller could evaluate. This module contains
// NO scheduling/conflict/occupancy/delay/ETA algorithm of its own — it
// only reads `conflicts` and `propagatedDelays.delaysByTrain`, fields the
// engine already produces, and reads `train.priority`, a field the engine
// already reads.
//
//   BASE STATE
//        |
//   Run EXISTING engine ONCE        (engine/index.js -> simulateRailwayState,
//        |                           just to see its conflicts/delays —
//        |                           this is the same base result the
//        |                           caller would get from GET /api/simulation)
//        |
//   For each conflict, propose:
//        - hold each involved train long enough to clear the resource
//        - swap the two trains' priority (give the currently-delayed
//          train the other's precedence, and vice versa)
//        |
//   Candidate interventions (deduplicated)
//
// Completely generic and data-driven: it never branches on a specific
// train id, station id, or resource id — it only ever reads the trainIds
// a real conflict names.

import { simulateRailwayState } from '../index.js';

/**
 * How long (minutes) a 'hold' on `trainId` would need to be for it to
 * clear the conflict it's part of, per the engine's own delay-propagation
 * result. Falls back to 1 minute (the smallest valid `minutes` value —
 * see engine/whatIf.js's requirePositiveMinutes) when the engine did not
 * already compute a delay for this train (e.g. it's the higher-precedence
 * side of the conflict), since holding it at all still changes ordering
 * at the shared resource and is worth evaluating.
 *
 * @param {string} trainId
 * @param {Object<string, number>} delaysByTrain
 * @returns {number}
 */
function holdMinutesFor(trainId, delaysByTrain) {
  const computed = Number(delaysByTrain[trainId]) || 0;
  return computed > 0 ? computed : 1;
}

/**
 * Generate the 'priority' candidates for one conflicting pair: give each
 * train the other's current priority, so the pair's relative precedence
 * flips. If priority data is missing or already identical for both
 * trains, fall back to granting each one, in turn, one step of extra
 * precedence over the other (one less than the lower of the two
 * priorities present, clamped to the minimum valid value of 1 — see
 * engine/whatIf.js's validateIntervention).
 *
 * @param {string} idA
 * @param {string} idB
 * @param {Map<string, number>} priorityById
 * @returns {Array<object>} 0-2 'priority' intervention candidates
 */
function priorityCandidatesFor(idA, idB, priorityById) {
  const pA = priorityById.get(idA);
  const pB = priorityById.get(idB);
  const hasA = typeof pA === 'number';
  const hasB = typeof pB === 'number';

  if (hasA && hasB && pA !== pB) {
    // Swap: let the currently-lower-precedence train take the other's spot.
    return [
      { type: 'priority', trainId: idA, priority: pB },
      { type: 'priority', trainId: idB, priority: pA },
    ];
  }

  // Equal, or one/both missing: give each train, in turn, one step ahead
  // of whatever priority is present (defaulting to 2 so the result is
  // still >= 1 after the -1 step below).
  const basis = hasA ? pA : hasB ? pB : 2;
  const promoted = Math.max(1, basis - 1);
  return [
    { type: 'priority', trainId: idA, priority: promoted },
    { type: 'priority', trainId: idB, priority: promoted },
  ];
}

/**
 * Generate candidate What-If interventions for a base railway state, by
 * running the EXISTING engine once and proposing one 'hold' + one
 * 'priority' candidate per train per conflict it is involved in.
 *
 * @param {{trains: Array<object>, resources: Array<object>, findTrack: Function}} baseState
 * @param {{conflicts: Array<object>, propagatedDelays: {delaysByTrain: Object<string, number>}}} [baseResult] -
 *   optional pre-computed simulateRailwayState(baseState) result, to avoid
 *   running the engine twice when the caller already has one.
 * @returns {Array<{type: 'hold'|'priority', trainId: string, minutes?: number, priority?: number}>}
 *   deduplicated candidate interventions, using only existing What-If
 *   intervention types (see WHAT_IF_INTERVENTION_TYPES in engine/whatIf.js).
 */
export function generateCandidates(baseState, baseResult) {
  if (!baseState || !Array.isArray(baseState.trains)) {
    throw new Error('generateCandidates: baseState.trains must be an array');
  }

  const result = baseResult || simulateRailwayState(baseState);
  const conflicts = Array.isArray(result.conflicts) ? result.conflicts : [];
  const delaysByTrain = (result.propagatedDelays && result.propagatedDelays.delaysByTrain) || {};
  const priorityById = new Map(baseState.trains.map((t) => [t.id, t.priority]));

  const candidates = [];
  const seen = new Set();

  function add(candidate) {
    const key = JSON.stringify(candidate, Object.keys(candidate).sort());
    if (seen.has(key)) return;
    seen.add(key);
    candidates.push(candidate);
  }

  for (const conflict of conflicts) {
    if (!Array.isArray(conflict.trainIds) || conflict.trainIds.length !== 2) continue;
    const [idA, idB] = conflict.trainIds;

    add({ type: 'hold', trainId: idA, minutes: holdMinutesFor(idA, delaysByTrain) });
    add({ type: 'hold', trainId: idB, minutes: holdMinutesFor(idB, delaysByTrain) });

    for (const candidate of priorityCandidatesFor(idA, idB, priorityById)) {
      add(candidate);
    }
  }

  return candidates;
}
