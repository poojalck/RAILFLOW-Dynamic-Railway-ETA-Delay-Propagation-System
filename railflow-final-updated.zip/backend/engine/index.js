// engine/index.js
//
// PHASE 2 CHUNK 5 — engine orchestrator.
//
// Pure: wires together the already-completed pure engine modules into a
// single simulation pass, in the required pipeline order:
//
//   Railway State
//        |
//   Event Generation      (eventGenerator.js        -> generateAllEvents)
//        |
//   Resource Occupancy    (resourceOccupancy.js      -> computeResourceOccupancy)
//        |
//   Conflict Detection    (conflictDetector.js       -> detectConflicts)
//        |
//   Delay Propagation     (delayPropagation.js       -> computeConflictDelays)
//        |
//   ETA Calculation       (etaCalculator.js           -> computeFleetETAs)
//        |
//   Simulation Result
//
// This module contains NO scheduling/conflict/delay/ETA algorithms of
// its own — it only calls the existing modules in order and assembles
// their outputs into one structured result. Every existing module's
// input/output shape already composes cleanly with the next stage, so no
// compatibility shims were needed.
//
// Purity: `simulateRailwayState` takes the railway state as a plain
// argument (trains, resources, and a `findTrack` lookup function — the
// same dependency-injection style eventGenerator.js/etaCalculator.js
// already use) and returns a new result object. It never reads files,
// never touches an HTTP request/response, and never branches on a
// specific train id, station id, or resource id — it is agnostic to
// whatever fleet/network/state it is given.

import { generateAllEvents } from './eventGenerator.js';
import { computeResourceOccupancy } from './resourceOccupancy.js';
import { detectConflicts } from './conflictDetector.js';
import { computeConflictDelays } from './delayPropagation.js';
import { computeFleetETAs } from './etaCalculator.js';

/**
 * Run one full simulation pass over a railway state.
 *
 * @param {object} state - the railway state to simulate.
 * @param {Array<object>} state.trains - the fleet (each with `id`, `path`,
 *   `scheduledDeparture`, `stops`, `priority`, and optionally `delay`).
 * @param {Array<object>} state.resources - constrained resources (each
 *   with `id`, `capacity`, `headwaySeconds`, ...), e.g. RESOURCES from
 *   data/network.js.
 * @param {(fromStationId: string, toStationId: string) => ({id:string, travelMinutes:number}|null)} state.findTrack -
 *   resolves the track between two adjacent stations in a train's path;
 *   the only source of leg duration used anywhere downstream. e.g.
 *   `findTrack` from data/network.js.
 * @param {Object<string, number>} [state.existingDelays] - optional
 *   trainId -> minutes-of-delay-already-carried map, forwarded to
 *   delay propagation's `existingDelays` parameter. When omitted, each
 *   train's own `delay` field (used by etaCalculator) is still applied;
 *   this only affects how much of the *conflict-clearing* delay a train
 *   is treated as already carrying.
 *
 * @returns {{
 *   events: Array<object>,
 *   occupancy: Array<object>,
 *   conflicts: Array<object>,
 *   propagatedDelays: { perConflict: Array<object>, delaysByTrain: Object<string, number> },
 *   etas: Array<{trainId:string, scheduledETA:string, predictedETA:string, totalDelay:number}>
 * }}
 */
export function simulateRailwayState(state) {
  if (!state || typeof state !== 'object') {
    throw new Error('simulateRailwayState: state object is required');
  }
  const { trains, resources, findTrack, existingDelays = {} } = state;

  if (!Array.isArray(trains)) {
    throw new Error('simulateRailwayState: state.trains must be an array');
  }
  if (!Array.isArray(resources)) {
    throw new Error('simulateRailwayState: state.resources must be an array');
  }
  if (typeof findTrack !== 'function') {
    throw new Error('simulateRailwayState: state.findTrack must be a function');
  }

  // 1. Event generation --------------------------------------------------
  const events = generateAllEvents(trains, { findTrack });

  // 2. Resource occupancy -------------------------------------------------
  const occupancy = computeResourceOccupancy(events, resources, trains);

  // 3. Conflict detection ---------------------------------------------------
  const conflicts = detectConflicts(occupancy, resources);

  // 4. Delay propagation ------------------------------------------------------
  const propagatedDelays = computeConflictDelays({
    occupancies: occupancy,
    conflicts,
    resources,
    trains,
    existingDelays,
  });

  // 5. ETA calculation -----------------------------------------------------
  const etas = computeFleetETAs(trains, { findTrack }, propagatedDelays.delaysByTrain);

  // 6. Simulation result -----------------------------------------------------
  return {
    events,
    occupancy,
    conflicts,
    propagatedDelays,
    etas,
  };
}
