// engine/delayPropagation.js
//
// PHASE 2 CHUNK 3 — delay propagation, part 1: conflict resolution delay.
//
// Pure: given resource occupancy (from resourceOccupancy.js), detected
// conflicts (from conflictDetector.js), each resource's headway, each
// train's `priority`, and each train's existing (already-accumulated)
// delay, this module determines the ADDITIONAL delay a lower-priority
// train must absorb so that it stops competing for the resource with the
// higher-priority train it conflicted with.
//
// Convention (matches data/trains.js): a LOWER `priority` number means
// HIGHER operational precedence. When two trains conflict over the same
// resource, the higher-precedence (lower-number) train keeps its
// schedule; the other train is pushed back until the resource is safely
// free — i.e. until the higher-precedence train's occupancy has ended
// AND the resource's required `headwaySeconds` safety margin has
// elapsed.
//
// This module does NOT:
//   - call any ETA/API integration
//   - re-run event generation or re-detect conflicts after applying a
//     delay (no cascading/iterative resolution yet — that is future work)
//   - optimize schedules or run what-if scenarios
//
// It is completely generic and data-driven: nothing here branches on a
// specific train id, station id, or resource id. Swap in a different
// fleet/network and the same code still works.

/**
 * Convert a resource's headwaySeconds into minutes (the engine's
 * scheduling-authority unit, matching timeUtils.js / conflictDetector.js).
 * @param {object} resource
 * @returns {number}
 */
function headwayMinutes(resource) {
  const seconds = Number(resource && resource.headwaySeconds) || 0;
  return seconds / 60;
}

/**
 * Find the occupancy record for a given (resourceId, trainId) pair that
 * is relevant to a specific conflict window. If a train has more than
 * one occupancy on the same resource (e.g. it passes through it twice),
 * we pick the occupancy whose window intersects the conflict's
 * [startMinutes, endMinutes] span; falling back to the first match keeps
 * this well-defined even for a single occupancy.
 * @param {Array<object>} occupancies
 * @param {string} resourceId
 * @param {string} trainId
 * @param {{startMinutes:number, endMinutes:number}} conflictWindow
 * @returns {object|null}
 */
function findRelevantOccupancy(occupancies, resourceId, trainId, conflictWindow) {
  const candidates = occupancies.filter(
    (o) => o.resourceId === resourceId && o.trainId === trainId
  );
  if (candidates.length === 0) return null;
  if (candidates.length === 1) return candidates[0];

  const overlapping = candidates.find(
    (o) => o.startMinutes < conflictWindow.endMinutes && conflictWindow.startMinutes < o.endMinutes
  );
  return overlapping || candidates[0];
}

/**
 * Decide, for a single conflict, which of the two trains has operational
 * precedence and which must be delayed. Ties (equal priority, or missing
 * priority data) fall back to a deterministic, non-train-specific rule
 * (whichever occupancy starts earlier keeps precedence), so behavior
 * stays fully defined without hardcoding any particular id.
 * @param {[string,string]} trainIds
 * @param {Map<string, number>} priorityById
 * @param {Map<string, object>} occupancyById - trainId -> its occupancy for this conflict
 * @returns {{higherId:string, lowerId:string}}
 */
function resolvePrecedence(trainIds, priorityById, occupancyById) {
  const [idA, idB] = trainIds;
  const pA = priorityById.get(idA);
  const pB = priorityById.get(idB);

  const hasPriorityA = typeof pA === 'number';
  const hasPriorityB = typeof pB === 'number';

  if (hasPriorityA && hasPriorityB && pA !== pB) {
    return pA < pB ? { higherId: idA, lowerId: idB } : { higherId: idB, lowerId: idA };
  }
  if (hasPriorityA && !hasPriorityB) return { higherId: idA, lowerId: idB };
  if (hasPriorityB && !hasPriorityA) return { higherId: idB, lowerId: idA };

  // Equal (or both-missing) priority: fall back to whichever occupancy
  // is scheduled to start first — it was there first, so it keeps the
  // resource.
  const occA = occupancyById.get(idA);
  const occB = occupancyById.get(idB);
  if (occA && occB && occA.startMinutes !== occB.startMinutes) {
    return occA.startMinutes < occB.startMinutes ? { higherId: idA, lowerId: idB } : { higherId: idB, lowerId: idA };
  }
  // Fully tied: stable, deterministic fallback that is not tied to any
  // specific id's identity (just a total order on whatever ids are
  // present), so results are reproducible without favoring a "named" train.
  return idA < idB ? { higherId: idA, lowerId: idB } : { higherId: idB, lowerId: idA };
}

/**
 * Compute the additional delay each lower-precedence train must absorb
 * to resolve the resource conflicts it is involved in.
 *
 * @param {object} params
 * @param {Array<object>} params.occupancies - output of computeResourceOccupancy
 *   (resourceId, trainId, startMinutes, endMinutes, ...).
 * @param {Array<object>} params.conflicts - output of detectConflicts
 *   (resourceId, trainIds, startTime, endTime, severity, reason). Only
 *   `resourceId` and `trainIds` are used for resolution; `startTime`/
 *   `endTime` are used only to disambiguate which occupancy a conflict
 *   refers to when a train occupies the same resource more than once.
 * @param {Array<object>} params.resources - RESOURCES from data/network.js
 *   (id, headwaySeconds, ...), used to size the required safety margin.
 * @param {Array<object>} params.trains - trains with `id` and `priority`
 *   (lower number = higher precedence).
 * @param {Object<string, number>} [params.existingDelays] - trainId ->
 *   minutes of delay the train already carries coming into this
 *   resolution pass. Defaults to 0 for any train not present.
 *
 * @returns {{
 *   perConflict: Array<{resourceId:string, delayedTrainId:string, precedingTrainId:string,
 *     additionalDelayMinutes:number, requiredStartMinutes:number, reason:string}>,
 *   delaysByTrain: Object<string, number>
 * }}
 */
export function computeConflictDelays({ occupancies, conflicts, resources, trains, existingDelays = {} }) {
  if (!Array.isArray(occupancies) || !Array.isArray(conflicts) || !Array.isArray(resources) || !Array.isArray(trains)) {
    throw new Error('computeConflictDelays: occupancies, conflicts, resources, and trains must all be arrays');
  }

  const resourceById = new Map(resources.map((r) => [r.id, r]));
  const priorityById = new Map(trains.map((t) => [t.id, t.priority]));

  const perConflict = [];
  const delaysByTrain = {};

  for (const conflict of conflicts) {
    const conflictWindow = {
      startMinutes:
        typeof conflict.startMinutes === 'number' ? conflict.startMinutes : null,
      endMinutes: typeof conflict.endMinutes === 'number' ? conflict.endMinutes : null,
    };
    // conflictDetector output carries startTime/endTime strings, not raw
    // minutes; fall back to a window derived from the two occupancies
    // themselves when minutes aren't directly present on the conflict.
    const rawOccupancyById = new Map();
    for (const trainId of conflict.trainIds) {
      const occ = occupancies.find((o) => o.resourceId === conflict.resourceId && o.trainId === trainId);
      if (occ) rawOccupancyById.set(trainId, occ);
    }
    if (conflictWindow.startMinutes === null || conflictWindow.endMinutes === null) {
      const starts = [...rawOccupancyById.values()].map((o) => o.startMinutes);
      const ends = [...rawOccupancyById.values()].map((o) => o.endMinutes);
      conflictWindow.startMinutes = starts.length ? Math.min(...starts) : 0;
      conflictWindow.endMinutes = ends.length ? Math.max(...ends) : 0;
    }

    const occupancyById = new Map();
    for (const trainId of conflict.trainIds) {
      const occ = findRelevantOccupancy(occupancies, conflict.resourceId, trainId, conflictWindow);
      if (occ) occupancyById.set(trainId, occ);
    }
    if (occupancyById.size < 2) continue; // can't resolve without both trains' occupancy windows

    const { higherId, lowerId } = resolvePrecedence(conflict.trainIds, priorityById, occupancyById);
    const higherOcc = occupancyById.get(higherId);
    const lowerOcc = occupancyById.get(lowerId);
    const resource = resourceById.get(conflict.resourceId);
    const requiredGapMinutes = headwayMinutes(resource);

    // The lower-precedence train may not enter the resource until the
    // higher-precedence train has released it AND the safety headway has
    // elapsed.
    const requiredStartMinutes = higherOcc.endMinutes + requiredGapMinutes;

    const existingDelayForLower = Number(existingDelays[lowerId]) || 0;
    const effectiveStartMinutes = lowerOcc.startMinutes + existingDelayForLower;

    const additionalDelayMinutes = Math.max(0, requiredStartMinutes - effectiveStartMinutes);

    perConflict.push({
      resourceId: conflict.resourceId,
      delayedTrainId: lowerId,
      precedingTrainId: higherId,
      additionalDelayMinutes,
      requiredStartMinutes,
      reason:
        additionalDelayMinutes > 0
          ? `${lowerId} must wait for ${higherId} to clear ${conflict.resourceId} (incl. headway) before proceeding`
          : `${lowerId} already clears ${conflict.resourceId} after ${higherId} with sufficient headway`,
    });

    if (additionalDelayMinutes > 0) {
      delaysByTrain[lowerId] = Math.max(delaysByTrain[lowerId] || 0, additionalDelayMinutes);
    }
  }

  return { perConflict, delaysByTrain };
}

/**
 * Convenience accessor: the additional delay (minutes) computed for a
 * given train, or 0 if that train was not delayed.
 * @param {{delaysByTrain: Object<string, number>}} result - output of computeConflictDelays
 * @param {string} trainId
 * @returns {number}
 */
export function getAdditionalDelayMinutes(result, trainId) {
  return (result && result.delaysByTrain && result.delaysByTrain[trainId]) || 0;
}
