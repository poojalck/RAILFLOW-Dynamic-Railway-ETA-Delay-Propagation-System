// engine/resourceStateBuilder.js
//
// PHASE 2 CHUNK 8 (NETWORK STATE) — pure resource-state aggregation.
//
//   Engine simulation
//        |
//   Resource occupancy + Conflicts   (resourceOccupancy.js / conflictDetector.js,
//        |                            already assembled by engine/index.js)
//        |
//   Resource-state aggregation        (this module)
//        |
//   GET /api/network -> resourceState (services/networkService.js)
//
// Pure: takes the network's static `resources` list plus the `occupancy`
// and `conflicts` shapes already produced by the engine (see
// engine/index.js -> simulateRailwayState) and derives, for each
// resource, a simple summary of its current schedule state:
//
//   - 'conflict'  -> the resource has at least one detected conflict.
//   - 'occupied'  -> no conflict, but at least one train occupies it.
//   - 'available' -> no occupancy at all.
//
// This module contains NO occupancy/conflict algorithm of its own — it
// only groups records that already exist by `resourceId` and reads their
// length. Fully generic/data-driven: nothing here branches on a specific
// train id, station id, or resource id. Swap in a different fleet/
// network and the same code still works.

/**
 * Group a list of records (occupancy or conflicts) by their resourceId.
 * @param {Array<{resourceId: string}>} records
 * @returns {Map<string, Array<object>>}
 */
function groupByResourceId(records) {
  const map = new Map();
  for (const record of records) {
    if (!map.has(record.resourceId)) map.set(record.resourceId, []);
    map.get(record.resourceId).push(record);
  }
  return map;
}

/**
 * Derive the status for one resource from its own occupancy/conflict
 * records. A conflict always takes precedence over mere occupancy.
 * @param {Array<object>} resourceOccupancies
 * @param {Array<object>} resourceConflicts
 * @returns {'available'|'occupied'|'conflict'}
 */
function statusFor(resourceOccupancies, resourceConflicts) {
  if (resourceConflicts.length > 0) return 'conflict';
  if (resourceOccupancies.length > 0) return 'occupied';
  return 'available';
}

/**
 * Collect the sorted, de-duplicated set of trainIds relevant to a
 * resource: every train that occupies it, plus every train named in one
 * of its conflicts (covers the rare case a conflict references an
 * occupancy this resource's own record set didn't otherwise surface).
 * @param {Array<{trainId: string}>} resourceOccupancies
 * @param {Array<{trainIds: string[]}>} resourceConflicts
 * @returns {string[]}
 */
function trainIdsFor(resourceOccupancies, resourceConflicts) {
  const ids = new Set();
  for (const occ of resourceOccupancies) ids.add(occ.trainId);
  for (const conflict of resourceConflicts) {
    for (const trainId of conflict.trainIds) ids.add(trainId);
  }
  return [...ids].sort();
}

/**
 * Build a lightweight, structured conflict summary for a resource, or
 * `null` when the resource has no conflicts. Kept intentionally simple —
 * just enough for future frontend visualization — rather than dumping
 * the full conflictDetector.js record shape.
 * @param {Array<object>} resourceConflicts
 * @returns {Array<{trainIds:string[], severity?:string, reason?:string}>|null}
 */
function conflictSummaryFor(resourceConflicts) {
  if (resourceConflicts.length === 0) return null;
  return resourceConflicts.map((c) => ({
    trainIds: [...c.trainIds],
    severity: c.severity,
    reason: c.reason,
  }));
}

/**
 * Build the per-resource state summary for the network endpoint.
 *
 * @param {object} params
 * @param {Array<{id:string}>} params.resources - RESOURCES from
 *   data/network.js (the full static resource list; every resource gets
 *   an entry, including ones with no current occupancy/conflict).
 * @param {Array<{resourceId:string, trainId:string}>} [params.occupancy] -
 *   output of resourceOccupancy.js's computeResourceOccupancy.
 * @param {Array<{resourceId:string, trainIds:string[], severity?:string, reason?:string}>} [params.conflicts] -
 *   output of conflictDetector.js's detectConflicts.
 *
 * @returns {Array<{resourceId:string, status:'available'|'occupied'|'conflict',
 *   trainIds:string[], conflict: Array<object>|null}>}
 */
export function buildResourceStates({ resources, occupancy = [], conflicts = [] }) {
  if (!Array.isArray(resources)) {
    throw new Error('buildResourceStates: resources must be an array');
  }

  const occupancyByResource = groupByResourceId(occupancy);
  const conflictsByResource = groupByResourceId(conflicts);

  return resources.map((resource) => {
    const resourceOccupancies = occupancyByResource.get(resource.id) || [];
    const resourceConflicts = conflictsByResource.get(resource.id) || [];

    return {
      resourceId: resource.id,
      status: statusFor(resourceOccupancies, resourceConflicts),
      trainIds: trainIdsFor(resourceOccupancies, resourceConflicts),
      conflict: conflictSummaryFor(resourceConflicts),
    };
  });
}
