// engine/etaCalculator.js
//
// PHASE 2 CHUNK 4 — ETA calculation.
//
// Pure: computes each train's scheduled and predicted arrival time at
// the end of its `path`, by reusing the existing engine building blocks
// rather than re-deriving timing logic:
//   - eventGenerator.js walks scheduledDeparture + track.travelMinutes +
//     stops[].dwellMinutes along the path and produces the chronological
//     event list (its FINAL_ARRIVAL event is the scheduled arrival).
//   - timeUtils.js formats/parses "HH:MM" <-> minutes-since-midnight.
//
// This module adds exactly one new thing on top of that: applying delay
// (the train's existing/original `delay`, plus any additional delay
// produced by delayPropagation.js for this train) to shift the scheduled
// arrival into a predicted arrival.
//
// scheduledETA  = time of the FINAL_ARRIVAL event from generateTrainEvents
//                 (i.e. scheduledDeparture + sum(travelMinutes) +
//                 sum(dwellMinutes) along the path, undelayed).
// totalDelay    = train.delay (existing/original delay, minutes) +
//                 additionalDelayMinutes (from delay-propagation, minutes)
// predictedETA  = scheduledETA + totalDelay
//
// This module does NOT re-run conflict detection or delay propagation
// itself — it takes their output (a per-train additional-delay number)
// as an input, so it stays a small, single-purpose step. It does not
// call any ETA API, optimize schedules, or run what-if scenarios.
//
// Fully generic and data-driven: no train id, station id, or resource id
// is ever referenced by name. Works for any path length (including a
// direct 2-station path) and any number of stops.

import { generateTrainEvents, EVENT_TYPES } from './eventGenerator.js';
import { formatTime } from './timeUtils.js';

/**
 * Find the event marking a train's scheduled (undelayed) arrival at the
 * end of its path. generateTrainEvents always emits exactly one
 * FINAL_ARRIVAL event, as the last event in its chronological output,
 * regardless of path length or number of stops.
 * @param {Array<object>} events - output of generateTrainEvents
 * @returns {object}
 */
function findFinalArrivalEvent(events) {
  const finalArrival = events.find((e) => e.type === EVENT_TYPES.FINAL_ARRIVAL);
  if (!finalArrival) {
    throw new Error('etaCalculator: generated events did not contain a FINAL_ARRIVAL event');
  }
  return finalArrival;
}

/**
 * Compute the scheduled and predicted ETA for a single train.
 *
 * @param {object} train - must have `id`, `path` (>=2 station ids),
 *   `scheduledDeparture` ("HH:MM"), `stops` (array of
 *   { stationId, dwellMinutes }, may be empty), and optionally `delay`
 *   (minutes of existing/original delay already carried by the train;
 *   defaults to 0 when absent).
 * @param {object} deps
 * @param {(fromStationId: string, toStationId: string) => ({id:string, travelMinutes:number}|null)} deps.findTrack -
 *   the ONLY source of leg duration, same contract as eventGenerator.js.
 *   `train.speed` is never used.
 * @param {number} [additionalDelayMinutes] - extra delay for this train
 *   produced by delayPropagation.js's `computeConflictDelays`
 *   (delaysByTrain[train.id], or 0 if that train wasn't delayed).
 * @returns {{trainId:string, scheduledETA:string, predictedETA:string, totalDelay:number}}
 */
export function computeTrainETA(train, { findTrack }, additionalDelayMinutes = 0) {
  if (!train || typeof train.id === 'undefined') {
    throw new Error('computeTrainETA: train.id is required');
  }

  const events = generateTrainEvents(train, { findTrack });
  const finalArrival = findFinalArrivalEvent(events);

  const existingDelayMinutes = Number(train.delay) || 0;
  const propagatedDelayMinutes = Number(additionalDelayMinutes) || 0;
  const totalDelay = existingDelayMinutes + propagatedDelayMinutes;

  const predictedMinutes = finalArrival.minutes + totalDelay;

  return {
    trainId: train.id,
    scheduledETA: finalArrival.time,
    predictedETA: formatTime(predictedMinutes),
    totalDelay,
  };
}

/**
 * Compute ETAs for a whole fleet at once.
 *
 * @param {Array<object>} trains
 * @param {object} deps
 * @param {(fromStationId: string, toStationId: string) => object|null} deps.findTrack
 * @param {Object<string, number>} [delaysByTrain] - trainId -> additional
 *   delay minutes, typically `delaysByTrain` from
 *   delayPropagation.js's `computeConflictDelays` result. Trains not
 *   present in this map are treated as having zero additional delay.
 * @returns {Array<{trainId:string, scheduledETA:string, predictedETA:string, totalDelay:number}>}
 */
export function computeFleetETAs(trains, { findTrack }, delaysByTrain = {}) {
  return trains.map((train) =>
    computeTrainETA(train, { findTrack }, delaysByTrain[train.id] || 0)
  );
}
