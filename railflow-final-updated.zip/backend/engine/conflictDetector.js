// engine/conflictDetector.js
//
// PHASE 2 CHUNK 2 — resource conflict detection.
//
// Pure: takes occupancy records already produced by resourceOccupancy.js
// (see computeResourceOccupancy) plus the network's resource definitions
// (backend/data/network.js), and reports where two or more trains
// legitimately compete for the same constrained resource — either by
// overlapping in time while the resource is at/over capacity, or by
// leaving less than the resource's required `headwaySeconds` safety
// margin between one occupancy ending and the next beginning.
//
// This module is completely generic and data-driven: it groups purely by
// `resourceId` and compares numeric time windows (`startMinutes` /
// `endMinutes`). It never branches on a specific train id, station id, or
// resource id — swap in a different fleet/network and the same code
// still works.

/**
 * Group occupancy records by resourceId, each list sorted by start time.
 * @param {Array<object>} occupancies
 * @returns {Map<string, Array<object>>}
 */
function groupByResource(occupancies) {
  const map = new Map();
  for (const occ of occupancies) {
    if (!map.has(occ.resourceId)) map.set(occ.resourceId, []);
    map.get(occ.resourceId).push(occ);
  }
  for (const list of map.values()) {
    list.sort((a, b) => a.startMinutes - b.startMinutes);
  }
  return map;
}

/**
 * Convert a resource's headwaySeconds into minutes (the engine's
 * scheduling-authority unit). Missing/zero headway simply means no extra
 * safety margin is required beyond the raw occupancy window.
 * @param {object} resource
 * @returns {number}
 */
function headwayMinutes(resource) {
  const seconds = Number(resource.headwaySeconds) || 0;
  return seconds / 60;
}

/**
 * How many trains are simultaneously present at a given instant in time,
 * given a sorted list of occupancy intervals for one resource. Uses a
 * half-open [start, end) sweep so back-to-back occupancies that merely
 * touch do not count as overlapping.
 * @param {Array<object>} sortedOccupancies
 * @returns {number} the maximum number of concurrent occupancies observed
 */
function maxConcurrency(sortedOccupancies) {
  const points = [];
  for (const occ of sortedOccupancies) {
    points.push({ time: occ.startMinutes, delta: 1 });
    points.push({ time: occ.endMinutes, delta: -1 });
  }
  // Process releases (-1) before entries (+1) at an identical instant, so
  // an occupancy that ends exactly when another begins does not appear as
  // simultaneous.
  points.sort((a, b) => a.time - b.time || a.delta - b.delta);

  let current = 0;
  let max = 0;
  for (const p of points) {
    current += p.delta;
    if (current > max) max = current;
  }
  return max;
}

/**
 * Find every pair of occupancies on the same resource whose windows
 * overlap directly (a half-open [start, end) overlap — merely touching
 * does not count).
 * @param {Array<object>} sortedOccupancies
 * @returns {Array<[object, object]>}
 */
function findOverlappingPairs(sortedOccupancies) {
  const pairs = [];
  for (let i = 0; i < sortedOccupancies.length; i++) {
    for (let j = i + 1; j < sortedOccupancies.length; j++) {
      const a = sortedOccupancies[i];
      const b = sortedOccupancies[j];
      if (a.startMinutes < b.endMinutes && b.startMinutes < a.endMinutes) {
        pairs.push([a, b]);
      }
    }
  }
  return pairs;
}

/**
 * Find every pair of occupancies on the same resource that do NOT
 * overlap directly, but whose gap (the time between one ending and the
 * next beginning) is smaller than the resource's required headway.
 * @param {Array<object>} sortedOccupancies
 * @param {number} minGapMinutes
 * @returns {Array<[object, object, number]>} pairs plus the observed gap
 */
function findHeadwayViolations(sortedOccupancies, minGapMinutes) {
  if (minGapMinutes <= 0) return [];
  const violations = [];
  // Sorted by start time; for headway purposes we only need to compare
  // each occupancy against the ones immediately following it in time,
  // since a violated gap against a later occupancy implies a smaller (or
  // equal) gap against the nearer one wouldn't hold in general — so we
  // still check all forward pairs to be safe and fully generic.
  for (let i = 0; i < sortedOccupancies.length; i++) {
    for (let j = i + 1; j < sortedOccupancies.length; j++) {
      const a = sortedOccupancies[i];
      const b = sortedOccupancies[j];
      // Skip pairs that already directly overlap; those are reported as
      // capacity conflicts, not headway violations.
      if (a.startMinutes < b.endMinutes && b.startMinutes < a.endMinutes) continue;

      const gap =
        a.endMinutes <= b.startMinutes
          ? b.startMinutes - a.endMinutes
          : a.startMinutes - b.endMinutes;

      if (gap < minGapMinutes) {
        violations.push([a, b, gap]);
      }
    }
  }
  return violations;
}

function pairKey(occA, occB) {
  return [occA.trainId, occB.trainId].sort().join('|');
}

/**
 * Detect resource conflicts from occupancy data.
 *
 * @param {Array<object>} occupancies - output of computeResourceOccupancy
 *   (each record must have resourceId, trainId, startTime, endTime,
 *   startMinutes, endMinutes).
 * @param {Array<object>} resources - RESOURCES from data/network.js (id,
 *   capacity, headwaySeconds, ...).
 * @returns {Array<{resourceId:string, trainIds:string[], startTime:string,
 *   endTime:string, severity:string, reason:string}>}
 */
export function detectConflicts(occupancies, resources) {
  if (!Array.isArray(occupancies) || !Array.isArray(resources)) {
    throw new Error('detectConflicts: occupancies and resources must both be arrays');
  }

  const resourceById = new Map(resources.map((r) => [r.id, r]));
  const grouped = groupByResource(occupancies);
  const conflicts = [];

  for (const [resourceId, sortedOccupancies] of grouped) {
    const resource = resourceById.get(resourceId);
    if (!resource) continue; // occupancy references an unknown resource; nothing to check it against
    if (sortedOccupancies.length < 2) continue; // a single train can't conflict with itself

    const capacity = Number.isFinite(resource.capacity) ? resource.capacity : 1;
    const minGapMinutes = headwayMinutes(resource);

    // --- Capacity conflicts: overlap pushes concurrency above capacity ---
    if (maxConcurrency(sortedOccupancies) > capacity) {
      for (const [a, b] of findOverlappingPairs(sortedOccupancies)) {
        if (a.trainId === b.trainId) continue; // never a real conflict with itself
        conflicts.push({
          resourceId,
          trainIds: [a.trainId, b.trainId].sort(),
          startTime: a.startMinutes <= b.startMinutes ? a.startTime : b.startTime,
          endTime: a.endMinutes >= b.endMinutes ? a.endTime : b.endTime,
          severity: 'capacity',
          reason: `resource capacity is ${capacity} but ${a.trainId} and ${b.trainId} overlap on it`,
        });
      }
    }

    // --- Headway conflicts: gap between occupancies is below the ---
    // --- resource's required safety margin.                      ---
    for (const [a, b, gapMinutes] of findHeadwayViolations(sortedOccupancies, minGapMinutes)) {
      if (a.trainId === b.trainId) continue;
      const first = a.endMinutes <= b.startMinutes ? a : b;
      const second = first === a ? b : a;
      conflicts.push({
        resourceId,
        trainIds: [a.trainId, b.trainId].sort(),
        startTime: first.startTime,
        endTime: second.endTime,
        severity: 'headway',
        reason: `only ${gapMinutes.toFixed(2)} min between occupancies but ${minGapMinutes.toFixed(2)} min headway is required`,
      });
    }
  }

  // De-duplicate: the same train pair could otherwise appear more than
  // once for the same resource (e.g. multiple overlap combinations). Keep
  // the first (capacity conflicts are pushed before headway ones above,
  // and capacity is the more severe finding for a given pair+resource).
  const seen = new Set();
  const deduped = [];
  for (const c of conflicts) {
    const key = `${c.resourceId}|${pairKey({ trainId: c.trainIds[0] }, { trainId: c.trainIds[1] })}|${c.severity}`;
    if (seen.has(key)) continue;
    seen.add(key);
    deduped.push(c);
  }

  deduped.sort((a, b) => a.resourceId.localeCompare(b.resourceId) || a.startTime.localeCompare(b.startTime));
  return deduped;
}
