// engine/whatIf.js
//
// PHASE 2 CHUNK 12A — WHAT-IF BACKEND CORE.
//
// Pure: applies a single hypothetical intervention to a CLONE of a
// railway state and runs it through the EXISTING engine orchestrator
// (engine/index.js -> simulateRailwayState). This module contains NO
// scheduling/conflict/occupancy/delay/ETA algorithm of its own — it
// only reshapes the same input fields the existing engine already reads
// (`scheduledDeparture`, `priority`), then hands the modified state to
// the unmodified engine.
//
//   Base Railway State
//        |
//   Clone state              (this module — trains only, deep clone)
//        |
//   Apply hypothetical intervention   (this module — edits the clone)
//        |
//   Run EXISTING engine       (engine/index.js -> simulateRailwayState,
//        |                     untouched — conflict detection, resource
//        |                     occupancy, delay propagation, timing, and
//        |                     ETA calculation all come from there)
//        |
//   What-If engine result
//
// No API endpoint is wired up in this chunk — see CHUNK 12A scope. This
// module is called directly (by tests now, by a service/controller in a
// later chunk).

import { parseTime, formatTime } from './timeUtils.js';
import { simulateRailwayState } from './index.js';

export const WHAT_IF_INTERVENTION_TYPES = Object.freeze(['delay', 'hold', 'priority']);

/**
 * Thrown for any invalid intervention. Kept as its own class (matching
 * the project's existing style of throwing plain `Error`s with a
 * descriptive message from validation code, e.g. engine/index.js,
 * eventGenerator.js) so callers can distinguish "bad input" from an
 * unexpected engine failure.
 */
export class InvalidInterventionError extends Error {
  constructor(message) {
    super(message);
    this.name = 'InvalidInterventionError';
  }
}

function isFiniteNumber(value) {
  return typeof value === 'number' && Number.isFinite(value);
}

function requireTrain(trains, trainId) {
  if (typeof trainId !== 'string' || trainId.length === 0) {
    throw new InvalidInterventionError('intervention.trainId is required and must be a non-empty string');
  }
  const train = trains.find((t) => t.id === trainId);
  if (!train) {
    throw new InvalidInterventionError(`intervention.trainId '${trainId}' does not match any known train`);
  }
  return train;
}

function requirePositiveMinutes(minutes) {
  if (!isFiniteNumber(minutes) || minutes <= 0) {
    throw new InvalidInterventionError('intervention.minutes must be a positive, finite number');
  }
  return minutes;
}

/**
 * Validate an intervention description against a railway state, without
 * applying it or mutating anything.
 *
 * @param {object} intervention
 * @param {{trains: Array<object>}} state - a railway state (e.g. the
 *   `{ trains, resources, findTrack }` shape engine/index.js already
 *   expects). Only `state.trains` is inspected here.
 */
export function validateIntervention(intervention, state) {
  if (!intervention || typeof intervention !== 'object' || Array.isArray(intervention)) {
    throw new InvalidInterventionError('intervention must be an object');
  }
  if (!state || !Array.isArray(state.trains)) {
    throw new InvalidInterventionError('validateIntervention: state.trains must be an array');
  }

  const { type } = intervention;
  if (!WHAT_IF_INTERVENTION_TYPES.includes(type)) {
    throw new InvalidInterventionError(
      `intervention.type must be one of: ${WHAT_IF_INTERVENTION_TYPES.join(', ')} (got ${JSON.stringify(type)})`
    );
  }

  // Every supported intervention targets exactly one train, found
  // generically by id — never hardcoded.
  requireTrain(state.trains, intervention.trainId);

  if (type === 'delay' || type === 'hold') {
    requirePositiveMinutes(intervention.minutes);
    return;
  }

  // type === 'priority'
  const { priority } = intervention;
  // Matches data/trains.js's convention: priority is a positive integer,
  // where 1 = highest operational precedence (see
  // engine/delayPropagation.js's resolvePrecedence, which reads this
  // same field). No specific numeric range is hardcoded — only that it
  // is a valid priority value under that convention.
  if (!Number.isInteger(priority) || priority < 1) {
    throw new InvalidInterventionError('intervention.priority must be a positive integer (1 = highest precedence)');
  }
}

/**
 * Apply a validated intervention to a CLONE of the given railway state's
 * trains, leaving the original `state` (and its `trains` array/objects)
 * completely untouched.
 *
 * - 'delay' and 'hold' both shift the train's `scheduledDeparture`
 *   forward by `minutes`. `scheduledDeparture` is the single timing
 *   input engine/eventGenerator.js walks forward from, so shifting it
 *   is enough to make the entire downstream pipeline (events,
 *   occupancy, conflicts, propagation, ETAs) re-derive itself around
 *   the extra time, with zero new engine code. 'hold' is kept as a
 *   distinct intervention type (per the What-If API's vocabulary) even
 *   though it currently applies the same additional-delay mechanism as
 *   'delay'.
 * - 'priority' overwrites `train.priority`, the same field
 *   delayPropagation.js's `resolvePrecedence` already reads to decide
 *   which train yields at a shared resource.
 *
 * @param {object} intervention - already validated via validateIntervention.
 * @param {{trains: Array<object>, resources: Array<object>, findTrack: Function}} state
 * @returns {{trains: Array<object>, resources: Array<object>, findTrack: Function}} a
 *   new state object whose `trains` array is a deep, independent copy of
 *   `state.trains` with the intervention applied. `resources` and
 *   `findTrack` are passed through by reference — an intervention never
 *   touches network topology or resources.
 */
export function applyIntervention(intervention, state) {
  validateIntervention(intervention, state);

  // Deep-clone only the trains — the part any intervention can ever
  // touch — so the caller's original state/trains are never mutated.
  const modifiedTrains = structuredClone(state.trains);
  const train = modifiedTrains.find((t) => t.id === intervention.trainId);

  if (intervention.type === 'delay' || intervention.type === 'hold') {
    // Reuse the existing HH:MM <-> minutes helpers (timeUtils.js) rather
    // than re-implementing clock arithmetic here.
    train.scheduledDeparture = formatTime(parseTime(train.scheduledDeparture) + intervention.minutes);
  } else if (intervention.type === 'priority') {
    train.priority = intervention.priority;
  }

  return {
    trains: modifiedTrains,
    resources: state.resources,
    findTrack: state.findTrack,
  };
}

/**
 * Validate + apply a single hypothetical intervention to a clone of
 * `baseState`, then run the result through the EXISTING engine
 * orchestrator and return its output. `baseState` itself is never
 * mutated.
 *
 * @param {object} intervention - { type: 'delay'|'hold', trainId, minutes }
 *   or { type: 'priority', trainId, priority }.
 * @param {{trains: Array<object>, resources: Array<object>, findTrack: Function}} baseState
 * @returns {{
 *   events: Array<object>,
 *   occupancy: Array<object>,
 *   conflicts: Array<object>,
 *   propagatedDelays: {perConflict: Array<object>, delaysByTrain: Object<string, number>},
 *   etas: Array<object>
 * }} the exact same result shape simulateRailwayState() already returns
 *   for the real base state — this is that same function, just given a
 *   hypothetical state instead.
 * @throws {InvalidInterventionError} if the intervention fails validation.
 */
export function runWhatIfSimulation(intervention, baseState) {
  const whatIfState = applyIntervention(intervention, baseState);
  return simulateRailwayState(whatIfState);
}
