// engine/eventGenerator.js
//
// PHASE 2 CHUNK 1 — dynamic chronological event generation.
//
// Pure, data-driven: given a train (with `path`, `scheduledDeparture`,
// `stops`) and a way to look up the track between two stations, this
// walks the train's path leg by leg and produces a chronological list of
// events. Nothing here is specific to any train id, station id, or track
// id — it works for any path length (including a direct 2-station path
// with zero intermediate stations).
//
// Timing rule (the only rule): every event's time is derived from
//   scheduledDeparture + sum(track.travelMinutes) + sum(dwellMinutes)
// walked in order along the path. `train.speed` is never read here.
//
// This module only produces events — it does not detect conflicts,
// propagate delays, or touch resource occupancy (that's
// resourceOccupancy.js, one layer up).

import { parseTime, formatTime } from './timeUtils.js';

export const EVENT_TYPES = Object.freeze({
  DEPARTURE: 'departure', // initial departure from the first station in path
  TRACK_ENTRY: 'trackEntry', // train enters a track segment
  TRACK_EXIT: 'trackExit', // train exits a track segment
  ARRIVAL: 'arrival', // arrival at an intermediate station that is a worked stop
  STATION_DEPARTURE: 'stationDeparture', // departure from an intermediate worked stop, after dwell
  PASS_THROUGH: 'passThrough', // train passes an intermediate station with no dwell
  FINAL_ARRIVAL: 'finalArrival', // arrival at the last station in path
});

function findStop(train, stationId) {
  return (train.stops || []).find((s) => s.stationId === stationId) || null;
}

/**
 * Generate the chronological list of events for a single train.
 *
 * @param {object} train - must have `id`, `path` (>=2 station ids),
 *   `scheduledDeparture` ("HH:MM"), and `stops` (array of
 *   { stationId, dwellMinutes }, may be empty).
 * @param {object} deps
 * @param {(fromStationId: string, toStationId: string) => ({ id: string, travelMinutes: number } | null)} deps.findTrack -
 *   resolves the track between two adjacent stations in the path. This
 *   is the ONLY source of leg duration — `train.speed` is never used.
 * @returns {Array<object>} events, already in chronological order.
 */
export function generateTrainEvents(train, { findTrack }) {
  if (!train || typeof train.id === 'undefined') {
    throw new Error('generateTrainEvents: train.id is required');
  }
  if (!Array.isArray(train.path) || train.path.length < 2) {
    throw new Error(`generateTrainEvents: train ${train.id} needs a path with at least 2 stations`);
  }
  if (typeof findTrack !== 'function') {
    throw new Error('generateTrainEvents: deps.findTrack must be a function');
  }

  const events = [];
  let counter = 0;
  const nextId = () => `${train.id}-e${counter++}`;

  let clock = parseTime(train.scheduledDeparture);
  const origin = train.path[0];

  events.push({
    id: nextId(),
    trainId: train.id,
    type: EVENT_TYPES.DEPARTURE,
    stationId: origin,
    time: formatTime(clock),
    minutes: clock,
  });

  for (let i = 0; i < train.path.length - 1; i++) {
    const from = train.path[i];
    const to = train.path[i + 1];
    const track = findTrack(from, to);
    if (!track) {
      throw new Error(`generateTrainEvents: no track found between ${from} and ${to} for train ${train.id}`);
    }

    const entryTime = clock;
    events.push({
      id: nextId(),
      trainId: train.id,
      type: EVENT_TYPES.TRACK_ENTRY,
      trackId: track.id,
      fromStationId: from,
      toStationId: to,
      time: formatTime(entryTime),
      minutes: entryTime,
    });

    const exitTime = entryTime + track.travelMinutes;
    events.push({
      id: nextId(),
      trainId: train.id,
      type: EVENT_TYPES.TRACK_EXIT,
      trackId: track.id,
      fromStationId: from,
      toStationId: to,
      time: formatTime(exitTime),
      minutes: exitTime,
      durationMinutes: track.travelMinutes,
    });

    const arrivalTime = exitTime;
    const isFinalStation = i === train.path.length - 2;

    if (isFinalStation) {
      events.push({
        id: nextId(),
        trainId: train.id,
        type: EVENT_TYPES.FINAL_ARRIVAL,
        stationId: to,
        time: formatTime(arrivalTime),
        minutes: arrivalTime,
      });
      clock = arrivalTime;
      continue;
    }

    const stop = findStop(train, to);
    if (stop) {
      events.push({
        id: nextId(),
        trainId: train.id,
        type: EVENT_TYPES.ARRIVAL,
        stationId: to,
        time: formatTime(arrivalTime),
        minutes: arrivalTime,
      });
      const dwell = stop.dwellMinutes || 0;
      const departureTime = arrivalTime + dwell;
      events.push({
        id: nextId(),
        trainId: train.id,
        type: EVENT_TYPES.STATION_DEPARTURE,
        stationId: to,
        time: formatTime(departureTime),
        minutes: departureTime,
        durationMinutes: dwell,
      });
      clock = departureTime;
    } else {
      // Pass-through: no dwell, the train is momentarily "at" the
      // station but continues on the next leg with zero delay.
      events.push({
        id: nextId(),
        trainId: train.id,
        type: EVENT_TYPES.PASS_THROUGH,
        stationId: to,
        time: formatTime(arrivalTime),
        minutes: arrivalTime,
        durationMinutes: 0,
      });
      clock = arrivalTime;
    }
  }

  return events;
}

/**
 * Generate events for a whole fleet, merged into a single chronological
 * (globally time-sorted) list.
 *
 * @param {Array<object>} trains
 * @param {object} deps
 * @param {(fromStationId: string, toStationId: string) => object|null} deps.findTrack
 * @returns {Array<object>}
 */
export function generateAllEvents(trains, { findTrack }) {
  const all = [];
  for (const train of trains) {
    all.push(...generateTrainEvents(train, { findTrack }));
  }
  all.sort((a, b) => a.minutes - b.minutes);
  return all;
}
