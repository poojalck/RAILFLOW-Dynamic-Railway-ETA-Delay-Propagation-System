// engine/resourceOccupancy.js
//
// PHASE 2 CHUNK 1 — basic resource occupancy.
//
// Pure: converts an already-generated event list (see eventGenerator.js)
// into occupancy intervals against the network's existing RESOURCES
// (backend/data/network.js). No conflict detection happens here — this
// module only says "which train occupied which resource, from when to
// when", based on resource properties (type + stationId) matched against
// each train's path/stops. It never keys off train ids to decide
// association — a resource is relevant to a train purely because that
// train's path/stops touch the resource's station.
//
// ASSUMPTION (documented, not hidden):
//   - Platform resources (type: 'platform') model a genuine worked stop:
//     a train only occupies a platform resource at a station if that
//     station is one of the train's `stops` (i.e. has real arrival/dwell
//     data). A train passing through or merely starting/ending its run
//     at that station (with no recorded dwell) does not generate a
//     platform occupancy record in this chunk — inventing a dwell window
//     for it would be fabricating data that was never scheduled.
//   - Junction resources (type: 'junction') model the physical act of
//     crossing/using the junction, which happens whether or not the
//     train stops. Since Phase 1 data does not schedule a precise
//     junction-crossing duration, we use a short, deterministic,
//     symmetric window around the train's passage instant through that
//     station: [passageInstant - JUNCTION_BUFFER_MINUTES, passageInstant
//     + JUNCTION_BUFFER_MINUTES]. The "passage instant" is whichever
//     event marks the train actually being at that station: its arrival
//     (worked stop), its pass-through instant, its final arrival, or —
//     if the junction station is the train's very first station — its
//     initial departure. This is a placeholder occupancy model for this
//     chunk only; a real signalling-based junction duration is future
//     work.

import { formatTime } from './timeUtils.js';

const JUNCTION_BUFFER_MINUTES = 2;

function eventsForTrain(eventsByTrain, trainId) {
  return eventsByTrain.get(trainId) || [];
}

function groupEventsByTrain(events) {
  const map = new Map();
  for (const event of events) {
    if (!map.has(event.trainId)) map.set(event.trainId, []);
    map.get(event.trainId).push(event);
  }
  return map;
}

function platformOccupancyForTrain(train, trainEvents, resource) {
  const stopDef = (train.stops || []).find((s) => s.stationId === resource.stationId);
  if (!stopDef) return null; // not a worked stop at this station -> no platform occupancy

  const arrivalEvent = trainEvents.find(
    (e) => e.stationId === resource.stationId && e.type === 'arrival'
  );
  const departureEvent = trainEvents.find(
    (e) => e.stationId === resource.stationId && e.type === 'stationDeparture'
  );
  if (!arrivalEvent || !departureEvent) return null;

  return {
    resourceId: resource.id,
    trainId: train.id,
    startTime: arrivalEvent.time,
    endTime: departureEvent.time,
    startMinutes: arrivalEvent.minutes,
    endMinutes: departureEvent.minutes,
    resourceType: 'platform',
  };
}

function junctionOccupancyForTrain(train, trainEvents, resource) {
  if (!train.path.includes(resource.stationId)) return null;

  const stationEvents = trainEvents.filter((e) => e.stationId === resource.stationId);
  if (stationEvents.length === 0) return null;

  // Prefer an event that represents genuinely being "at" the station
  // (arrival / pass-through / final arrival) over a bare origin departure.
  const anchor =
    stationEvents.find((e) => ['arrival', 'passThrough', 'finalArrival'].includes(e.type)) ||
    stationEvents.find((e) => e.type === 'departure');
  if (!anchor) return null;

  const startMinutes = anchor.minutes - JUNCTION_BUFFER_MINUTES;
  const endMinutes = anchor.minutes + JUNCTION_BUFFER_MINUTES;

  return {
    resourceId: resource.id,
    trainId: train.id,
    startTime: formatTime(startMinutes),
    endTime: formatTime(endMinutes),
    startMinutes,
    endMinutes,
    resourceType: 'junction',
  };
}

/**
 * Compute resource occupancy records from an already-generated event
 * list, a fleet of trains (for their `path`/`stops`), and the network's
 * resource definitions.
 *
 * @param {Array<object>} events - output of generateAllEvents/generateTrainEvents
 * @param {Array<object>} resources - RESOURCES from data/network.js (id, type, stationId, ...)
 * @param {Array<object>} trains - the trains the events were generated for
 * @returns {Array<{resourceId:string, trainId:string, startTime:string, endTime:string}>}
 */
export function computeResourceOccupancy(events, resources, trains) {
  const eventsByTrain = groupEventsByTrain(events);
  const records = [];

  for (const resource of resources) {
    for (const train of trains) {
      if (!Array.isArray(train.path) || !train.path.includes(resource.stationId)) continue;
      const trainEvents = eventsForTrain(eventsByTrain, train.id);

      let record = null;
      if (resource.type === 'platform') {
        record = platformOccupancyForTrain(train, trainEvents, resource);
      } else if (resource.type === 'junction') {
        record = junctionOccupancyForTrain(train, trainEvents, resource);
      }
      if (record) records.push(record);
    }
  }

  records.sort((a, b) => a.startMinutes - b.startMinutes);
  return records;
}
