// engine/alertGenerator.js
//
// PHASE 2 CHUNK 6 (ALERTS) — pure alert-generation module.
//
//   Engine simulation
//        |
//   Conflicts + propagated delays   (conflictDetector.js / delayPropagation.js,
//        |                           already assembled by engine/index.js)
//        |
//   Alert generation                (this module)
//        |
//   GET /api/alerts                 (services/alertService.js)
//
// Pure: takes the `conflicts` and `propagatedDelays` shapes already
// produced by the engine (see engine/index.js -> simulateRailwayState)
// and converts them into small, structured alerts. This module contains
// NO scheduling/conflict/delay algorithm of its own — it only reads
// fields already computed upstream and applies a couple of simple,
// generic rules:
//
//   1. Every detected resource conflict -> one conflict alert.
//   2. Every train whose propagated delay meets/exceeds a threshold ->
//      one delay alert.
//   3. No conflicts and no significant delay -> no alerts.
//
// Fully generic/data-driven: nothing here branches on a specific train
// id, station id, or resource id. Swap in a different fleet/network and
// the same code still works.

// A propagated delay below this many minutes is not considered
// "significant" enough to raise its own alert (avoids noise from
// sub-minute rounding-level adjustments).
export const DEFAULT_DELAY_ALERT_THRESHOLD_MINUTES = 5;

// A delay at/above this many minutes is escalated from 'warning' to
// 'critical' severity. Kept simple and generic on purpose for this chunk.
const CRITICAL_DELAY_MINUTES = 15;

/**
 * Map a conflict's own severity classification (from conflictDetector.js:
 * 'capacity' | 'headway') onto an alert severity.
 * @param {{severity?: string}} conflict
 * @returns {'critical'|'warning'}
 */
function conflictAlertSeverity(conflict) {
  return conflict.severity === 'capacity' ? 'critical' : 'warning';
}

/**
 * Deterministic, content-derived id for a conflict alert so repeated
 * runs over the same simulation state produce stable ids (and so
 * genuinely distinct conflicts never collide).
 * @param {{resourceId:string, trainIds:string[], severity?:string}} conflict
 * @returns {string}
 */
function conflictAlertId(conflict) {
  const trainPart = [...conflict.trainIds].sort().join('-');
  return `conflict-${conflict.resourceId}-${trainPart}-${conflict.severity || 'unknown'}`;
}

/**
 * Build a generic, non-train-specific-template message describing a
 * conflict. The specific ids are interpolated, not hardcoded.
 * @param {{resourceId:string, trainIds:string[], severity?:string}} conflict
 * @returns {string}
 */
function conflictAlertMessage(conflict) {
  const [first, second] = conflict.trainIds;
  if (conflict.severity === 'capacity') {
    return `Trains ${first} and ${second} are scheduled to overlap on resource ${conflict.resourceId}, exceeding its capacity`;
  }
  return `Trains ${first} and ${second} do not have sufficient headway on resource ${conflict.resourceId}`;
}

/**
 * Convert detected resource conflicts into conflict alerts.
 * @param {Array<{resourceId:string, trainIds:string[], severity?:string, reason?:string}>} conflicts
 *   - output of conflictDetector.js's detectConflicts.
 * @returns {Array<object>} conflict alerts (one per conflict).
 */
export function generateConflictAlerts(conflicts) {
  if (!Array.isArray(conflicts)) return [];

  return conflicts.map((conflict) => ({
    id: conflictAlertId(conflict),
    type: 'conflict',
    severity: conflictAlertSeverity(conflict),
    message: conflictAlertMessage(conflict),
    trainIds: [...conflict.trainIds],
    resourceId: conflict.resourceId,
  }));
}

/**
 * Find a representative resourceId to attach to a delayed train's alert,
 * by looking at the per-conflict resolution records for the first one
 * that actually delayed this train. Purely a lookup — introduces no new
 * decision logic beyond "which resource caused this train's delay".
 * @param {Array<{delayedTrainId:string, resourceId:string, additionalDelayMinutes:number}>} perConflict
 * @param {string} trainId
 * @returns {string|null}
 */
function resourceResponsibleForDelay(perConflict, trainId) {
  if (!Array.isArray(perConflict)) return null;
  const record = perConflict.find(
    (entry) => entry.delayedTrainId === trainId && entry.additionalDelayMinutes > 0
  );
  return record ? record.resourceId : null;
}

/**
 * Convert propagated per-train delays into delay alerts, for any train
 * whose additional delay meets/exceeds the significance threshold.
 * @param {{delaysByTrain?: Object<string, number>, perConflict?: Array<object>}} propagatedDelays
 *   - output of delayPropagation.js's computeConflictDelays.
 * @param {{thresholdMinutes?: number}} [options]
 * @returns {Array<object>} delay alerts (one per significantly-delayed train).
 */
export function generateDelayAlerts(propagatedDelays, options = {}) {
  if (!propagatedDelays || typeof propagatedDelays !== 'object') return [];
  const { thresholdMinutes = DEFAULT_DELAY_ALERT_THRESHOLD_MINUTES } = options;
  const { delaysByTrain = {}, perConflict = [] } = propagatedDelays;

  const alerts = [];
  for (const trainId of Object.keys(delaysByTrain)) {
    const minutes = Number(delaysByTrain[trainId]) || 0;
    if (minutes < thresholdMinutes) continue;

    const resourceId = resourceResponsibleForDelay(perConflict, trainId);
    alerts.push({
      id: `delay-${trainId}`,
      type: 'delay',
      severity: minutes >= CRITICAL_DELAY_MINUTES ? 'critical' : 'warning',
      message: `Train ${trainId} is carrying a propagated delay of ${Math.round(minutes)} min`,
      trainIds: [trainId],
      resourceId,
    });
  }

  // Stable, deterministic ordering (by id) so output doesn't depend on
  // object key enumeration order.
  alerts.sort((a, b) => a.id.localeCompare(b.id));
  return alerts;
}

/**
 * Generate the full set of engine-driven alerts for one simulation
 * result: conflict alerts followed by delay alerts. No conflicts and no
 * significant delay simply yields an empty array.
 *
 * @param {{conflicts?: Array<object>, propagatedDelays?: {delaysByTrain?: Object<string,number>, perConflict?: Array<object>}}} simulationResult
 *   - the (or a subset of the) object returned by engine/index.js's
 *   simulateRailwayState.
 * @param {{thresholdMinutes?: number}} [options]
 * @returns {Array<{id:string, type:string, severity:string, message:string, trainIds:string[], resourceId:string|null}>}
 */
export function generateAlerts(simulationResult, options = {}) {
  if (!simulationResult || typeof simulationResult !== 'object') {
    throw new Error('generateAlerts: simulationResult object is required');
  }
  const { conflicts = [], propagatedDelays = {} } = simulationResult;

  return [
    ...generateConflictAlerts(conflicts),
    ...generateDelayAlerts(propagatedDelays, options),
  ];
}
