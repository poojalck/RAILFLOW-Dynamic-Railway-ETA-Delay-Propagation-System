// engine/timeUtils.js
//
// Small, pure "HH:MM" <-> minutes-since-midnight helpers shared by the
// engine modules. No train/network knowledge lives here on purpose —
// this is just clock arithmetic.

/**
 * Parse an "HH:MM" string into minutes since midnight.
 * @param {string} hhmm
 * @returns {number}
 */
export function parseTime(hhmm) {
  if (typeof hhmm !== 'string' || !/^\d{1,2}:\d{2}$/.test(hhmm)) {
    throw new Error(`parseTime: expected an "HH:MM" string, got ${JSON.stringify(hhmm)}`);
  }
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

/**
 * Format minutes since midnight back into an "HH:MM" string.
 * Wraps around a 24h clock (e.g. 1450 -> "00:10") since a multi-leg
 * schedule can legitimately roll past midnight.
 * @param {number} minutes
 * @returns {string}
 */
export function formatTime(minutes) {
  const normalized = ((Math.round(minutes) % 1440) + 1440) % 1440;
  const h = Math.floor(normalized / 60);
  const m = normalized % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}
