// server.js — RAILFLOW backend entry point.
//
// PHASE 1 scope: server bootstrapping, route wiring, and the four
// "read-only" endpoints that serve the ported seed data. The railway
// simulation engine itself (Phases 2-8) plugs in underneath the service
// layer without changing these routes or the frontend's contract.
//
// Run with:  node server.js   (or `npm run dev` for auto-restart on change)

import { createApp, cors } from './utils/router.js';
import { registerHealthRoutes } from './routes/health.js';
import { registerTrainRoutes } from './routes/trains.js';
import { registerNetworkRoutes } from './routes/network.js';
import { registerAlertRoutes } from './routes/alerts.js';
import { registerSimulationRoutes } from './routes/simulation.js';
import { registerOptimizationRoutes } from './routes/optimization.js';

const PORT = process.env.PORT || 4000;

const app = createApp();

app.use(cors());

registerHealthRoutes(app);
registerTrainRoutes(app);
registerNetworkRoutes(app);
registerAlertRoutes(app);
registerSimulationRoutes(app);
registerOptimizationRoutes(app);

app.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`RAILFLOW backend listening on http://localhost:${PORT}`);
  // eslint-disable-next-line no-console
  console.log(`  GET  /api/health`);
  // eslint-disable-next-line no-console
  console.log(`  GET  /api/trains`);
  // eslint-disable-next-line no-console
  console.log(`  GET  /api/trains/:id`);
  // eslint-disable-next-line no-console
  console.log(`  GET  /api/network`);
  // eslint-disable-next-line no-console
  console.log(`  GET  /api/alerts`);
  // eslint-disable-next-line no-console
  console.log(`  GET  /api/simulation`);
  // eslint-disable-next-line no-console
  console.log(`  POST /api/simulation/what-if`);
  // eslint-disable-next-line no-console
  console.log(`  POST /api/simulation/optimize`);
  // eslint-disable-next-line no-console
  console.log(`  GET  /api/optimization`);
});
