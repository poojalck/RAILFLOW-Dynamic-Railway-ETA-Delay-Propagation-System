// tests/phase2.delay.test.js
//
// Focused tests for PHASE 2 CHUNK 3: delay propagation, part 1
// (conflict-resolution delay). Uses Node's built-in test runner
// (`node --test`).
//
// Occupancies are synthetic "HH:MM" fixtures (same style as
// phase2.conflict.test.js) fed through the REAL detectConflicts so these
// tests exercise the actual occupancy -> conflict -> delay pipeline, not
// a hand-rolled conflict shape.

import test from 'node:test';
import assert from 'node:assert/strict';
import { detectConflicts } from '../engine/conflictDetector.js';
import { computeConflictDelays, getAdditionalDelayMinutes } from '../engine/delayPropagation.js';
import { parseTime } from '../engine/timeUtils.js';

function occ(resourceId, trainId, startTime, endTime) {
  return {
    resourceId,
    trainId,
    startTime,
    endTime,
    startMinutes: parseTime(startTime),
    endMinutes: parseTime(endTime),
  };
}

// 1. No conflicts -> no additional delay ----------------------------------
test('no conflicts means no additional delay for any train', () => {
  const resources = [{ id: 'R1', capacity: 1, headwaySeconds: 0 }];
  const trains = [
    { id: 'TA', priority: 1 },
    { id: 'TB', priority: 2 },
  ];
  const occupancies = [
    occ('R1', 'TA', '10:00', '10:10'),
    occ('R1', 'TB', '10:20', '10:30'),
  ];

  const conflicts = detectConflicts(occupancies, resources);
  assert.deepEqual(conflicts, []);

  const result = computeConflictDelays({ occupancies, conflicts, resources, trains });
  assert.deepEqual(result.delaysByTrain, {});
  assert.deepEqual(result.perConflict, []);
});

// 2. One conflict -> lower-priority train is delayed -----------------------
test('a single conflict delays the lower-priority train', () => {
  const resources = [{ id: 'R1', capacity: 1, headwaySeconds: 0 }];
  const trains = [
    { id: 'TA', priority: 1 }, // higher precedence (lower number)
    { id: 'TB', priority: 2 }, // lower precedence
  ];
  const occupancies = [
    occ('R1', 'TA', '10:00', '10:15'),
    occ('R1', 'TB', '10:05', '10:20'), // overlaps TA
  ];

  const conflicts = detectConflicts(occupancies, resources);
  assert.equal(conflicts.length, 1);

  const result = computeConflictDelays({ occupancies, conflicts, resources, trains });

  // TB must be pushed to start at/after TA's occupancy ends (10:15), i.e.
  // delayed by (10:15 - 10:05) = 10 minutes.
  assert.equal(getAdditionalDelayMinutes(result, 'TB'), 10);
  assert.equal(result.perConflict.length, 1);
  assert.equal(result.perConflict[0].delayedTrainId, 'TB');
  assert.equal(result.perConflict[0].precedingTrainId, 'TA');
});

// 3. Higher-priority train remains unaffected ------------------------------
test('the higher-priority train in a conflict receives no additional delay', () => {
  const resources = [{ id: 'R1', capacity: 1, headwaySeconds: 0 }];
  const trains = [
    { id: 'TA', priority: 1 },
    { id: 'TB', priority: 2 },
  ];
  const occupancies = [
    occ('R1', 'TA', '10:00', '10:15'),
    occ('R1', 'TB', '10:05', '10:20'),
  ];

  const conflicts = detectConflicts(occupancies, resources);
  const result = computeConflictDelays({ occupancies, conflicts, resources, trains });

  assert.equal(getAdditionalDelayMinutes(result, 'TA'), 0);
  assert.equal('TA' in result.delaysByTrain, false);
});

// 4. Headway is included when calculating the required delay --------------
test('the required delay includes the resource headway, not just the raw occupancy gap', () => {
  const resources = [{ id: 'R1', capacity: 1, headwaySeconds: 300 }]; // 5 min headway
  const trains = [
    { id: 'TA', priority: 1 },
    { id: 'TB', priority: 2 },
  ];
  // TB starts only 2 minutes after TA's occupancy ends -> violates the
  // 5-minute headway even though the intervals don't literally overlap.
  const occupancies = [
    occ('R1', 'TA', '10:00', '10:10'),
    occ('R1', 'TB', '10:12', '10:20'),
  ];

  const conflicts = detectConflicts(occupancies, resources);
  assert.equal(conflicts.length, 1);
  assert.equal(conflicts[0].severity, 'headway');

  const result = computeConflictDelays({ occupancies, conflicts, resources, trains });

  // Required start = TA end (10:10) + 5 min headway = 10:15.
  // TB was scheduled for 10:12, so additional delay = 3 minutes.
  assert.equal(getAdditionalDelayMinutes(result, 'TB'), 3);
});

// 5. Multiple conflicts can be processed -----------------------------------
test('multiple independent conflicts across different resources are all resolved', () => {
  const resources = [
    { id: 'R1', capacity: 1, headwaySeconds: 0 },
    { id: 'R2', capacity: 1, headwaySeconds: 0 },
  ];
  const trains = [
    { id: 'TA', priority: 1 },
    { id: 'TB', priority: 2 },
    { id: 'TC', priority: 1 },
    { id: 'TD', priority: 3 },
  ];
  const occupancies = [
    occ('R1', 'TA', '10:00', '10:15'),
    occ('R1', 'TB', '10:05', '10:20'), // conflict on R1: TB delayed behind TA
    occ('R2', 'TC', '11:00', '11:10'),
    occ('R2', 'TD', '11:02', '11:12'), // conflict on R2: TD delayed behind TC
  ];

  const conflicts = detectConflicts(occupancies, resources);
  assert.equal(conflicts.length, 2);

  const result = computeConflictDelays({ occupancies, conflicts, resources, trains });

  assert.equal(getAdditionalDelayMinutes(result, 'TB'), 10); // 10:15 - 10:05
  assert.equal(getAdditionalDelayMinutes(result, 'TD'), 8); // 11:10 - 11:02
  assert.equal(getAdditionalDelayMinutes(result, 'TA'), 0);
  assert.equal(getAdditionalDelayMinutes(result, 'TC'), 0);
  assert.equal(result.perConflict.length, 2);
});

// 6. Existing delay is taken into account -----------------------------------
test('existing delay already carried by the lower-priority train reduces the additional delay needed', () => {
  const resources = [{ id: 'R1', capacity: 1, headwaySeconds: 0 }];
  const trains = [
    { id: 'TA', priority: 1 },
    { id: 'TB', priority: 2 },
  ];
  const occupancies = [
    occ('R1', 'TA', '10:00', '10:15'),
    occ('R1', 'TB', '10:05', '10:20'),
  ];
  const conflicts = detectConflicts(occupancies, resources);

  // TB already carries 7 minutes of delay coming in, so it only needs
  // (10:15 - 10:05) - 7 = 3 more minutes to clear TA.
  const result = computeConflictDelays({
    occupancies,
    conflicts,
    resources,
    trains,
    existingDelays: { TB: 7 },
  });
  assert.equal(getAdditionalDelayMinutes(result, 'TB'), 3);

  // If TB already carries enough delay to clear TA on its own, no
  // additional delay is required.
  const resultFullyCovered = computeConflictDelays({
    occupancies,
    conflicts,
    resources,
    trains,
    existingDelays: { TB: 15 },
  });
  assert.equal(getAdditionalDelayMinutes(resultFullyCovered, 'TB'), 0);
});

test('delayPropagation.js source contains no hardcoded train/station/resource-id branching', async () => {
  const fs = await import('node:fs');
  const { fileURLToPath } = await import('node:url');
  const sourcePath = fileURLToPath(new URL('../engine/delayPropagation.js', import.meta.url));
  const source = fs.readFileSync(sourcePath, 'utf8');

  assert.ok(!/trainId\s*===\s*['"`]/.test(source), 'found a literal trainId === "..." comparison');
  assert.ok(!/id\s*===\s*['"`](?!idA|idB)/.test(source.replace(/higherId|lowerId/g, '')), 'found a suspicious literal id === "..." comparison');
});
