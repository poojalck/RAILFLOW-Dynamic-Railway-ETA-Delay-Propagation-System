// tests/phase2.orchestrator.test.js
//
// Focused tests for PHASE 2 CHUNK 5: the engine orchestrator
// (engine/index.js -> simulateRailwayState). Uses Node's built-in test
// runner (`node --test`).
//
// A synthetic fixture drives a scenario that deliberately produces a
// resource conflict (so the delay-propagation and downstream ETA stages
// have something real to act on), plus a smaller integration test
// against the real seed data (data/trains.js + data/network.js) to catch
// any wiring mistakes.

import test from 'node:test';
import assert from 'node:assert/strict';
import { simulateRailwayState } from '../engine/index.js';
import { parseTime } from '../engine/timeUtils.js';
import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';

// ---------------------------------------------------------------------
// Synthetic fixture: two trains sharing a capacity-1 resource at the
// same time, on a two-station A -> B path, guaranteed to conflict.
// ---------------------------------------------------------------------
function makeConflictingState(overrides = {}) {
  const trains = [
    {
      id: 'TA',
      priority: 1, // higher precedence
      path: ['A', 'B'],
      scheduledDeparture: '10:00',
      stops: [],
      delay: 0,
    },
    {
      id: 'TB',
      priority: 2, // lower precedence -> expected to be delayed
      path: ['A', 'B'],
      scheduledDeparture: '10:00',
      stops: [],
      delay: 0,
    },
  ];
  const resources = [
    { id: 'JCT-A', label: 'Junction A', stationId: 'A', type: 'junction', capacity: 1, headwaySeconds: 60 },
  ];
  const findTrackFn = () => ({ id: 'A-B', travelMinutes: 30 });

  return { trains, resources, findTrack: findTrackFn, ...overrides };
}

// 1. simulateRailwayState exists and is callable ---------------------------
test('simulateRailwayState is exported as a callable function', () => {
  assert.equal(typeof simulateRailwayState, 'function');
  assert.doesNotThrow(() => simulateRailwayState(makeConflictingState()));
});

// 2. A valid railway state produces a structured simulation result --------
test('a valid railway state produces a structured result with all expected top-level keys', () => {
  const result = simulateRailwayState(makeConflictingState());

  for (const key of ['events', 'occupancy', 'conflicts', 'propagatedDelays', 'etas']) {
    assert.ok(key in result, `simulation result missing '${key}'`);
  }
  assert.ok(Array.isArray(result.events));
  assert.ok(Array.isArray(result.occupancy));
  assert.ok(Array.isArray(result.conflicts));
  assert.ok(Array.isArray(result.etas));
  assert.ok(result.propagatedDelays && typeof result.propagatedDelays === 'object');
});

// 3. The result contains events --------------------------------------------
test('the result contains generated events for every train', () => {
  const state = makeConflictingState();
  const result = simulateRailwayState(state);

  assert.ok(result.events.length > 0);
  for (const train of state.trains) {
    assert.ok(result.events.some((e) => e.trainId === train.id), `expected an event for ${train.id}`);
  }
});

// 4. The result contains occupancy -------------------------------------------
test('the result contains occupancy records for the contested resource', () => {
  const result = simulateRailwayState(makeConflictingState());

  assert.ok(result.occupancy.length > 0);
  assert.ok(result.occupancy.every((o) => 'resourceId' in o && 'trainId' in o));
  assert.ok(result.occupancy.some((o) => o.resourceId === 'JCT-A'));
});

// 5. Conflicts are present when applicable -----------------------------------
test('conflicts are detected when the railway state has a genuine resource conflict', () => {
  const result = simulateRailwayState(makeConflictingState());

  assert.ok(result.conflicts.length > 0);
  assert.deepEqual(result.conflicts[0].trainIds, ['TA', 'TB']);
});

test('no conflicts are reported for a railway state with no contention', () => {
  const state = makeConflictingState();
  // Push TB's departure well past TA's occupancy + headway, removing the conflict.
  state.trains[1].scheduledDeparture = '12:00';

  const result = simulateRailwayState(state);
  assert.deepEqual(result.conflicts, []);
});

// 6. Delay propagation output is present -------------------------------------
test('delay propagation output reflects the lower-priority train being delayed', () => {
  const result = simulateRailwayState(makeConflictingState());

  assert.ok('perConflict' in result.propagatedDelays);
  assert.ok('delaysByTrain' in result.propagatedDelays);
  assert.ok(result.propagatedDelays.delaysByTrain.TB > 0);
  assert.equal(result.propagatedDelays.delaysByTrain.TA, undefined);
});

// 7. ETA output is present ----------------------------------------------------
test('ETA output is present for every train and reflects the propagated delay', () => {
  const result = simulateRailwayState(makeConflictingState());

  assert.equal(result.etas.length, 2);
  const etaA = result.etas.find((e) => e.trainId === 'TA');
  const etaB = result.etas.find((e) => e.trainId === 'TB');

  assert.ok(etaA && etaB);
  assert.equal(etaA.totalDelay, 0);
  assert.equal(etaA.predictedETA, etaA.scheduledETA);

  assert.ok(etaB.totalDelay > 0);
  assert.equal(etaB.totalDelay, result.propagatedDelays.delaysByTrain.TB);
  assert.equal(
    parseTime(etaB.predictedETA) - parseTime(etaB.scheduledETA),
    etaB.totalDelay
  );
});

// Purity: calling twice with the same input produces the same output, and
// the input state object itself is not mutated.
test('simulateRailwayState is pure: repeated calls with the same state give identical results', () => {
  const state = makeConflictingState();
  const stateCopy = JSON.parse(JSON.stringify({ trains: state.trains, resources: state.resources }));

  const result1 = simulateRailwayState(state);
  const result2 = simulateRailwayState(state);

  assert.deepEqual(result1.etas, result2.etas);
  assert.deepEqual(result1.conflicts, result2.conflicts);
  // The trains/resources passed in were not mutated by the simulation.
  assert.deepEqual(state.trains, stateCopy.trains);
  assert.deepEqual(state.resources, stateCopy.resources);
});

// ---------------------------------------------------------------------
// Integration smoke test against the REAL seed data, exercising the
// full pipeline end-to-end exactly as later phases would call it.
// ---------------------------------------------------------------------
test('simulates the entire real seed fleet end-to-end without error', () => {
  const result = simulateRailwayState({ trains: INITIAL_TRAINS, resources: RESOURCES, findTrack });

  assert.ok(result.events.length > 0);
  assert.ok(result.occupancy.length > 0);
  assert.ok(Array.isArray(result.conflicts));
  assert.ok(result.propagatedDelays.delaysByTrain && typeof result.propagatedDelays.delaysByTrain === 'object');
  assert.equal(result.etas.length, INITIAL_TRAINS.length);
  for (const eta of result.etas) {
    assert.ok(/^\d{2}:\d{2}$/.test(eta.scheduledETA));
    assert.ok(/^\d{2}:\d{2}$/.test(eta.predictedETA));
    assert.ok(typeof eta.totalDelay === 'number' && eta.totalDelay >= 0);
  }
});

test('engine/index.js source contains no hardcoded train/station/resource-id branching', async () => {
  const fs = await import('node:fs');
  const { fileURLToPath } = await import('node:url');
  const sourcePath = fileURLToPath(new URL('../engine/index.js', import.meta.url));
  const source = fs.readFileSync(sourcePath, 'utf8');

  assert.ok(!/trainId\s*===\s*['"`]/.test(source), 'found a literal trainId === "..." comparison');
  assert.ok(!/stationId\s*===\s*['"`]/.test(source), 'found a literal stationId === "..." comparison');
  assert.ok(!/resourceId\s*===\s*['"`]/.test(source), 'found a literal resourceId === "..." comparison');
});
