// tests/phase2.service-integration.test.js
//
// Focused tests for PHASE 2 CHUNK 6: connecting the engine to
// trainService, and confirming the /api/trains endpoints surface the
// engine's computed output. Uses Node's built-in test runner
// (`node --test`).
//
// Boots a real HTTP server (same pattern as phase1.api.test.js) so these
// tests exercise the full routes -> controllers -> services -> engine
// path exactly as a real client would hit it, plus direct unit tests
// against trainService.js itself.

import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp, cors } from '../utils/router.js';
import { registerTrainRoutes } from '../routes/trains.js';
import { getAllTrains, getTrainById } from '../services/trainService.js';
import { simulateRailwayState } from '../engine/index.js';
import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';

const EXPECTED_FIELDS = [
  'id',
  'routeLabel',
  'path',
  'speed',
  'delay',
  'status',
  'scheduledETA',
  'predictedETA',
  'priority',
  'scheduledDeparture',
  'stops',
];

let server;
let baseUrl;

test.before(async () => {
  const app = createApp();
  app.use(cors());
  registerTrainRoutes(app);

  await new Promise((resolve) => {
    server = app.listen(0, resolve);
  });
  const { port } = server.address();
  baseUrl = `http://localhost:${port}`;
});

test.after(() => {
  server.close();
});

// 1. /api/trains still returns successfully ---------------------------------
test('GET /api/trains still returns 200 with a non-empty fleet', async () => {
  const res = await fetch(`${baseUrl}/api/trains`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.ok(Array.isArray(body.trains));
  assert.equal(body.trains.length, INITIAL_TRAINS.length);
});

// 2. Existing train fields are preserved -------------------------------------
test('every train in the response still has every existing Phase 1 field', async () => {
  const res = await fetch(`${baseUrl}/api/trains`);
  const body = await res.json();

  for (const train of body.trains) {
    for (const field of EXPECTED_FIELDS) {
      assert.ok(field in train, `train ${train.id} is missing field '${field}'`);
    }
  }
});

test('static, non-computed fields (id, routeLabel, path, speed, priority, scheduledDeparture, stops) are unchanged from the seed data', async () => {
  const res = await fetch(`${baseUrl}/api/trains`);
  const body = await res.json();
  const byId = new Map(body.trains.map((t) => [t.id, t]));

  for (const seedTrain of INITIAL_TRAINS) {
    const served = byId.get(seedTrain.id);
    assert.ok(served, `expected train ${seedTrain.id} to still be served`);
    assert.equal(served.routeLabel, seedTrain.routeLabel);
    assert.deepEqual(served.path, seedTrain.path);
    assert.equal(served.speed, seedTrain.speed);
    assert.equal(served.priority, seedTrain.priority);
    assert.equal(served.scheduledDeparture, seedTrain.scheduledDeparture);
    assert.deepEqual(served.stops, seedTrain.stops);
  }
});

// 3. predictedETA is now produced using the engine ---------------------------
test('predictedETA in the API response matches the engine\'s own computed output', async () => {
  const res = await fetch(`${baseUrl}/api/trains`);
  const body = await res.json();

  const { etas } = simulateRailwayState({ trains: INITIAL_TRAINS, resources: RESOURCES, findTrack });
  const etaByTrainId = new Map(etas.map((e) => [e.trainId, e]));

  for (const train of body.trains) {
    const engineEta = etaByTrainId.get(train.id);
    assert.ok(engineEta, `expected engine ETA output for ${train.id}`);
    assert.equal(train.scheduledETA, engineEta.scheduledETA);
    assert.equal(train.predictedETA, engineEta.predictedETA);
  }
});

// 4. Computed delay is available ---------------------------------------------
test('delay in the API response matches the engine\'s totalDelay, and status reflects it', async () => {
  const res = await fetch(`${baseUrl}/api/trains`);
  const body = await res.json();

  const { etas } = simulateRailwayState({ trains: INITIAL_TRAINS, resources: RESOURCES, findTrack });
  const etaByTrainId = new Map(etas.map((e) => [e.trainId, e]));

  let sawADelayedTrain = false;
  for (const train of body.trains) {
    const engineEta = etaByTrainId.get(train.id);
    assert.equal(train.delay, engineEta.totalDelay);
    if (engineEta.totalDelay > 0) {
      sawADelayedTrain = true;
      assert.equal(train.status, 'delayed');
    } else {
      assert.equal(train.status, 'onTime');
    }
  }
  // Sanity: the real seed fleet + network is expected to produce at
  // least one genuine conflict-driven delay, so this integration
  // actually exercises the engine rather than trivially passing through.
  assert.ok(sawADelayedTrain, 'expected at least one train to have a computed delay in the real seed fleet');
});

// 5. /api/trains/:id still works ----------------------------------------------
test('GET /api/trains/:id still returns a single matching train with computed fields', async () => {
  const knownId = INITIAL_TRAINS[0].id;
  const res = await fetch(`${baseUrl}/api/trains/${knownId}`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(body.train.id, knownId);
  for (const field of EXPECTED_FIELDS) {
    assert.ok(field in body.train, `single-train response missing field '${field}'`);
  }
});

// 6. Unknown train still returns 404 -------------------------------------------
test('GET /api/trains/:id still 404s for an unknown id', async () => {
  const res = await fetch(`${baseUrl}/api/trains/NOPE`);
  assert.equal(res.status, 404);
  const body = await res.json();
  assert.ok('error' in body);
});

// Direct unit-level checks against trainService.js itself (no HTTP layer)
test('trainService.getAllTrains() merges engine output onto every train', () => {
  const trains = getAllTrains();
  assert.equal(trains.length, INITIAL_TRAINS.length);
  for (const train of trains) {
    for (const field of EXPECTED_FIELDS) {
      assert.ok(field in train, `train ${train.id} missing '${field}'`);
    }
    assert.ok(['onTime', 'delayed'].includes(train.status));
    assert.ok(typeof train.delay === 'number' && train.delay >= 0);
  }
});

test('trainService.getTrainById() returns null for an unknown id and a merged train for a known one', () => {
  assert.equal(getTrainById('NOPE'), null);

  const knownId = INITIAL_TRAINS[0].id;
  const train = getTrainById(knownId);
  assert.ok(train);
  assert.equal(train.id, knownId);
  assert.ok(typeof train.predictedETA === 'string');
});

test('trainService.js source contains no hardcoded train/station/resource-id branching', async () => {
  const fs = await import('node:fs');
  const { fileURLToPath } = await import('node:url');
  const sourcePath = fileURLToPath(new URL('../services/trainService.js', import.meta.url));
  const source = fs.readFileSync(sourcePath, 'utf8');

  assert.ok(!/train\.id\s*===\s*['"`]/.test(source), 'found a literal train.id === "..." comparison');
  assert.ok(!/stationId\s*===\s*['"`]/.test(source), 'found a literal stationId === "..." comparison');
});
