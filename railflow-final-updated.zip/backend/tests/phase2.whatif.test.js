// tests/phase2.whatif.test.js
//
// Focused tests for PHASE 2 CHUNK 12A (WHAT-IF BACKEND CORE):
// engine/whatIf.js (validateIntervention, applyIntervention,
// runWhatIfSimulation). No API endpoint exists yet for this chunk — the
// module is exercised directly. Uses Node's built-in test runner
// (`node --test`).
//
// A synthetic two-train fixture (mirroring phase2.orchestrator.test.js's
// style) drives the core behavior tests so they're independent of how
// the real fleet happens to be scheduled; a smaller integration block at
// the bottom exercises the real seed data (data/trains.js +
// data/network.js) to catch any wiring mistakes.

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateIntervention,
  applyIntervention,
  runWhatIfSimulation,
  InvalidInterventionError,
  WHAT_IF_INTERVENTION_TYPES,
} from '../engine/whatIf.js';
import { simulateRailwayState } from '../engine/index.js';
import { parseTime } from '../engine/timeUtils.js';
import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';

// ---------------------------------------------------------------------
// Synthetic fixture: two trains sharing a capacity-1 resource, same
// pattern as phase2.orchestrator.test.js, so a delay/hold/priority
// intervention has something real to change.
// ---------------------------------------------------------------------
function makeState(overrides = {}) {
  const trains = [
    {
      id: 'TA',
      priority: 2,
      path: ['A', 'B'],
      scheduledDeparture: '10:00',
      stops: [],
      delay: 0,
    },
    {
      id: 'TB',
      priority: 1, // higher precedence -> TA is expected to yield
      path: ['A', 'B'],
      scheduledDeparture: '10:00',
      stops: [],
      delay: 0,
    },
  ];
  const resources = [
    { id: 'JCT-A', label: 'Junction A', stationId: 'A', type: 'junction', capacity: 1, headwaySeconds: 90 },
  ];
  const findTrackFixture = (from, to) => {
    if ((from === 'A' && to === 'B') || (from === 'B' && to === 'A')) {
      return { id: 'TRACK-A-B', travelMinutes: 20 };
    }
    return null;
  };
  return { trains, resources, findTrack: findTrackFixture, ...overrides };
}

function realState() {
  return { trains: INITIAL_TRAINS, resources: RESOURCES, findTrack };
}

// 1. Valid delay intervention works -----------------------------------------------
test('a valid delay intervention shifts the target train scheduledDeparture forward and produces a full engine result', () => {
  const state = makeState();
  const result = runWhatIfSimulation({ type: 'delay', trainId: 'TA', minutes: 30 }, state);

  assert.ok(Array.isArray(result.events));
  assert.ok(Array.isArray(result.occupancy));
  assert.ok(Array.isArray(result.conflicts));
  assert.ok(result.propagatedDelays && typeof result.propagatedDelays === 'object');
  assert.ok(Array.isArray(result.etas));

  const taDeparture = result.events.find((e) => e.trainId === 'TA' && e.type === 'departure');
  assert.equal(taDeparture.minutes, parseTime('10:00') + 30);
});

// 2. Valid hold intervention works --------------------------------------------------
test('a valid hold intervention also shifts the target train forward as an additional temporary delay', () => {
  const state = makeState();
  const result = runWhatIfSimulation({ type: 'hold', trainId: 'TA', minutes: 15 }, state);

  const taDeparture = result.events.find((e) => e.trainId === 'TA' && e.type === 'departure');
  assert.equal(taDeparture.minutes, parseTime('10:00') + 15);
});

// 3. Valid priority intervention works ------------------------------------------------
test('a valid priority intervention changes which train yields in delay propagation', () => {
  const base = makeState();
  const baseResult = simulateRailwayState(base);
  // Base: TB (priority 1) has precedence, so TA (priority 2) is the one delayed.
  assert.ok(baseResult.propagatedDelays.delaysByTrain.TA > 0);
  assert.equal(baseResult.propagatedDelays.delaysByTrain.TB, undefined);

  // Flip TA to priority 1 (now equal/higher precedence than TB) via a
  // what-if intervention and confirm the *what-if* result differs.
  const whatIfResult = runWhatIfSimulation({ type: 'priority', trainId: 'TA', priority: 1 }, base);
  // With TA now matching TB's old precedence in a tie, resolution falls
  // back to a stable id-based rule — the important assertion is just
  // that the outcome is no longer "TA always yields to TB regardless".
  assert.notDeepEqual(whatIfResult.propagatedDelays.delaysByTrain, baseResult.propagatedDelays.delaysByTrain);
});

// 4. Original/base railway state is NOT mutated ----------------------------------------
test('applyIntervention and runWhatIfSimulation never mutate the base state', () => {
  const state = makeState();
  const before = structuredClone(state.trains);

  applyIntervention({ type: 'delay', trainId: 'TA', minutes: 45 }, state);
  assert.deepEqual(state.trains, before);

  runWhatIfSimulation({ type: 'hold', trainId: 'TB', minutes: 10 }, state);
  assert.deepEqual(state.trains, before);

  runWhatIfSimulation({ type: 'priority', trainId: 'TA', priority: 9 }, state);
  assert.deepEqual(state.trains, before);
});

test('the real seed data (INITIAL_TRAINS) is never mutated by a what-if run', () => {
  const before = structuredClone(INITIAL_TRAINS);
  const state = realState();

  runWhatIfSimulation({ type: 'delay', trainId: INITIAL_TRAINS[0].id, minutes: 20 }, state);
  runWhatIfSimulation({ type: 'hold', trainId: INITIAL_TRAINS[1].id, minutes: 10 }, state);
  runWhatIfSimulation({ type: 'priority', trainId: INITIAL_TRAINS[2].id, priority: 1 }, state);

  assert.deepEqual(INITIAL_TRAINS, before);
});

test('applyIntervention returns a trains array that is a different reference from the input', () => {
  const state = makeState();
  const modified = applyIntervention({ type: 'delay', trainId: 'TA', minutes: 5 }, state);
  assert.notEqual(modified.trains, state.trains);
  assert.notEqual(
    modified.trains.find((t) => t.id === 'TA'),
    state.trains.find((t) => t.id === 'TA')
  );
});

// 5. Unknown train ID is rejected -------------------------------------------------------
test('an unknown trainId is rejected', () => {
  const state = makeState();
  assert.throws(
    () => runWhatIfSimulation({ type: 'delay', trainId: 'NOT-REAL', minutes: 5 }, state),
    InvalidInterventionError
  );
});

test('a missing trainId is rejected', () => {
  const state = makeState();
  assert.throws(() => runWhatIfSimulation({ type: 'delay', minutes: 5 }, state), InvalidInterventionError);
});

// 6. Unknown intervention type is rejected -----------------------------------------------
test('an unsupported intervention type is rejected', () => {
  const state = makeState();
  assert.throws(
    () => runWhatIfSimulation({ type: 'reroute', trainId: 'TA' }, state),
    InvalidInterventionError
  );
});

test('WHAT_IF_INTERVENTION_TYPES only exposes the three supported types', () => {
  assert.deepEqual([...WHAT_IF_INTERVENTION_TYPES].sort(), ['delay', 'hold', 'priority']);
});

// 7. Invalid minutes are rejected ----------------------------------------------------------
test('negative minutes are rejected for delay', () => {
  const state = makeState();
  assert.throws(() => validateIntervention({ type: 'delay', trainId: 'TA', minutes: -5 }, state), InvalidInterventionError);
});

test('zero minutes are rejected for delay', () => {
  const state = makeState();
  assert.throws(() => validateIntervention({ type: 'delay', trainId: 'TA', minutes: 0 }, state), InvalidInterventionError);
});

test('non-numeric minutes are rejected for delay', () => {
  const state = makeState();
  assert.throws(
    () => validateIntervention({ type: 'delay', trainId: 'TA', minutes: 'five' }, state),
    InvalidInterventionError
  );
});

test('negative, zero, and non-numeric minutes are all rejected for hold too', () => {
  const state = makeState();
  assert.throws(() => validateIntervention({ type: 'hold', trainId: 'TA', minutes: -1 }, state), InvalidInterventionError);
  assert.throws(() => validateIntervention({ type: 'hold', trainId: 'TA', minutes: 0 }, state), InvalidInterventionError);
  assert.throws(() => validateIntervention({ type: 'hold', trainId: 'TA', minutes: NaN }, state), InvalidInterventionError);
});

// 8. Invalid priority is rejected -----------------------------------------------------------
test('a non-integer priority is rejected', () => {
  const state = makeState();
  assert.throws(
    () => validateIntervention({ type: 'priority', trainId: 'TA', priority: 1.5 }, state),
    InvalidInterventionError
  );
});

test('a priority below 1 is rejected', () => {
  const state = makeState();
  assert.throws(
    () => validateIntervention({ type: 'priority', trainId: 'TA', priority: 0 }, state),
    InvalidInterventionError
  );
  assert.throws(
    () => validateIntervention({ type: 'priority', trainId: 'TA', priority: -2 }, state),
    InvalidInterventionError
  );
});

test('a missing/non-numeric priority is rejected', () => {
  const state = makeState();
  assert.throws(
    () => validateIntervention({ type: 'priority', trainId: 'TA' }, state),
    InvalidInterventionError
  );
  assert.throws(
    () => validateIntervention({ type: 'priority', trainId: 'TA', priority: 'first' }, state),
    InvalidInterventionError
  );
});

// 9. Existing engine is actually reused ------------------------------------------------------
test('runWhatIfSimulation delegates to simulateRailwayState (same output as calling it directly on the modified state)', () => {
  const state = makeState();
  const intervention = { type: 'delay', trainId: 'TA', minutes: 30 };

  const viaWhatIf = runWhatIfSimulation(intervention, state);
  const modifiedState = applyIntervention(intervention, state);
  const direct = simulateRailwayState(modifiedState);

  assert.deepEqual(viaWhatIf, direct);
});

test('engine/whatIf.js source contains no reimplemented conflict/occupancy/ETA algorithm (delegates to engine/index.js)', async () => {
  const fs = await import('node:fs');
  const { fileURLToPath } = await import('node:url');
  const sourcePath = fileURLToPath(new URL('../engine/whatIf.js', import.meta.url));
  const source = fs.readFileSync(sourcePath, 'utf8');

  assert.match(source, /import\s*\{\s*simulateRailwayState\s*\}\s*from\s*'\.\/index\.js'/);
  assert.ok(!/function\s+detectConflicts/.test(source));
  assert.ok(!/function\s+computeResourceOccupancy/.test(source));
  assert.ok(!/function\s+computeConflictDelays/.test(source));
  assert.ok(!/function\s+computeFleetETAs/.test(source));
});

// 10. What-If result is produced successfully, including against the real seed data ----------
test('a what-if run against the real seed data returns a full result for every real train', () => {
  const state = realState();
  const trainId = INITIAL_TRAINS[0].id;
  const result = runWhatIfSimulation({ type: 'delay', trainId, minutes: 10 }, state);

  assert.equal(result.etas.length, INITIAL_TRAINS.length);
  assert.ok(result.etas.every((eta) => 'trainId' in eta && 'predictedETA' in eta && 'totalDelay' in eta));
});

test('a what-if hold and a what-if priority run against the real seed data both succeed', () => {
  const state = realState();
  const holdResult = runWhatIfSimulation({ type: 'hold', trainId: INITIAL_TRAINS[0].id, minutes: 12 }, state);
  const priorityResult = runWhatIfSimulation({ type: 'priority', trainId: INITIAL_TRAINS[1].id, priority: 1 }, state);

  assert.equal(holdResult.etas.length, INITIAL_TRAINS.length);
  assert.equal(priorityResult.etas.length, INITIAL_TRAINS.length);
});
