// tests/phase2.engine.test.js
//
// Focused tests for PHASE 2 CHUNK 1: dynamic event generation + basic
// resource occupancy. Uses Node's built-in test runner (`node --test`).
//
// Synthetic fixtures are used for the core engine behavior tests so they
// stay independent of the real fleet/network data (and therefore keep
// working no matter how data/trains.js or data/network.js evolve). A
// smaller integration test at the bottom exercises the real seed data to
// catch any wiring mistakes between data and engine.

import test from 'node:test';
import assert from 'node:assert/strict';
import { generateTrainEvents, generateAllEvents, EVENT_TYPES } from '../engine/eventGenerator.js';
import { computeResourceOccupancy } from '../engine/resourceOccupancy.js';
import { parseTime, formatTime } from '../engine/timeUtils.js';
import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';

// ---------------------------------------------------------------------
// Synthetic fixture matching the exact example from the spec:
//   A -> B -> C, departure A = 10:00, A->B = 15 min, B dwell = 3 min,
//   B->C = 20 min.
// ---------------------------------------------------------------------
function makeAbcTrain(overrides = {}) {
  return {
    id: 'T-ABC',
    path: ['A', 'B', 'C'],
    scheduledDeparture: '10:00',
    stops: [{ stationId: 'B', dwellMinutes: 3 }],
    ...overrides,
  };
}

function makeAbcTracks(overrides = {}) {
  const base = {
    'A|B': { id: 'A-B', travelMinutes: 15 },
    'B|C': { id: 'B-C', travelMinutes: 20 },
  };
  const merged = { ...base, ...overrides };
  return function findTrack(from, to) {
    return merged[`${from}|${to}`] || merged[`${to}|${from}`] || null;
  };
}

// 1. Event generation for a multi-leg route -----------------------------
test('generates the exact chronological event sequence for a multi-leg route', () => {
  const train = makeAbcTrain();
  const events = generateTrainEvents(train, { findTrack: makeAbcTracks() });

  const simplified = events.map((e) => ({ type: e.type, time: e.time }));

  assert.deepEqual(simplified, [
    { type: EVENT_TYPES.DEPARTURE, time: '10:00' },
    { type: EVENT_TYPES.TRACK_ENTRY, time: '10:00' },
    { type: EVENT_TYPES.TRACK_EXIT, time: '10:15' },
    { type: EVENT_TYPES.ARRIVAL, time: '10:15' },
    { type: EVENT_TYPES.STATION_DEPARTURE, time: '10:18' },
    { type: EVENT_TYPES.TRACK_ENTRY, time: '10:18' },
    { type: EVENT_TYPES.TRACK_EXIT, time: '10:38' },
    { type: EVENT_TYPES.FINAL_ARRIVAL, time: '10:38' },
  ]);

  // Every event carries an id and the train id.
  for (const e of events) {
    assert.equal(e.trainId, 'T-ABC');
    assert.ok(typeof e.id === 'string' && e.id.length > 0);
  }

  // Events are already in chronological (non-decreasing) order.
  for (let i = 1; i < events.length; i++) {
    assert.ok(events[i].minutes >= events[i - 1].minutes);
  }
});

test('works for an arbitrary-length path with a pass-through station (no dwell)', () => {
  const train = {
    id: 'T-PASS',
    path: ['A', 'B', 'C', 'D'],
    scheduledDeparture: '09:00',
    stops: [{ stationId: 'C', dwellMinutes: 5 }], // B is a pass-through, C is a worked stop
  };
  const findTrackFn = (from, to) => {
    const table = {
      'A|B': { id: 'A-B', travelMinutes: 10 },
      'B|C': { id: 'B-C', travelMinutes: 12 },
      'C|D': { id: 'C-D', travelMinutes: 7 },
    };
    return table[`${from}|${to}`] || table[`${to}|${from}`] || null;
  };

  const events = generateTrainEvents(train, { findTrack: findTrackFn });
  const types = events.map((e) => e.type);

  // B must be a passThrough (no arrival/stationDeparture pair for B).
  assert.ok(types.includes(EVENT_TYPES.PASS_THROUGH));
  const bEvents = events.filter((e) => e.stationId === 'B');
  assert.equal(bEvents.length, 1);
  assert.equal(bEvents[0].type, EVENT_TYPES.PASS_THROUGH);

  // C must have a real arrival + stationDeparture pair separated by the dwell.
  const cArrival = events.find((e) => e.stationId === 'C' && e.type === EVENT_TYPES.ARRIVAL);
  const cDeparture = events.find((e) => e.stationId === 'C' && e.type === EVENT_TYPES.STATION_DEPARTURE);
  assert.ok(cArrival && cDeparture);
  assert.equal(cDeparture.minutes - cArrival.minutes, 5);

  // Final arrival is D, with no matching stationDeparture.
  const finalEvent = events[events.length - 1];
  assert.equal(finalEvent.type, EVENT_TYPES.FINAL_ARRIVAL);
  assert.equal(finalEvent.stationId, 'D');
});

test('handles a direct path with zero intermediate stations', () => {
  const train = { id: 'T-DIRECT', path: ['X', 'Y'], scheduledDeparture: '08:00', stops: [] };
  const findTrackFn = () => ({ id: 'X-Y', travelMinutes: 22 });

  const events = generateTrainEvents(train, { findTrack: findTrackFn });
  const types = events.map((e) => e.type);

  assert.deepEqual(types, [
    EVENT_TYPES.DEPARTURE,
    EVENT_TYPES.TRACK_ENTRY,
    EVENT_TYPES.TRACK_EXIT,
    EVENT_TYPES.FINAL_ARRIVAL,
  ]);
  assert.equal(events[events.length - 1].time, '08:22');
});

// 2. Intermediate dwell changes later event times ------------------------
test('increasing an intermediate dwell shifts every downstream event later by the same amount', () => {
  const tracks = makeAbcTracks();
  const before = generateTrainEvents(makeAbcTrain(), { findTrack: tracks });
  const after = generateTrainEvents(
    makeAbcTrain({ stops: [{ stationId: 'B', dwellMinutes: 3 + 10 }] }),
    { findTrack: tracks }
  );

  // Events up to and including the arrival at B are unaffected by B's dwell.
  const uptoArrival = [EVENT_TYPES.DEPARTURE, EVENT_TYPES.TRACK_ENTRY, EVENT_TYPES.TRACK_EXIT, EVENT_TYPES.ARRIVAL];
  for (let i = 0; i < uptoArrival.length; i++) {
    assert.equal(before[i].minutes, after[i].minutes, `event ${i} (${uptoArrival[i]}) should not shift`);
  }

  // Every event from the station departure at B onward shifts by exactly +10.
  for (let i = uptoArrival.length; i < before.length; i++) {
    assert.equal(after[i].minutes - before[i].minutes, 10, `event ${i} should shift by +10`);
  }
});

// 3. Changing travelMinutes changes event times ---------------------------
test('changing a leg travelMinutes changes every downstream event time', () => {
  const before = generateTrainEvents(makeAbcTrain(), { findTrack: makeAbcTracks() });
  const after = generateTrainEvents(makeAbcTrain(), {
    findTrack: makeAbcTracks({ 'A|B': { id: 'A-B', travelMinutes: 15 + 25 } }),
  });

  // Departure from A is unaffected.
  assert.equal(before[0].minutes, after[0].minutes);
  assert.equal(before[1].minutes, after[1].minutes); // track entry A-B unaffected (same departure)

  // Every event from track exit A-B onward shifts by +25.
  for (let i = 2; i < before.length; i++) {
    assert.equal(after[i].minutes - before[i].minutes, 25, `event ${i} should shift by +25`);
  }
});

// 4. Resource occupancy is generated --------------------------------------
test('produces platform and junction occupancy records from generated events', () => {
  const train = makeAbcTrain(); // stops at B for 3 minutes
  const events = generateTrainEvents(train, { findTrack: makeAbcTracks() });
  const resources = [
    { id: 'PLAT-B', label: 'Platform B', stationId: 'B', type: 'platform', capacity: 1 },
    { id: 'JCT-B', label: 'Junction B', stationId: 'B', type: 'junction', capacity: 1 },
    { id: 'PLAT-A', label: 'Platform A', stationId: 'A', type: 'platform', capacity: 1 }, // A is origin, not a worked stop
  ];

  const occupancy = computeResourceOccupancy(events, resources, [train]);

  for (const rec of occupancy) {
    for (const field of ['resourceId', 'trainId', 'startTime', 'endTime']) {
      assert.ok(field in rec, `occupancy record missing '${field}'`);
    }
  }

  const platformRecord = occupancy.find((r) => r.resourceId === 'PLAT-B');
  assert.ok(platformRecord, 'expected a platform occupancy record at B');
  assert.equal(platformRecord.trainId, 'T-ABC');
  assert.equal(platformRecord.startTime, '10:15'); // arrival at B
  assert.equal(platformRecord.endTime, '10:18'); // departure after 3 min dwell

  const junctionRecord = occupancy.find((r) => r.resourceId === 'JCT-B');
  assert.ok(junctionRecord, 'expected a junction occupancy record at B');
  assert.equal(junctionRecord.startTime, '10:13'); // arrival (10:15) - 2 min buffer
  assert.equal(junctionRecord.endTime, '10:17'); // arrival (10:15) + 2 min buffer

  // A is only the origin (no dwell scheduled there) -> no platform record.
  const originPlatformRecord = occupancy.find((r) => r.resourceId === 'PLAT-A');
  assert.equal(originPlatformRecord, undefined);
});

// 5. Changing the schedule changes occupancy -------------------------------
test('shifting scheduledDeparture shifts occupancy times by the same amount', () => {
  const tracks = makeAbcTracks();
  const resources = [
    { id: 'PLAT-B', label: 'Platform B', stationId: 'B', type: 'platform', capacity: 1 },
    { id: 'JCT-B', label: 'Junction B', stationId: 'B', type: 'junction', capacity: 1 },
  ];

  const earlyTrain = makeAbcTrain({ scheduledDeparture: '10:00' });
  const lateTrain = makeAbcTrain({ scheduledDeparture: '10:30' }); // +30 minutes

  const earlyOccupancy = computeResourceOccupancy(
    generateTrainEvents(earlyTrain, { findTrack: tracks }),
    resources,
    [earlyTrain]
  );
  const lateOccupancy = computeResourceOccupancy(
    generateTrainEvents(lateTrain, { findTrack: tracks }),
    resources,
    [lateTrain]
  );

  assert.equal(earlyOccupancy.length, lateOccupancy.length);
  for (let i = 0; i < earlyOccupancy.length; i++) {
    assert.equal(lateOccupancy[i].startMinutes - earlyOccupancy[i].startMinutes, 30);
    assert.equal(lateOccupancy[i].endMinutes - earlyOccupancy[i].endMinutes, 30);
  }
});

// ---------------------------------------------------------------------
// timeUtils sanity (small pure helpers, cheap to pin down directly)
// ---------------------------------------------------------------------
test('parseTime/formatTime round-trip', () => {
  assert.equal(parseTime('00:00'), 0);
  assert.equal(parseTime('10:42'), 642);
  assert.equal(formatTime(642), '10:42');
  assert.equal(formatTime(0), '00:00');
});

// ---------------------------------------------------------------------
// Integration smoke test against the REAL seed data (data/trains.js +
// data/network.js), so a data-wiring mistake (e.g. a stop referencing a
// station not on the path, or a missing track) fails loudly here.
// ---------------------------------------------------------------------
test('generates events and occupancy for the entire real seed fleet without error', () => {
  const events = generateAllEvents(INITIAL_TRAINS, { findTrack });
  assert.ok(events.length > 0);

  // Events are globally sorted by time.
  for (let i = 1; i < events.length; i++) {
    assert.ok(events[i].minutes >= events[i - 1].minutes);
  }

  const occupancy = computeResourceOccupancy(events, RESOURCES, INITIAL_TRAINS);
  // The real network defines a platform (P3) and a junction (J1) at VJA,
  // and several real trains have a worked stop at VJA, so we expect at
  // least some occupancy records to come out the other end.
  assert.ok(occupancy.length > 0);
  for (const rec of occupancy) {
    assert.ok(RESOURCES.some((r) => r.id === rec.resourceId));
    assert.ok(INITIAL_TRAINS.some((t) => t.id === rec.trainId));
  }
});
