// tests/phase2.simulation-optimize.test.js
//
// Focused tests for PHASE 2 CHUNK 14 (OPTIMIZATION API ONLY):
// services/simulationService.js's new getOptimizationRun(...) and
// POST /api/simulation/optimize. Does NOT re-test optimize()/
// generateCandidates()/evaluateIntervention() themselves — see
// tests/phase2.optimization-foundation.test.js (CHUNK 13A) and
// tests/phase2.optimization-complete.test.js (CHUNK 13B), both untouched.
// Uses Node's built-in test runner (`node --test`).

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { getOptimizationRun } from '../services/simulationService.js';
import { InvalidInterventionError } from '../engine/whatIf.js';
import { optimize } from '../engine/optimization/optimizer.js';
import { simulateRailwayState } from '../engine/index.js';
import { computeNetworkDelay } from '../engine/whatIfComparison.js';
import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';
import { createApp, cors } from '../utils/router.js';
import { registerHealthRoutes } from '../routes/health.js';
import { registerTrainRoutes } from '../routes/trains.js';
import { registerNetworkRoutes } from '../routes/network.js';
import { registerAlertRoutes } from '../routes/alerts.js';
import { registerSimulationRoutes } from '../routes/simulation.js';
import { registerOptimizationRoutes } from '../routes/optimization.js';

function realState() {
  return { trains: INITIAL_TRAINS, resources: RESOURCES, findTrack };
}

// ===========================================================================
// services/simulationService.js -> getOptimizationRun(...)
// ===========================================================================

test('getOptimizationRun returns base/bestIntervention/result/score/improvement', () => {
  const body = getOptimizationRun();

  assert.equal(typeof body.base.networkDelay, 'number');
  assert.ok(Array.isArray(body.base.conflicts));
  assert.ok('bestIntervention' in body);
  assert.equal(typeof body.result.networkDelay, 'number');
  assert.ok(Array.isArray(body.result.conflicts));
  assert.equal(typeof body.score, 'number');
  assert.equal(typeof body.improvement, 'number');
  assert.equal(typeof body.candidatesEvaluated, 'number');
  assert.equal(typeof body.improved, 'boolean');
});

test('getOptimizationRun reuses the existing optimize() outcome: same best score and intervention', () => {
  const state = realState();
  const expected = optimize(state);
  const body = getOptimizationRun();

  assert.deepEqual(body.bestIntervention, expected.best.intervention);
  assert.equal(body.score, expected.best.score);
  assert.equal(body.candidatesEvaluated, expected.candidatesEvaluated);
  assert.equal(body.improved, expected.improved);
});

test('getOptimizationRun.base matches a plain simulateRailwayState() over the same state', () => {
  const state = realState();
  const baseResult = simulateRailwayState(state);
  const body = getOptimizationRun();

  assert.equal(body.base.networkDelay, computeNetworkDelay(baseResult.etas));
  assert.deepEqual(body.base.conflicts, baseResult.conflicts);
});

test('getOptimizationRun.improvement is base networkDelay minus best score', () => {
  const body = getOptimizationRun();
  assert.equal(body.improvement, body.base.networkDelay - body.score);
});

test('getOptimizationRun accepts a caller-supplied candidate list and evaluates only that one', () => {
  const trainId = INITIAL_TRAINS[0].id;
  const candidates = [{ type: 'hold', trainId, minutes: 5 }];

  const body = getOptimizationRun(candidates);
  assert.equal(body.candidatesEvaluated, 1);
});

test('getOptimizationRun rejects an unknown train id in a caller-supplied candidate', () => {
  assert.throws(
    () => getOptimizationRun([{ type: 'hold', trainId: 'NOT-REAL', minutes: 5 }]),
    InvalidInterventionError
  );
});

test('getOptimizationRun rejects an unsupported intervention type in a caller-supplied candidate', () => {
  const trainId = INITIAL_TRAINS[0].id;
  assert.throws(
    () => getOptimizationRun([{ type: 'reroute', trainId }]),
    InvalidInterventionError
  );
});

test('getOptimizationRun rejects invalid values (e.g. non-positive minutes) in a caller-supplied candidate', () => {
  const trainId = INITIAL_TRAINS[0].id;
  assert.throws(
    () => getOptimizationRun([{ type: 'hold', trainId, minutes: -5 }]),
    InvalidInterventionError
  );
});

test('getOptimizationRun never mutates the real seed data', () => {
  const snapshotTrains = structuredClone(INITIAL_TRAINS);
  const snapshotResources = structuredClone(RESOURCES);

  getOptimizationRun();

  assert.deepEqual(INITIAL_TRAINS, snapshotTrains);
  assert.deepEqual(RESOURCES, snapshotResources);
});

test('getOptimizationRun leaves the base state usable for an unaffected plain simulation afterwards', () => {
  const state = realState();
  const before = simulateRailwayState(state);

  getOptimizationRun();

  const after = simulateRailwayState(realState());
  assert.deepEqual(before, after);
});

test('simulationService.js optimization additions delegate to the existing optimizer rather than reimplementing it', () => {
  const src = new URL('../services/simulationService.js', import.meta.url);
  const text = readFileSync(src, 'utf8');
  for (const forbidden of ['detectConflicts', 'computeResourceOccupancy', 'computeFleetETAs', 'computeConflictDelays', 'generateCandidates(']) {
    assert.ok(!text.includes(forbidden), `simulationService.js unexpectedly references ${forbidden}`);
  }
  assert.ok(text.includes("from '../engine/optimization/optimizer.js'"), 'should import the existing optimize()');
  assert.ok(text.includes('validateIntervention'), 'should reuse the existing validateIntervention for request validation');
});

// ===========================================================================
// POST /api/simulation/optimize — HTTP level
// ===========================================================================

let server;
let baseUrl;

test.before(async () => {
  const app = createApp();
  app.use(cors());
  registerHealthRoutes(app);
  registerTrainRoutes(app);
  registerNetworkRoutes(app);
  registerAlertRoutes(app);
  registerSimulationRoutes(app);
  registerOptimizationRoutes(app);

  await new Promise((resolve) => {
    server = app.listen(0, resolve);
  });
  const { port } = server.address();
  baseUrl = `http://localhost:${port}`;
});

test.after(() => {
  server.close();
});

test('POST /api/simulation/optimize exists and returns HTTP 200 with no body', async () => {
  const res = await fetch(`${baseUrl}/api/simulation/optimize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({}),
  });
  assert.equal(res.status, 200);
});

test('POST /api/simulation/optimize response matches getOptimizationRun()', async () => {
  const res = await fetch(`${baseUrl}/api/simulation/optimize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({}),
  });
  const body = await res.json();
  assert.deepEqual(body, getOptimizationRun());
});

test('POST /api/simulation/optimize returns the best candidate and its score', async () => {
  const res = await fetch(`${baseUrl}/api/simulation/optimize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({}),
  });
  const body = await res.json();

  assert.ok('bestIntervention' in body);
  assert.equal(typeof body.score, 'number');
  if (body.bestIntervention !== null) {
    assert.ok(['delay', 'hold', 'priority'].includes(body.bestIntervention.type));
  }
});

test('POST /api/simulation/optimize accepts a caller-supplied candidates array', async () => {
  const trainId = INITIAL_TRAINS[0].id;
  const res = await fetch(`${baseUrl}/api/simulation/optimize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ candidates: [{ type: 'hold', trainId, minutes: 5 }] }),
  });
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(body.candidatesEvaluated, 1);
});

test('POST /api/simulation/optimize returns 400 when candidates is not an array', async () => {
  const res = await fetch(`${baseUrl}/api/simulation/optimize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ candidates: 'not-an-array' }),
  });
  assert.equal(res.status, 400);
  const body = await res.json();
  assert.ok(body.error);
});

test('POST /api/simulation/optimize returns 400 for an unknown train id in candidates', async () => {
  const res = await fetch(`${baseUrl}/api/simulation/optimize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ candidates: [{ type: 'hold', trainId: 'NOT-REAL', minutes: 5 }] }),
  });
  assert.equal(res.status, 400);
  const body = await res.json();
  assert.ok(body.error);
});

test('POST /api/simulation/optimize returns 400 for an unsupported intervention type in candidates', async () => {
  const trainId = INITIAL_TRAINS[0].id;
  const res = await fetch(`${baseUrl}/api/simulation/optimize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ candidates: [{ type: 'reroute', trainId }] }),
  });
  assert.equal(res.status, 400);
});

test('POST /api/simulation/optimize does not mutate the base state (base networkDelay is stable across repeated calls)', async () => {
  const res1 = await fetch(`${baseUrl}/api/simulation/optimize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({}),
  });
  const body1 = await res1.json();

  const res2 = await fetch(`${baseUrl}/api/simulation/optimize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({}),
  });
  const body2 = await res2.json();

  assert.deepEqual(body1, body2);
});

test('GET /api/simulation, POST /api/simulation/what-if, and GET /api/optimization still work alongside the new endpoint', async () => {
  const sim = await fetch(`${baseUrl}/api/simulation`);
  assert.equal(sim.status, 200);

  const trainId = INITIAL_TRAINS[0].id;
  const whatIf = await fetch(`${baseUrl}/api/simulation/what-if`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'delay', trainId, minutes: 10 }),
  });
  assert.equal(whatIf.status, 200);

  const opt = await fetch(`${baseUrl}/api/optimization`);
  assert.equal(opt.status, 200);
});
