// tests/phase2.simulation.test.js
//
// Focused tests for PHASE 2 CHUNK 9 (SIMULATION API): GET /api/simulation
// and services/simulationService.js. Boots a real HTTP server (same
// pattern as the other phase2 integration test files) plus direct
// unit-level checks against simulationService.js itself, and a
// full-router smoke test confirming every existing endpoint still works
// alongside the new one. Uses Node's built-in test runner
// (`node --test`).

import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp, cors } from '../utils/router.js';
import { registerHealthRoutes } from '../routes/health.js';
import { registerTrainRoutes } from '../routes/trains.js';
import { registerNetworkRoutes } from '../routes/network.js';
import { registerAlertRoutes } from '../routes/alerts.js';
import { registerSimulationRoutes } from '../routes/simulation.js';
import { getSimulationResult } from '../services/simulationService.js';
import { simulateRailwayState } from '../engine/index.js';
import { buildResourceStates } from '../engine/resourceStateBuilder.js';
import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';

let server;
let baseUrl;

test.before(async () => {
  const app = createApp();
  app.use(cors());
  registerHealthRoutes(app);
  registerTrainRoutes(app);
  registerNetworkRoutes(app);
  registerAlertRoutes(app);
  registerSimulationRoutes(app);

  await new Promise((resolve) => {
    server = app.listen(0, resolve);
  });
  const { port } = server.address();
  baseUrl = `http://localhost:${port}`;
});

test.after(() => {
  server.close();
});

// 1. GET /api/simulation returns HTTP 200 ------------------------------------
test('GET /api/simulation returns HTTP 200', async () => {
  const res = await fetch(`${baseUrl}/api/simulation`);
  assert.equal(res.status, 200);
});

// 2. Response is an object ----------------------------------------------------
test('GET /api/simulation response body is a plain object', async () => {
  const res = await fetch(`${baseUrl}/api/simulation`);
  const body = await res.json();
  assert.equal(typeof body, 'object');
  assert.ok(body !== null);
  assert.ok(!Array.isArray(body));
});

// 3. It contains train results -------------------------------------------------
test('GET /api/simulation includes the fleet the simulation ran against', async () => {
  const res = await fetch(`${baseUrl}/api/simulation`);
  const body = await res.json();
  assert.ok(Array.isArray(body.trains));
  assert.equal(body.trains.length, INITIAL_TRAINS.length);
  assert.deepEqual(
    body.trains.map((t) => t.id).sort(),
    INITIAL_TRAINS.map((t) => t.id).sort()
  );
});

// 4. It contains events ---------------------------------------------------------
test('GET /api/simulation includes engine events', async () => {
  const res = await fetch(`${baseUrl}/api/simulation`);
  const body = await res.json();
  assert.ok(Array.isArray(body.events));
  assert.ok(body.events.length > 0);
});

// 5. It contains occupancy -------------------------------------------------------
test('GET /api/simulation includes resource occupancy', async () => {
  const res = await fetch(`${baseUrl}/api/simulation`);
  const body = await res.json();
  assert.ok(Array.isArray(body.occupancy));
  assert.ok(body.occupancy.length > 0);
});

// 6. It contains conflicts ---------------------------------------------------------
test('GET /api/simulation includes detected conflicts', async () => {
  const res = await fetch(`${baseUrl}/api/simulation`);
  const body = await res.json();
  assert.ok(Array.isArray(body.conflicts));
  assert.ok(body.conflicts.length > 0, 'expected at least one conflict for the real seed data');
});

// 7. It contains propagated delays ---------------------------------------------------
test('GET /api/simulation includes propagated delays', async () => {
  const res = await fetch(`${baseUrl}/api/simulation`);
  const body = await res.json();
  assert.ok(body.propagatedDelays && typeof body.propagatedDelays === 'object');
  assert.ok(Array.isArray(body.propagatedDelays.perConflict));
  assert.ok(typeof body.propagatedDelays.delaysByTrain === 'object');
});

// 8. It contains ETA results -----------------------------------------------------------
test('GET /api/simulation includes ETA results for every train', async () => {
  const res = await fetch(`${baseUrl}/api/simulation`);
  const body = await res.json();
  assert.ok(Array.isArray(body.etas));
  assert.equal(body.etas.length, INITIAL_TRAINS.length);
  for (const eta of body.etas) {
    assert.ok('trainId' in eta);
    assert.ok('scheduledETA' in eta);
    assert.ok('predictedETA' in eta);
    assert.ok('totalDelay' in eta);
  }
});

// Bonus: resourceState is also included, reusing the Chunk 8 aggregator --------
test('GET /api/simulation includes resourceState, matching the same aggregator /api/network uses', async () => {
  const res = await fetch(`${baseUrl}/api/simulation`);
  const body = await res.json();

  const { occupancy, conflicts } = simulateRailwayState({ trains: INITIAL_TRAINS, resources: RESOURCES, findTrack });
  const expected = buildResourceStates({ resources: RESOURCES, occupancy, conflicts });

  assert.deepEqual(body.resourceState, expected);
});

// 9-11. Existing endpoints still work alongside the new one ---------------------
test('GET /api/trains still returns 200 with the full fleet', async () => {
  const res = await fetch(`${baseUrl}/api/trains`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.ok(Array.isArray(body.trains));
  assert.equal(body.trains.length, INITIAL_TRAINS.length);
});

test('GET /api/network still returns stations, tracks, resources, and resourceState', async () => {
  const res = await fetch(`${baseUrl}/api/network`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.ok(Array.isArray(body.stations));
  assert.ok(Array.isArray(body.tracks));
  assert.ok(Array.isArray(body.resources));
  assert.ok(Array.isArray(body.resourceState));
});

test('GET /api/alerts still returns a valid alerts array', async () => {
  const res = await fetch(`${baseUrl}/api/alerts`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.ok(Array.isArray(body.alerts));
});

// Direct unit-level checks against simulationService.js itself (no HTTP layer)
test('simulationService.getSimulationResult() returns every required field with correct shapes', () => {
  const result = getSimulationResult();

  assert.ok(Array.isArray(result.trains));
  assert.ok(Array.isArray(result.events));
  assert.ok(Array.isArray(result.occupancy));
  assert.ok(Array.isArray(result.conflicts));
  assert.ok(Array.isArray(result.etas));
  assert.ok(Array.isArray(result.resourceState));
  assert.ok(result.propagatedDelays && typeof result.propagatedDelays === 'object');
});

test('simulationService.getSimulationResult() matches simulateRailwayState() run directly on the same state', () => {
  const direct = simulateRailwayState({ trains: INITIAL_TRAINS, resources: RESOURCES, findTrack });
  const viaService = getSimulationResult();

  assert.deepEqual(viaService.events, direct.events);
  assert.deepEqual(viaService.occupancy, direct.occupancy);
  assert.deepEqual(viaService.conflicts, direct.conflicts);
  assert.deepEqual(viaService.propagatedDelays, direct.propagatedDelays);
  assert.deepEqual(viaService.etas, direct.etas);
});

test('simulationService.js source contains no hardcoded train/station/resource-id branching', async () => {
  const fs = await import('node:fs');
  const { fileURLToPath } = await import('node:url');
  const sourcePath = fileURLToPath(new URL('../services/simulationService.js', import.meta.url));
  const source = fs.readFileSync(sourcePath, 'utf8');

  assert.ok(!/train\.id\s*===\s*['"`]/.test(source), 'found a literal train.id === "..." comparison');
  assert.ok(!/resourceId\s*===\s*['"`]/.test(source), 'found a literal resourceId === "..." comparison');
});
