// tests/phase2.optimization-foundation.test.js
//
// Focused tests for PHASE 2 CHUNK 13A (OPTIMIZATION FOUNDATION ONLY):
// engine/optimization/optimizer.js (evaluateIntervention, scoreResult).
// Does NOT test candidate search / best-intervention selection / an
// Optimization API — none of that exists yet (see CHUNK 13B). Uses
// Node's built-in test runner (`node --test`).
//
// Same synthetic two-train fixture style as tests/phase2.whatif.test.js
// and tests/phase2.whatif-comparison.test.js, plus a small real-seed-data
// smoke test.

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { evaluateIntervention, scoreResult, InvalidInterventionError } from '../engine/optimization/optimizer.js';
import { runWhatIfSimulation } from '../engine/whatIf.js';
import { simulateRailwayState } from '../engine/index.js';
import { computeNetworkDelay } from '../engine/whatIfComparison.js';
import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';

// ---------------------------------------------------------------------
// Synthetic fixture: two trains sharing a capacity-1 resource, same
// pattern used by tests/phase2.whatif.test.js and
// tests/phase2.whatif-comparison.test.js.
// ---------------------------------------------------------------------
function makeState() {
  const trains = [
    { id: 'TA', priority: 2, path: ['A', 'B'], scheduledDeparture: '10:00', stops: [], delay: 0 },
    { id: 'TB', priority: 1, path: ['A', 'B'], scheduledDeparture: '10:00', stops: [], delay: 0 },
  ];
  const resources = [
    { id: 'JCT-A', label: 'Junction A', stationId: 'A', type: 'junction', capacity: 1, headwaySeconds: 90 },
  ];
  const findTrackFixture = (from, to) => {
    if ((from === 'A' && to === 'B') || (from === 'B' && to === 'A')) {
      return { id: 'TRACK-A-B', travelMinutes: 20 };
    }
    return null;
  };
  return { trains, resources, findTrack: findTrackFixture };
}

function realState() {
  return { trains: INITIAL_TRAINS, resources: RESOURCES, findTrack };
}

// 1. A candidate can be evaluated -------------------------------------------
test('evaluateIntervention evaluates a single candidate and returns intervention, result, and score', () => {
  const state = makeState();
  const candidate = { type: 'delay', trainId: 'TA', minutes: 30 };

  const evaluation = evaluateIntervention(candidate, state);

  assert.equal(evaluation.intervention, candidate);
  assert.ok(evaluation.result && typeof evaluation.result === 'object');
  assert.ok(Array.isArray(evaluation.result.etas));
  assert.ok(Array.isArray(evaluation.result.conflicts));
  assert.equal(typeof evaluation.score, 'number');
});

// 2. Existing What-If simulation is reused, not re-implemented --------------
test('evaluateIntervention produces exactly the same engine result runWhatIfSimulation would for the same candidate', () => {
  const state = makeState();
  const candidate = { type: 'priority', trainId: 'TA', priority: 1 };

  const evaluation = evaluateIntervention(candidate, state);
  const directResult = runWhatIfSimulation(candidate, state);

  assert.deepEqual(evaluation.result, directResult);
});

test('optimizer.js source contains no reimplemented conflict/occupancy/ETA algorithm (delegates to whatIf.js)', () => {
  // Guards against the module quietly growing its own scheduling logic
  // instead of continuing to delegate to engine/whatIf.js ->
  // engine/index.js, per the CHUNK 13A scope restriction.
  const src = new URL('../engine/optimization/optimizer.js', import.meta.url);
  const text = readFileSync(src, 'utf8');
  for (const forbidden of ['detectConflicts', 'computeResourceOccupancy', 'computeFleetETAs', 'computeConflictDelays']) {
    assert.ok(!text.includes(forbidden), `optimizer.js unexpectedly references ${forbidden}`);
  }
  assert.ok(text.includes('runWhatIfSimulation'), 'optimizer.js should call the existing runWhatIfSimulation');
});

// 3. A score is produced ------------------------------------------------------
test('scoreResult reduces an engine result to the same number computeNetworkDelay would produce', () => {
  const state = makeState();
  const baseResult = simulateRailwayState(state);

  const score = scoreResult(baseResult);

  assert.equal(score, computeNetworkDelay(baseResult.etas));
  assert.equal(typeof score, 'number');
});

test('scoreResult rejects a result without an etas array', () => {
  assert.throws(() => scoreResult({}), /etas/);
  assert.throws(() => scoreResult(null), /etas/);
});

// 4. Lower network delay produces a better (lower) score ---------------------
test('a candidate that reduces network delay scores lower than one that increases it', () => {
  const state = makeState();

  // TB has higher precedence (priority 1) than TA (priority 2) and both
  // depart at the same time over a capacity-1 resource, so the base
  // state already has TA yielding to TB with some delay. Holding TA well
  // clear of TB's occupancy removes the conflict entirely (score 0,
  // strictly better than the base state); delaying TB by a small amount
  // instead moves TB later without escaping TA's occupancy window,
  // producing a larger network delay than the base state.
  const improving = evaluateIntervention({ type: 'hold', trainId: 'TA', minutes: 120 }, state);
  const worsening = evaluateIntervention({ type: 'delay', trainId: 'TB', minutes: 5 }, state);

  assert.ok(
    improving.score < worsening.score,
    `expected improving.score (${improving.score}) < worsening.score (${worsening.score})`
  );
});

test('scoring the unmodified base state directly is consistent with scoring a zero-effect-equivalent evaluation', () => {
  const state = makeState();
  const baseResult = simulateRailwayState(state);
  const baseScore = scoreResult(baseResult);

  // A tiny, harmless intervention on an unrelated dimension (raising the
  // already-lower-precedence train's priority number further) should not
  // make the network delay better than the true base state.
  const evaluation = evaluateIntervention({ type: 'priority', trainId: 'TA', priority: 5 }, state);

  assert.ok(evaluation.score >= baseScore - 1e-9);
});

// 5. Base railway state is not mutated ---------------------------------------
test('evaluateIntervention never mutates the base state passed to it', () => {
  const state = makeState();
  const snapshotTrains = structuredClone(state.trains);
  const snapshotResources = structuredClone(state.resources);

  evaluateIntervention({ type: 'delay', trainId: 'TA', minutes: 45 }, state);
  evaluateIntervention({ type: 'hold', trainId: 'TB', minutes: 10 }, state);
  evaluateIntervention({ type: 'priority', trainId: 'TA', priority: 9 }, state);

  assert.deepEqual(state.trains, snapshotTrains);
  assert.deepEqual(state.resources, snapshotResources);
});

test('evaluateIntervention leaves the base state usable for an unaffected plain simulation afterwards', () => {
  const state = makeState();
  const before = simulateRailwayState(state);

  evaluateIntervention({ type: 'delay', trainId: 'TA', minutes: 999 }, state);

  const after = simulateRailwayState(state);
  assert.deepEqual(before, after);
});

// 6. Invalid intervention data is rejected appropriately ----------------------
test('evaluateIntervention rejects an unknown intervention type', () => {
  const state = makeState();
  assert.throws(
    () => evaluateIntervention({ type: 'reroute', trainId: 'TA' }, state),
    InvalidInterventionError
  );
});

test('evaluateIntervention rejects an unknown trainId', () => {
  const state = makeState();
  assert.throws(
    () => evaluateIntervention({ type: 'delay', trainId: 'NOPE', minutes: 10 }, state),
    InvalidInterventionError
  );
});

test('evaluateIntervention rejects a non-positive minutes value for delay/hold', () => {
  const state = makeState();
  assert.throws(
    () => evaluateIntervention({ type: 'delay', trainId: 'TA', minutes: 0 }, state),
    InvalidInterventionError
  );
  assert.throws(
    () => evaluateIntervention({ type: 'hold', trainId: 'TA', minutes: -5 }, state),
    InvalidInterventionError
  );
});

test('evaluateIntervention rejects an invalid priority value', () => {
  const state = makeState();
  assert.throws(
    () => evaluateIntervention({ type: 'priority', trainId: 'TA', priority: 0 }, state),
    InvalidInterventionError
  );
  assert.throws(
    () => evaluateIntervention({ type: 'priority', trainId: 'TA', priority: 1.5 }, state),
    InvalidInterventionError
  );
});

test('evaluateIntervention rejects a malformed candidate object outright, before touching the engine', () => {
  const state = makeState();
  assert.throws(() => evaluateIntervention(null, state), InvalidInterventionError);
  assert.throws(() => evaluateIntervention('delay', state), InvalidInterventionError);
});

// ===========================================================================
// Real seed data smoke test — no hardcoded train/resource IDs; the trainId
// used below is read from the real fleet at test time, not hardcoded.
// ===========================================================================

test('evaluateIntervention works against the real seed data with no hardcoded train or resource IDs', () => {
  const state = realState();
  const someRealTrainId = state.trains[0].id;

  const evaluation = evaluateIntervention({ type: 'delay', trainId: someRealTrainId, minutes: 15 }, state);

  assert.ok(Array.isArray(evaluation.result.etas));
  assert.equal(evaluation.result.etas.length, state.trains.length);
  assert.equal(typeof evaluation.score, 'number');
  assert.ok(Number.isFinite(evaluation.score));
});
