// tests/phase2.network-state.test.js
//
// Focused tests for PHASE 2 CHUNK 8 (NETWORK STATE):
// engine/resourceStateBuilder.js (pure unit tests against constructed
// occupancy/conflict fixtures) and services/networkService.js +
// GET /api/network (integration, against the real seed fleet/network).
// Uses Node's built-in test runner (`node --test`).

import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp, cors } from '../utils/router.js';
import { registerNetworkRoutes } from '../routes/network.js';
import { getNetworkTopology } from '../services/networkService.js';
import { buildResourceStates } from '../engine/resourceStateBuilder.js';
import { simulateRailwayState } from '../engine/index.js';
import { STATIONS, TRACKS, RESOURCES, findTrack } from '../data/network.js';
import { INITIAL_TRAINS } from '../data/trains.js';

// ---------------------------------------------------------------------
// Pure unit tests against engine/resourceStateBuilder.js
// ---------------------------------------------------------------------

const FIXTURE_RESOURCES = [
  { id: 'FREE1', label: 'Unused resource', capacity: 1, headwaySeconds: 60 },
  { id: 'BUSY1', label: 'Busy resource', capacity: 2, headwaySeconds: 60 },
  { id: 'CONF1', label: 'Conflicted resource', capacity: 1, headwaySeconds: 60 },
];

// 7. An available resource is correctly identified --------------------------
test('a resource with no occupancy and no conflicts is "available"', () => {
  const states = buildResourceStates({ resources: FIXTURE_RESOURCES, occupancy: [], conflicts: [] });
  const free = states.find((s) => s.resourceId === 'FREE1');
  assert.ok(free);
  assert.equal(free.status, 'available');
  assert.deepEqual(free.trainIds, []);
  assert.equal(free.conflict, null);
});

// 5. An occupied resource is correctly identified ----------------------------
test('a resource with occupancy but no conflict is "occupied"', () => {
  const occupancy = [
    { resourceId: 'BUSY1', trainId: 'T1', startTime: '10:00', endTime: '10:05', startMinutes: 600, endMinutes: 605 },
  ];
  const states = buildResourceStates({ resources: FIXTURE_RESOURCES, occupancy, conflicts: [] });
  const busy = states.find((s) => s.resourceId === 'BUSY1');
  assert.equal(busy.status, 'occupied');
  assert.deepEqual(busy.trainIds, ['T1']);
  assert.equal(busy.conflict, null);
});

// 6. A conflicting resource is correctly identified --------------------------
test('a resource with a detected conflict is "conflict", even if it also has occupancy', () => {
  const occupancy = [
    { resourceId: 'CONF1', trainId: 'A', startTime: '10:00', endTime: '10:05', startMinutes: 600, endMinutes: 605 },
    { resourceId: 'CONF1', trainId: 'B', startTime: '10:02', endTime: '10:07', startMinutes: 602, endMinutes: 607 },
  ];
  const conflicts = [
    { resourceId: 'CONF1', trainIds: ['A', 'B'], severity: 'capacity', reason: 'overlap' },
  ];
  const states = buildResourceStates({ resources: FIXTURE_RESOURCES, occupancy, conflicts });
  const conflicted = states.find((s) => s.resourceId === 'CONF1');
  assert.equal(conflicted.status, 'conflict');
  assert.deepEqual(conflicted.trainIds, ['A', 'B']);
  assert.ok(Array.isArray(conflicted.conflict));
  assert.equal(conflicted.conflict.length, 1);
  assert.equal(conflicted.conflict[0].severity, 'capacity');
});

test('buildResourceStates returns exactly one entry per static resource, in the given order', () => {
  const states = buildResourceStates({ resources: FIXTURE_RESOURCES, occupancy: [], conflicts: [] });
  assert.equal(states.length, FIXTURE_RESOURCES.length);
  assert.deepEqual(states.map((s) => s.resourceId), FIXTURE_RESOURCES.map((r) => r.id));
});

test('trainIds for a resource merge occupancy trainIds and conflict trainIds without duplicates', () => {
  const occupancy = [
    { resourceId: 'CONF1', trainId: 'A', startTime: '10:00', endTime: '10:05', startMinutes: 600, endMinutes: 605 },
  ];
  const conflicts = [
    { resourceId: 'CONF1', trainIds: ['A', 'C'], severity: 'headway', reason: 'insufficient gap' },
  ];
  const [state] = buildResourceStates({ resources: [FIXTURE_RESOURCES[2]], occupancy, conflicts });
  assert.deepEqual(state.trainIds, ['A', 'C']);
});

test('resourceStateBuilder.js source contains no hardcoded train/station/resource-id branching', async () => {
  const fs = await import('node:fs');
  const { fileURLToPath } = await import('node:url');
  const sourcePath = fileURLToPath(new URL('../engine/resourceStateBuilder.js', import.meta.url));
  const source = fs.readFileSync(sourcePath, 'utf8');

  assert.ok(!/trainId\s*===\s*['"`]/.test(source), 'found a literal trainId === "..." comparison');
  assert.ok(!/resourceId\s*===\s*['"`]/.test(source), 'found a literal resourceId === "..." comparison');
});

// ---------------------------------------------------------------------
// Integration: services/networkService.js + GET /api/network
// ---------------------------------------------------------------------

let server;
let baseUrl;

test.before(async () => {
  const app = createApp();
  app.use(cors());
  registerNetworkRoutes(app);

  await new Promise((resolve) => {
    server = app.listen(0, resolve);
  });
  const { port } = server.address();
  baseUrl = `http://localhost:${port}`;
});

test.after(() => {
  server.close();
});

// 1. /api/network still returns stations -------------------------------------
test('GET /api/network still returns the full stations list, unchanged', async () => {
  const res = await fetch(`${baseUrl}/api/network`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.deepEqual(body.stations, STATIONS);
});

// 2. /api/network still returns tracks ----------------------------------------
test('GET /api/network still returns the full tracks list, unchanged', async () => {
  const res = await fetch(`${baseUrl}/api/network`);
  const body = await res.json();
  assert.deepEqual(body.tracks, TRACKS);
});

// 3. /api/network still returns resources -------------------------------------
test('GET /api/network still returns the full static resources list, unchanged', async () => {
  const res = await fetch(`${baseUrl}/api/network`);
  const body = await res.json();
  assert.deepEqual(body.resources, RESOURCES);
});

// 4. Computed resource state is present ---------------------------------------
test('GET /api/network includes a resourceState array with one entry per resource', async () => {
  const res = await fetch(`${baseUrl}/api/network`);
  const body = await res.json();
  assert.ok(Array.isArray(body.resourceState));
  assert.equal(body.resourceState.length, RESOURCES.length);
  for (const entry of body.resourceState) {
    assert.ok(['available', 'occupied', 'conflict'].includes(entry.status));
    assert.ok(Array.isArray(entry.trainIds));
    assert.ok('resourceId' in entry);
    assert.ok('conflict' in entry);
  }
});

test('networkService resourceState matches buildResourceStates computed directly from the real seed engine run', () => {
  const { occupancy, conflicts } = simulateRailwayState({ trains: INITIAL_TRAINS, resources: RESOURCES, findTrack });
  const expected = buildResourceStates({ resources: RESOURCES, occupancy, conflicts });

  const { resourceState } = getNetworkTopology();
  assert.deepEqual(resourceState, expected);
});

test('the real seed fleet/network produces at least one resource in conflict status (sanity check the engine is really wired in)', () => {
  const { resourceState } = getNetworkTopology();
  assert.ok(
    resourceState.some((r) => r.status === 'conflict'),
    'expected at least one resource with status "conflict" for the real seed data'
  );
});

// 8. Existing Phase 1 fields untouched ----------------------------------------
test('getNetworkTopology() keeps stations/tracks/resources fields exactly as before, adding resourceState alongside them', () => {
  const topology = getNetworkTopology();
  assert.deepEqual(topology.stations, STATIONS);
  assert.deepEqual(topology.tracks, TRACKS);
  assert.deepEqual(topology.resources, RESOURCES);
  assert.ok(Array.isArray(topology.resourceState));
});
