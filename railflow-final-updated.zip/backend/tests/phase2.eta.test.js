// tests/phase2.eta.test.js
//
// Focused tests for PHASE 2 CHUNK 4: ETA calculation. Uses Node's
// built-in test runner (`node --test`).
//
// Synthetic fixtures mirror the style used in phase2.engine.test.js so
// these tests stay independent of the real fleet/network data, plus a
// smaller integration test against the real seed data and against the
// real delayPropagation output.

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { computeTrainETA, computeFleetETAs } from '../engine/etaCalculator.js';
import { detectConflicts } from '../engine/conflictDetector.js';
import { computeConflictDelays } from '../engine/delayPropagation.js';
import { computeResourceOccupancy } from '../engine/resourceOccupancy.js';
import { generateAllEvents } from '../engine/eventGenerator.js';
import { parseTime } from '../engine/timeUtils.js';
import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';

// ---------------------------------------------------------------------
// Synthetic fixture matching the same A -> B -> C shape used elsewhere:
//   departure A = 10:00, A->B = 15 min, B dwell = 3 min, B->C = 20 min.
// Scheduled arrival at C = 10:38.
// ---------------------------------------------------------------------
function makeAbcTrain(overrides = {}) {
  return {
    id: 'T-ABC',
    path: ['A', 'B', 'C'],
    scheduledDeparture: '10:00',
    stops: [{ stationId: 'B', dwellMinutes: 3 }],
    delay: 0,
    ...overrides,
  };
}

function makeAbcTracks(overrides = {}) {
  const base = {
    'A|B': { id: 'A-B', travelMinutes: 15 },
    'B|C': { id: 'B-C', travelMinutes: 20 },
  };
  const merged = { ...base, ...overrides };
  return function findTrackFn(from, to) {
    return merged[`${from}|${to}`] || merged[`${to}|${from}`] || null;
  };
}

// 1. Train with zero delay gets the correct ETA ----------------------------
test('a train with zero delay has scheduledETA === predictedETA and totalDelay 0', () => {
  const train = makeAbcTrain();
  const eta = computeTrainETA(train, { findTrack: makeAbcTracks() });

  assert.equal(eta.trainId, 'T-ABC');
  assert.equal(eta.scheduledETA, '10:38'); // 10:00 + 15 + 3 dwell + 20
  assert.equal(eta.predictedETA, '10:38');
  assert.equal(eta.totalDelay, 0);
});

// 2. Dwell time is included correctly ---------------------------------------
test('dwell time at an intermediate stop is included in the scheduled ETA', () => {
  const noDwellTrain = makeAbcTrain({ stops: [{ stationId: 'B', dwellMinutes: 0 }] });
  const withDwellTrain = makeAbcTrain({ stops: [{ stationId: 'B', dwellMinutes: 12 }] });
  const tracks = makeAbcTracks();

  const noDwellEta = computeTrainETA(noDwellTrain, { findTrack: tracks });
  const withDwellEta = computeTrainETA(withDwellTrain, { findTrack: tracks });

  assert.equal(noDwellEta.scheduledETA, '10:35'); // 10:00 + 15 + 0 + 20
  assert.equal(withDwellEta.scheduledETA, '10:47'); // 10:00 + 15 + 12 + 20
  assert.equal(
    parseTime(withDwellEta.scheduledETA) - parseTime(noDwellEta.scheduledETA),
    12,
    'the extra dwell should shift the scheduled ETA by exactly the dwell difference'
  );
});

// 3. Existing delay shifts predicted ETA ------------------------------------
test('an existing/original delay shifts the predicted ETA but not the scheduled ETA', () => {
  const train = makeAbcTrain({ delay: 9 });
  const eta = computeTrainETA(train, { findTrack: makeAbcTracks() });

  assert.equal(eta.scheduledETA, '10:38'); // unaffected by delay
  assert.equal(eta.predictedETA, '10:47'); // 10:38 + 9
  assert.equal(eta.totalDelay, 9);
});

// 4. Propagated delay shifts predicted ETA -----------------------------------
test('additional delay from delay-propagation shifts the predicted ETA', () => {
  const train = makeAbcTrain({ delay: 0 });
  const eta = computeTrainETA(train, { findTrack: makeAbcTracks() }, 6); // +6 min propagated

  assert.equal(eta.scheduledETA, '10:38');
  assert.equal(eta.predictedETA, '10:44'); // 10:38 + 6
  assert.equal(eta.totalDelay, 6);
});

test('existing delay and propagated delay combine additively into totalDelay', () => {
  const train = makeAbcTrain({ delay: 4 });
  const eta = computeTrainETA(train, { findTrack: makeAbcTracks() }, 6);

  assert.equal(eta.totalDelay, 10); // 4 existing + 6 propagated
  assert.equal(eta.predictedETA, '10:48'); // 10:38 + 10
});

// 4b. Integration: propagated delay actually sourced from --------------------
//     delayPropagation.js's computeConflictDelays (end-to-end wiring check)
test('ETA calculation correctly consumes real delayPropagation output', () => {
  const resources = [{ id: 'R1', capacity: 1, headwaySeconds: 0 }];
  const trains = [
    { id: 'TA', priority: 1, path: ['A', 'B'], scheduledDeparture: '10:00', stops: [], delay: 0 },
    { id: 'TB', priority: 2, path: ['A', 'B'], scheduledDeparture: '10:00', stops: [], delay: 0 },
  ];
  const findTrackFn = () => ({ id: 'A-B', travelMinutes: 20 });

  // Manually construct occupancy for a shared resource R1 that overlaps
  // for both trains (both run A->B at the same time on a capacity-1
  // resource), to drive a real conflict + delay through the pipeline.
  const occupancies = [
    { resourceId: 'R1', trainId: 'TA', startTime: '10:00', endTime: '10:20', startMinutes: 600, endMinutes: 620 },
    { resourceId: 'R1', trainId: 'TB', startTime: '10:00', endTime: '10:20', startMinutes: 600, endMinutes: 620 },
  ];
  const conflicts = detectConflicts(occupancies, resources);
  assert.equal(conflicts.length, 1);

  const delayResult = computeConflictDelays({ occupancies, conflicts, resources, trains });
  assert.ok(delayResult.delaysByTrain.TB > 0);

  const etas = computeFleetETAs(trains, { findTrack: findTrackFn }, delayResult.delaysByTrain);
  const etaA = etas.find((e) => e.trainId === 'TA');
  const etaB = etas.find((e) => e.trainId === 'TB');

  assert.equal(etaA.totalDelay, 0);
  assert.equal(etaA.predictedETA, etaA.scheduledETA);
  assert.equal(etaB.totalDelay, delayResult.delaysByTrain.TB);
  assert.equal(
    parseTime(etaB.predictedETA) - parseTime(etaB.scheduledETA),
    delayResult.delaysByTrain.TB
  );
});

// 5. Multiple stops are handled correctly ------------------------------------
test('multiple stops with different dwell times are all accounted for', () => {
  const train = {
    id: 'T-MULTI',
    path: ['A', 'B', 'C', 'D'],
    scheduledDeparture: '08:00',
    stops: [
      { stationId: 'B', dwellMinutes: 4 },
      { stationId: 'C', dwellMinutes: 6 },
    ],
    delay: 0,
  };
  const findTrackFn = (from, to) => {
    const table = {
      'A|B': { id: 'A-B', travelMinutes: 10 },
      'B|C': { id: 'B-C', travelMinutes: 15 },
      'C|D': { id: 'C-D', travelMinutes: 5 },
    };
    return table[`${from}|${to}`] || table[`${to}|${from}`] || null;
  };

  const eta = computeTrainETA(train, { findTrack: findTrackFn });
  // 08:00 + 10 + 4(dwell B) + 15 + 6(dwell C) + 5 = 08:40
  assert.equal(eta.scheduledETA, '08:40');
  assert.equal(eta.predictedETA, '08:40');
});

// 6. Different path lengths work correctly -----------------------------------
test('a direct 2-station path (no intermediate stops) works correctly', () => {
  const train = { id: 'T-DIRECT', path: ['X', 'Y'], scheduledDeparture: '08:00', stops: [], delay: 0 };
  const findTrackFn = () => ({ id: 'X-Y', travelMinutes: 22 });

  const eta = computeTrainETA(train, { findTrack: findTrackFn });
  assert.equal(eta.scheduledETA, '08:22');
  assert.equal(eta.predictedETA, '08:22');
});

test('a long multi-leg path (5 stations, 2 worked stops, 2 pass-throughs) works correctly', () => {
  const train = {
    id: 'T-LONG',
    path: ['A', 'B', 'C', 'D', 'E'],
    scheduledDeparture: '06:00',
    stops: [{ stationId: 'C', dwellMinutes: 2 }], // B and D are pass-throughs
    delay: 1,
  };
  const findTrackFn = (from, to) => {
    const table = {
      'A|B': { id: 'A-B', travelMinutes: 8 },
      'B|C': { id: 'B-C', travelMinutes: 9 },
      'C|D': { id: 'C-D', travelMinutes: 7 },
      'D|E': { id: 'D-E', travelMinutes: 11 },
    };
    return table[`${from}|${to}`] || table[`${to}|${from}`] || null;
  };

  const eta = computeTrainETA(train, { findTrack: findTrackFn });
  // 06:00 + 8 + 9 + 2(dwell C) + 7 + 11 = 06:37 scheduled; +1 delay = 06:38
  assert.equal(eta.scheduledETA, '06:37');
  assert.equal(eta.predictedETA, '06:38');
  assert.equal(eta.totalDelay, 1);
});

// computeFleetETAs sanity: returns one entry per train, correctly keyed
test('computeFleetETAs returns one ETA per train, matched by trainId', () => {
  const trains = [
    makeAbcTrain({ id: 'T1', delay: 0 }),
    makeAbcTrain({ id: 'T2', delay: 5 }),
  ];
  const etas = computeFleetETAs(trains, { findTrack: makeAbcTracks() }, { T2: 2 });

  assert.equal(etas.length, 2);
  const eta1 = etas.find((e) => e.trainId === 'T1');
  const eta2 = etas.find((e) => e.trainId === 'T2');
  assert.equal(eta1.totalDelay, 0);
  assert.equal(eta2.totalDelay, 7); // 5 existing + 2 propagated
});

// ---------------------------------------------------------------------
// Integration smoke test against the REAL seed data + real occupancy /
// conflict / delay pipeline, so a wiring mistake fails loudly here.
// ---------------------------------------------------------------------
test('computes ETAs for the entire real seed fleet without error, wired through the real pipeline', () => {
  const events = generateAllEvents(INITIAL_TRAINS, { findTrack });
  const occupancy = computeResourceOccupancy(events, RESOURCES, INITIAL_TRAINS);
  const conflicts = detectConflicts(occupancy, RESOURCES);
  const delayResult = computeConflictDelays({
    occupancies: occupancy,
    conflicts,
    resources: RESOURCES,
    trains: INITIAL_TRAINS,
  });

  const etas = computeFleetETAs(INITIAL_TRAINS, { findTrack }, delayResult.delaysByTrain);

  assert.equal(etas.length, INITIAL_TRAINS.length);
  for (const eta of etas) {
    assert.ok(INITIAL_TRAINS.some((t) => t.id === eta.trainId));
    assert.ok(typeof eta.scheduledETA === 'string' && /^\d{2}:\d{2}$/.test(eta.scheduledETA));
    assert.ok(typeof eta.predictedETA === 'string' && /^\d{2}:\d{2}$/.test(eta.predictedETA));
    assert.ok(typeof eta.totalDelay === 'number');
    assert.ok(eta.totalDelay >= 0);
  }
});

test('etaCalculator.js source contains no hardcoded train/station/resource-id branching', () => {
  const sourcePath = fileURLToPath(new URL('../engine/etaCalculator.js', import.meta.url));
  const source = fs.readFileSync(sourcePath, 'utf8');

  assert.ok(!/trainId\s*===\s*['"`]/.test(source), 'found a literal trainId === "..." comparison');
  assert.ok(!/stationId\s*===\s*['"`]/.test(source), 'found a literal stationId === "..." comparison');
});
