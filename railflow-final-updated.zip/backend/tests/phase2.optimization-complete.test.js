// tests/phase2.optimization-complete.test.js
//
// Focused tests for PHASE 2 CHUNK 13B (COMPLETE OPTIMIZATION):
// engine/optimization/candidateGenerator.js (generateCandidates) and
// engine/optimization/optimizer.js's new optimize(...), plus
// services/optimizationService.js and GET /api/optimization. Does NOT
// re-test evaluateIntervention/scoreResult themselves — see
// tests/phase2.optimization-foundation.test.js (CHUNK 13A, untouched).
// Uses Node's built-in test runner (`node --test`).

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { generateCandidates } from '../engine/optimization/candidateGenerator.js';
import { optimize, evaluateIntervention } from '../engine/optimization/optimizer.js';
import { simulateRailwayState } from '../engine/index.js';
import { computeNetworkDelay } from '../engine/whatIfComparison.js';
import { WHAT_IF_INTERVENTION_TYPES } from '../engine/whatIf.js';
import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';
import { createApp, cors } from '../utils/router.js';
import { registerHealthRoutes } from '../routes/health.js';
import { registerTrainRoutes } from '../routes/trains.js';
import { registerNetworkRoutes } from '../routes/network.js';
import { registerAlertRoutes } from '../routes/alerts.js';
import { registerSimulationRoutes } from '../routes/simulation.js';
import { registerOptimizationRoutes } from '../routes/optimization.js';
import { getOptimizationResult } from '../services/optimizationService.js';

// ---------------------------------------------------------------------
// Synthetic fixture: two trains sharing a capacity-1 resource — same
// pattern used throughout the phase2 What-If / optimization-foundation
// test files, guaranteed to produce at least one conflict.
// ---------------------------------------------------------------------
function makeConflictState() {
  const trains = [
    { id: 'TA', priority: 2, path: ['A', 'B'], scheduledDeparture: '10:00', stops: [], delay: 0 },
    { id: 'TB', priority: 1, path: ['A', 'B'], scheduledDeparture: '10:00', stops: [], delay: 0 },
  ];
  const resources = [
    { id: 'JCT-A', label: 'Junction A', stationId: 'A', type: 'junction', capacity: 1, headwaySeconds: 90 },
  ];
  const findTrackFixture = (from, to) => {
    if ((from === 'A' && to === 'B') || (from === 'B' && to === 'A')) {
      return { id: 'TRACK-A-B', travelMinutes: 20 };
    }
    return null;
  };
  return { trains, resources, findTrack: findTrackFixture };
}

function makeConflictFreeState() {
  const trains = [
    { id: 'TA', priority: 1, path: ['A', 'B'], scheduledDeparture: '10:00', stops: [], delay: 0 },
    { id: 'TB', priority: 2, path: ['A', 'B'], scheduledDeparture: '12:00', stops: [], delay: 0 },
  ];
  const resources = [
    { id: 'JCT-A', label: 'Junction A', stationId: 'A', type: 'junction', capacity: 1, headwaySeconds: 90 },
  ];
  const findTrackFixture = (from, to) => {
    if ((from === 'A' && to === 'B') || (from === 'B' && to === 'A')) {
      return { id: 'TRACK-A-B', travelMinutes: 20 };
    }
    return null;
  };
  return { trains, resources, findTrack: findTrackFixture };
}

function realState() {
  return { trains: INITIAL_TRAINS, resources: RESOURCES, findTrack };
}

// ===========================================================================
// candidateGenerator.js
// ===========================================================================

test('generateCandidates proposes candidates for a state with a real conflict', () => {
  const state = makeConflictState();
  const candidates = generateCandidates(state);

  assert.ok(candidates.length > 0, 'expected at least one candidate for a conflicting state');
  for (const c of candidates) {
    assert.ok(WHAT_IF_INTERVENTION_TYPES.includes(c.type), `unexpected candidate type ${c.type}`);
    assert.ok(['TA', 'TB'].includes(c.trainId));
  }
});

test('generateCandidates proposes no candidates when there are no conflicts', () => {
  const state = makeConflictFreeState();
  const candidates = generateCandidates(state);
  assert.deepEqual(candidates, []);
});

test('generateCandidates only uses existing What-If intervention types (hold/priority), never a new type', () => {
  const state = makeConflictState();
  const candidates = generateCandidates(state);
  for (const c of candidates) {
    assert.ok(c.type === 'hold' || c.type === 'priority');
  }
});

test('generateCandidates produces valid, positive minutes for every hold candidate', () => {
  const state = makeConflictState();
  const candidates = generateCandidates(state).filter((c) => c.type === 'hold');
  assert.ok(candidates.length > 0);
  for (const c of candidates) {
    assert.equal(typeof c.minutes, 'number');
    assert.ok(c.minutes > 0);
  }
});

test('generateCandidates produces valid positive-integer priorities for every priority candidate', () => {
  const state = makeConflictState();
  const candidates = generateCandidates(state).filter((c) => c.type === 'priority');
  assert.ok(candidates.length > 0);
  for (const c of candidates) {
    assert.ok(Number.isInteger(c.priority));
    assert.ok(c.priority >= 1);
  }
});

test('generateCandidates deduplicates identical candidates', () => {
  const state = makeConflictState();
  const candidates = generateCandidates(state);
  const keys = candidates.map((c) => JSON.stringify(c, Object.keys(c).sort()));
  assert.equal(new Set(keys).size, keys.length);
});

test('generateCandidates never mutates the base state', () => {
  const state = makeConflictState();
  const snapshotTrains = structuredClone(state.trains);
  generateCandidates(state);
  assert.deepEqual(state.trains, snapshotTrains);
});

test('every candidate generateCandidates proposes is independently evaluable via the existing evaluateIntervention', () => {
  const state = makeConflictState();
  const candidates = generateCandidates(state);
  for (const candidate of candidates) {
    const evaluation = evaluateIntervention(candidate, state);
    assert.equal(typeof evaluation.score, 'number');
    assert.ok(Number.isFinite(evaluation.score));
  }
});

test('candidateGenerator.js source contains no reimplemented conflict/occupancy/ETA algorithm', () => {
  const src = new URL('../engine/optimization/candidateGenerator.js', import.meta.url);
  const text = readFileSync(src, 'utf8');
  for (const forbidden of ['detectConflicts', 'computeResourceOccupancy', 'computeFleetETAs', 'computeConflictDelays']) {
    assert.ok(!text.includes(forbidden), `candidateGenerator.js unexpectedly references ${forbidden}`);
  }
  assert.ok(text.includes('simulateRailwayState'), 'candidateGenerator.js should call the existing simulateRailwayState');
});

test('generateCandidates works against the real seed data with no hardcoded train or resource IDs', () => {
  const state = realState();
  const candidates = generateCandidates(state);
  // Whatever candidates come back (zero or more, depending on the real
  // seed's conflicts) must reference real train ids and nothing else.
  const realIds = new Set(state.trains.map((t) => t.id));
  for (const c of candidates) {
    assert.ok(realIds.has(c.trainId));
  }
});

// ===========================================================================
// optimizer.js -> optimize(...)
// ===========================================================================

test('optimize returns a baseline, evaluations, and a best pick', () => {
  const state = makeConflictState();
  const outcome = optimize(state);

  assert.equal(typeof outcome.baseline.score, 'number');
  assert.ok(Array.isArray(outcome.evaluations));
  assert.equal(outcome.candidatesEvaluated, outcome.evaluations.length);
  assert.ok(outcome.best && typeof outcome.best.score === 'number');
  assert.equal(typeof outcome.improved, 'boolean');
});

test('optimize selects an intervention that produces the lowest score among everything evaluated', () => {
  const state = makeConflictState();
  const outcome = optimize(state);

  const allScores = [outcome.baseline.score, ...outcome.evaluations.map((e) => e.score)];
  const minScore = Math.min(...allScores);
  assert.ok(outcome.best.score <= minScore + 1e-9);
  assert.equal(outcome.best.score, minScore);
});

test('optimize reuses the existing What-If simulation result shape for its best pick', () => {
  const state = makeConflictState();
  const outcome = optimize(state);

  if (outcome.best.intervention !== null) {
    assert.ok(Array.isArray(outcome.best.result.etas));
    assert.ok(Array.isArray(outcome.best.result.conflicts));
    assert.equal(outcome.best.score, computeNetworkDelay(outcome.best.result.etas));
  }
});

test('optimize falls back to "no intervention" (best.intervention === null) when nothing improves on the baseline', () => {
  const state = makeConflictFreeState();
  const outcome = optimize(state);

  assert.equal(outcome.candidatesEvaluated, 0);
  assert.equal(outcome.best.intervention, null);
  assert.equal(outcome.improved, false);
  assert.equal(outcome.best.score, outcome.baseline.score);
  assert.deepEqual(outcome.best.result, simulateRailwayState(state));
});

test('optimize marks improved=true and best.intervention non-null when a candidate beats the baseline', () => {
  const state = makeConflictState();
  const outcome = optimize(state);

  // The synthetic conflict fixture always has a strictly-better
  // intervention available (holding the lower-precedence train clear, or
  // swapping precedence) — see phase2.optimization-foundation.test.js's
  // equivalent assertion for evaluateIntervention.
  assert.equal(outcome.improved, true);
  assert.notEqual(outcome.best.intervention, null);
  assert.ok(outcome.best.score < outcome.baseline.score);
});

test('optimize accepts a caller-supplied candidate list instead of generating one', () => {
  const state = makeConflictState();
  const manualCandidates = [{ type: 'hold', trainId: 'TA', minutes: 200 }];

  const outcome = optimize(state, { candidates: manualCandidates });

  assert.equal(outcome.candidatesEvaluated, 1);
  assert.deepEqual(outcome.evaluations[0].intervention, manualCandidates[0]);
});

test('optimize never mutates the base state', () => {
  const state = makeConflictState();
  const snapshotTrains = structuredClone(state.trains);
  const snapshotResources = structuredClone(state.resources);

  optimize(state);

  assert.deepEqual(state.trains, snapshotTrains);
  assert.deepEqual(state.resources, snapshotResources);
});

test('optimize leaves the base state usable for an unaffected plain simulation afterwards', () => {
  const state = makeConflictState();
  const before = simulateRailwayState(state);

  optimize(state);

  const after = simulateRailwayState(state);
  assert.deepEqual(before, after);
});

test('optimize rejects a state without a trains array', () => {
  assert.throws(() => optimize({}), /trains/);
  assert.throws(() => optimize(null), /trains/);
});

test('optimizer.js source still delegates rather than reimplementing engine algorithms (13B additions included)', () => {
  const src = new URL('../engine/optimization/optimizer.js', import.meta.url);
  const text = readFileSync(src, 'utf8');
  for (const forbidden of ['detectConflicts', 'computeResourceOccupancy', 'computeFleetETAs', 'computeConflictDelays']) {
    assert.ok(!text.includes(forbidden), `optimizer.js unexpectedly references ${forbidden}`);
  }
  assert.ok(text.includes('generateCandidates'), 'optimize() should call the existing generateCandidates');
  assert.ok(text.includes('runWhatIfSimulation'), 'optimizer.js should still call the existing runWhatIfSimulation');
});

test('optimize works against the real seed data with no hardcoded train or resource IDs', () => {
  const state = realState();
  const outcome = optimize(state);

  assert.equal(typeof outcome.baseline.score, 'number');
  assert.ok(Number.isFinite(outcome.baseline.score));
  assert.ok(outcome.best.score <= outcome.baseline.score + 1e-9);
});

// ===========================================================================
// services/optimizationService.js
// ===========================================================================

test('getOptimizationResult assembles the optimize() outcome into the service response shape', () => {
  const body = getOptimizationResult();

  assert.equal(typeof body.baseline.score, 'number');
  assert.ok(Array.isArray(body.evaluations));
  assert.equal(typeof body.candidatesEvaluated, 'number');
  assert.equal(typeof body.improved, 'boolean');
  assert.ok('intervention' in body.best);
  assert.ok(Array.isArray(body.best.etas));
  assert.ok(Array.isArray(body.best.conflicts));
});

test('getOptimizationResult never mutates the real seed data', () => {
  const snapshotTrains = structuredClone(INITIAL_TRAINS);
  getOptimizationResult();
  assert.deepEqual(INITIAL_TRAINS, snapshotTrains);
});

// ===========================================================================
// GET /api/optimization
// ===========================================================================

let server;
let baseUrl;

test.before(async () => {
  const app = createApp();
  app.use(cors());
  registerHealthRoutes(app);
  registerTrainRoutes(app);
  registerNetworkRoutes(app);
  registerAlertRoutes(app);
  registerSimulationRoutes(app);
  registerOptimizationRoutes(app);

  await new Promise((resolve) => {
    server = app.listen(0, resolve);
  });
  const { port } = server.address();
  baseUrl = `http://localhost:${port}`;
});

test.after(() => {
  server.close();
});

test('GET /api/optimization returns HTTP 200 with the expected shape', async () => {
  const res = await fetch(`${baseUrl}/api/optimization`);
  assert.equal(res.status, 200);

  const body = await res.json();
  assert.equal(typeof body.baseline.score, 'number');
  assert.ok(Array.isArray(body.evaluations));
  assert.ok('intervention' in body.best);
  assert.equal(typeof body.improved, 'boolean');
});

test('GET /api/optimization matches services/optimizationService.js output', async () => {
  const res = await fetch(`${baseUrl}/api/optimization`);
  const body = await res.json();
  assert.deepEqual(body, getOptimizationResult());
});

test('GET /api/optimization does not affect the still-existing GET /api/simulation endpoint', async () => {
  const res = await fetch(`${baseUrl}/api/simulation`);
  assert.equal(res.status, 200);
});
