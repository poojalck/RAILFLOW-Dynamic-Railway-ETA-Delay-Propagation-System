// tests/phase1.api.test.js
//
// Phase 1 smoke tests: the server boots, the health check responds, and
// the trains/network/alerts endpoints serve the expected shapes. Uses
// Node's built-in test runner (`node --test`) — no extra dependency.

import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp, cors } from '../utils/router.js';
import { registerHealthRoutes } from '../routes/health.js';
import { registerTrainRoutes } from '../routes/trains.js';
import { registerNetworkRoutes } from '../routes/network.js';
import { registerAlertRoutes } from '../routes/alerts.js';

let server;
let baseUrl;

test.before(async () => {
  const app = createApp();
  app.use(cors());
  registerHealthRoutes(app);
  registerTrainRoutes(app);
  registerNetworkRoutes(app);
  registerAlertRoutes(app);

  await new Promise((resolve) => {
    server = app.listen(0, resolve);
  });
  const { port } = server.address();
  baseUrl = `http://localhost:${port}`;
});

test.after(() => {
  server.close();
});

test('GET /api/health returns ok status', async () => {
  const res = await fetch(`${baseUrl}/api/health`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(body.status, 'ok');
});

test('GET /api/trains returns the full fleet with expected fields', async () => {
  const res = await fetch(`${baseUrl}/api/trains`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.ok(Array.isArray(body.trains));
  assert.ok(body.trains.length > 0);
  const t = body.trains[0];
  for (const field of ['id', 'routeLabel', 'path', 'delay', 'status', 'scheduledETA', 'predictedETA']) {
    assert.ok(field in t, `train is missing field '${field}'`);
  }
});

test('GET /api/trains/:id returns a single matching train', async () => {
  const res = await fetch(`${baseUrl}/api/trains/12601`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(body.train.id, '12601');
});

test('GET /api/trains/:id 404s for an unknown id', async () => {
  const res = await fetch(`${baseUrl}/api/trains/NOPE`);
  assert.equal(res.status, 404);
});

test('GET /api/network returns stations, tracks, and resources', async () => {
  const res = await fetch(`${baseUrl}/api/network`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.ok(Array.isArray(body.stations) && body.stations.length > 0);
  assert.ok(Array.isArray(body.tracks) && body.tracks.length > 0);
  assert.ok(Array.isArray(body.resources) && body.resources.length > 0);
});

test('GET /api/alerts returns the seed alert list', async () => {
  const res = await fetch(`${baseUrl}/api/alerts`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.ok(Array.isArray(body.alerts));
});

test('every train path only references tracks that exist in the network', async () => {
  const [trainsRes, networkRes] = await Promise.all([fetch(`${baseUrl}/api/trains`), fetch(`${baseUrl}/api/network`)]);
  const { trains } = await trainsRes.json();
  const { tracks } = await networkRes.json();
  const trackKeys = new Set();
  tracks.forEach((t) => {
    trackKeys.add(`${t.source}|${t.target}`);
    trackKeys.add(`${t.target}|${t.source}`);
  });

  for (const train of trains) {
    for (let i = 0; i < train.path.length - 1; i++) {
      const key = `${train.path[i]}|${train.path[i + 1]}`;
      assert.ok(trackKeys.has(key), `train ${train.id} references a non-existent track ${key}`);
    }
  }
});
