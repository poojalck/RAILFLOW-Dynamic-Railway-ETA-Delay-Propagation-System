// tests/phase2.conflict.test.js
//
// Focused tests for PHASE 2 CHUNK 2: resource conflict detection.
// Uses Node's built-in test runner (`node --test`).
//
// Synthetic occupancy fixtures are used throughout so these tests stay
// independent of the real fleet/network data and exercise the detector's
// generic behavior directly (capacity, headway, multiple resources).

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { detectConflicts } from '../engine/conflictDetector.js';
import { parseTime } from '../engine/timeUtils.js';

// Build a synthetic occupancy record directly from "HH:MM" strings so
// tests read naturally, without going through the full event/occupancy
// pipeline.
function occ(resourceId, trainId, startTime, endTime) {
  return {
    resourceId,
    trainId,
    startTime,
    endTime,
    startMinutes: parseTime(startTime),
    endMinutes: parseTime(endTime),
  };
}

// 1. Non-overlapping trains -> no conflict --------------------------------
test('non-overlapping occupancies on a capacity-1 resource produce no conflict', () => {
  const resources = [{ id: 'R1', capacity: 1, headwaySeconds: 0 }];
  const occupancies = [
    occ('R1', 'TA', '10:00', '10:10'),
    occ('R1', 'TB', '10:20', '10:30'),
  ];

  const conflicts = detectConflicts(occupancies, resources);
  assert.deepEqual(conflicts, []);
});

// 2. Two trains occupying the same capacity-1 resource simultaneously ----
test('two trains overlapping on a capacity-1 resource produce a capacity conflict', () => {
  const resources = [{ id: 'R1', capacity: 1, headwaySeconds: 0 }];
  const occupancies = [
    occ('R1', 'TA', '10:00', '10:15'),
    occ('R1', 'TB', '10:10', '10:20'), // overlaps TA from 10:10-10:15
  ];

  const conflicts = detectConflicts(occupancies, resources);
  assert.equal(conflicts.length, 1);
  assert.equal(conflicts[0].resourceId, 'R1');
  assert.deepEqual(conflicts[0].trainIds, ['TA', 'TB']);
  assert.equal(conflicts[0].severity, 'capacity');
  assert.ok(conflicts[0].reason.length > 0);
});

// 3. Occupancies separated by sufficient headway -> no conflict ----------
test('occupancies separated by at least the required headway produce no conflict', () => {
  const resources = [{ id: 'R1', capacity: 1, headwaySeconds: 120 }]; // 2 min
  const occupancies = [
    occ('R1', 'TA', '10:00', '10:10'),
    occ('R1', 'TB', '10:12', '10:20'), // exactly 2 min gap
  ];

  const conflicts = detectConflicts(occupancies, resources);
  assert.deepEqual(conflicts, []);
});

// 4. Occupancies inside the headway window -> conflict --------------------
test('occupancies with a gap smaller than the required headway produce a headway conflict', () => {
  const resources = [{ id: 'R1', capacity: 1, headwaySeconds: 300 }]; // 5 min
  const occupancies = [
    occ('R1', 'TA', '10:00', '10:10'),
    occ('R1', 'TB', '10:12', '10:20'), // only 2 min gap, needs 5
  ];

  const conflicts = detectConflicts(occupancies, resources);
  assert.equal(conflicts.length, 1);
  assert.equal(conflicts[0].severity, 'headway');
  assert.deepEqual(conflicts[0].trainIds, ['TA', 'TB']);
});

// 5. Resource capacity > 1 allows the appropriate number of simultaneous --
//    trains --------------------------------------------------------------
test('a capacity-2 resource allows two simultaneous trains without conflict', () => {
  const resources = [{ id: 'R1', capacity: 2, headwaySeconds: 0 }];
  const occupancies = [
    occ('R1', 'TA', '10:00', '10:20'),
    occ('R1', 'TB', '10:05', '10:15'), // both within capacity of 2
  ];

  const conflicts = detectConflicts(occupancies, resources);
  assert.deepEqual(conflicts, []);
});

test('a capacity-2 resource flags a conflict once a third train overlaps beyond capacity', () => {
  const resources = [{ id: 'R1', capacity: 2, headwaySeconds: 0 }];
  const occupancies = [
    occ('R1', 'TA', '10:00', '10:20'),
    occ('R1', 'TB', '10:05', '10:15'),
    occ('R1', 'TC', '10:08', '10:12'), // pushes concurrency to 3, above capacity 2
  ];

  const conflicts = detectConflicts(occupancies, resources);
  assert.ok(conflicts.length > 0);
  assert.ok(conflicts.every((c) => c.severity === 'capacity'));
  const involvedTrains = new Set(conflicts.flatMap((c) => c.trainIds));
  assert.ok(involvedTrains.has('TC'));
});

// 6. Multiple resources are handled independently -------------------------
test('conflicts on one resource do not leak onto an unrelated resource', () => {
  const resources = [
    { id: 'R1', capacity: 1, headwaySeconds: 0 },
    { id: 'R2', capacity: 1, headwaySeconds: 0 },
  ];
  const occupancies = [
    occ('R1', 'TA', '10:00', '10:15'),
    occ('R1', 'TB', '10:05', '10:20'), // overlap on R1
    occ('R2', 'TC', '10:00', '10:15'),
    occ('R2', 'TD', '11:00', '11:15'), // no overlap on R2
  ];

  const conflicts = detectConflicts(occupancies, resources);
  assert.equal(conflicts.length, 1);
  assert.equal(conflicts[0].resourceId, 'R1');
  assert.deepEqual(conflicts[0].trainIds, ['TA', 'TB']);
});

// 7. No train-ID-specific logic exists --------------------------------------
test('detector works identically for arbitrary/anonymous train and resource ids (fully generic)', () => {
  const resources = [{ id: 'zzz-resource-42', capacity: 1, headwaySeconds: 0 }];
  const occupancies = [
    occ('zzz-resource-42', 'train-alpha-xyz', '05:00', '05:10'),
    occ('zzz-resource-42', 'train-beta-abc', '05:05', '05:12'),
  ];

  const conflicts = detectConflicts(occupancies, resources);
  assert.equal(conflicts.length, 1);
  assert.deepEqual(conflicts[0].trainIds, ['train-alpha-xyz', 'train-beta-abc']);
});

test('conflictDetector.js source contains no hardcoded train-id-specific branching', () => {
  const sourcePath = fileURLToPath(new URL('../engine/conflictDetector.js', import.meta.url));
  const source = fs.readFileSync(sourcePath, 'utf8');

  // Guard against the exact anti-pattern called out in the spec, and more
  // generally against any literal comparison against a specific train id.
  assert.ok(!/trainId\s*===\s*['"`]/.test(source), 'found a literal trainId === "..." comparison');
  assert.ok(!/===\s*['"`]12601['"`]/.test(source), 'found a hardcoded specific train id');
});
