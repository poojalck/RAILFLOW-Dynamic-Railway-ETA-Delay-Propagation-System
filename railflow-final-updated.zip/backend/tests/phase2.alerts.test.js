// tests/phase2.alerts.test.js
//
// Focused tests for PHASE 2 CHUNK 6 (ALERTS): engine/alertGenerator.js
// (pure unit tests against constructed conflict/delay fixtures) and
// services/alertService.js + GET /api/alerts (integration, against the
// real seed fleet/network). Uses Node's built-in test runner
// (`node --test`).

import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp, cors } from '../utils/router.js';
import { registerAlertRoutes } from '../routes/alerts.js';
import { getAllAlerts } from '../services/alertService.js';
import {
  generateAlerts,
  generateConflictAlerts,
  generateDelayAlerts,
  DEFAULT_DELAY_ALERT_THRESHOLD_MINUTES,
} from '../engine/alertGenerator.js';
import { simulateRailwayState } from '../engine/index.js';
import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';

// ---------------------------------------------------------------------
// Pure unit tests against engine/alertGenerator.js
// ---------------------------------------------------------------------

// 1. No conflicts -> no conflict alert -----------------------------------
test('generateConflictAlerts([]) produces no alerts', () => {
  assert.deepEqual(generateConflictAlerts([]), []);
});

test('generateAlerts with no conflicts and no delays produces an empty array', () => {
  const alerts = generateAlerts({
    conflicts: [],
    propagatedDelays: { delaysByTrain: {}, perConflict: [] },
  });
  assert.deepEqual(alerts, []);
});

// 2. Conflict -> alert generated ------------------------------------------
test('a single detected conflict produces exactly one conflict alert', () => {
  const conflict = {
    resourceId: 'R9',
    trainIds: ['T2', 'T1'],
    startTime: '10:00',
    endTime: '10:05',
    severity: 'capacity',
    reason: 'resource capacity is 1 but T1 and T2 overlap on it',
  };
  const alerts = generateConflictAlerts([conflict]);
  assert.equal(alerts.length, 1);
  assert.equal(alerts[0].type, 'conflict');
});

test('a headway conflict is generated with warning severity, a capacity conflict with critical severity', () => {
  const capacityConflict = { resourceId: 'R1', trainIds: ['A', 'B'], severity: 'capacity' };
  const headwayConflict = { resourceId: 'R1', trainIds: ['C', 'D'], severity: 'headway' };

  const [capacityAlert] = generateConflictAlerts([capacityConflict]);
  const [headwayAlert] = generateConflictAlerts([headwayConflict]);

  assert.equal(capacityAlert.severity, 'critical');
  assert.equal(headwayAlert.severity, 'warning');
});

// 3. Delay propagation -> delay alert when threshold met -------------------
test('a propagated delay below the threshold produces no delay alert', () => {
  const belowThreshold = DEFAULT_DELAY_ALERT_THRESHOLD_MINUTES - 1;
  const alerts = generateDelayAlerts({
    delaysByTrain: { T1: belowThreshold },
    perConflict: [],
  });
  assert.deepEqual(alerts, []);
});

test('a propagated delay at/above the threshold produces a delay alert', () => {
  const alerts = generateDelayAlerts({
    delaysByTrain: { T1: DEFAULT_DELAY_ALERT_THRESHOLD_MINUTES },
    perConflict: [],
  });
  assert.equal(alerts.length, 1);
  assert.equal(alerts[0].type, 'delay');
  assert.equal(alerts[0].trainIds[0], 'T1');
});

test('a very large propagated delay is escalated to critical severity', () => {
  const [alert] = generateDelayAlerts({
    delaysByTrain: { T1: 30 },
    perConflict: [],
  });
  assert.equal(alert.severity, 'critical');
});

// 4. Alert contains relevant train/resource information --------------------
test('conflict alerts carry the conflicting trainIds and resourceId', () => {
  const conflict = { resourceId: 'J1', trainIds: ['12601', '12602'], severity: 'headway' };
  const [alert] = generateConflictAlerts([conflict]);
  assert.deepEqual([...alert.trainIds].sort(), ['12601', '12602']);
  assert.equal(alert.resourceId, 'J1');
  assert.ok(alert.message.includes('12601'));
  assert.ok(alert.message.includes('12602'));
  assert.ok(alert.message.includes('J1'));
});

test('delay alerts carry the delayed trainId and, when known, the responsible resourceId', () => {
  const alerts = generateDelayAlerts({
    delaysByTrain: { T1: 10 },
    perConflict: [
      { delayedTrainId: 'T1', resourceId: 'P3', additionalDelayMinutes: 10 },
    ],
  });
  assert.equal(alerts[0].trainIds[0], 'T1');
  assert.equal(alerts[0].resourceId, 'P3');
});

test('delay alerts fall back to a null resourceId when no per-conflict record explains the delay', () => {
  const [alert] = generateDelayAlerts({ delaysByTrain: { T1: 10 }, perConflict: [] });
  assert.equal(alert.resourceId, null);
});

// 5. Multiple conflicts produce appropriate alerts --------------------------
test('multiple distinct conflicts each produce their own alert, with unique ids', () => {
  const conflicts = [
    { resourceId: 'J1', trainIds: ['A', 'B'], severity: 'capacity' },
    { resourceId: 'P3', trainIds: ['C', 'D'], severity: 'headway' },
  ];
  const alerts = generateConflictAlerts(conflicts);
  assert.equal(alerts.length, 2);
  const ids = alerts.map((a) => a.id);
  assert.equal(new Set(ids).size, 2, 'expected unique alert ids per conflict');
});

test('generateAlerts combines conflict alerts and delay alerts together', () => {
  const alerts = generateAlerts({
    conflicts: [{ resourceId: 'J1', trainIds: ['A', 'B'], severity: 'capacity' }],
    propagatedDelays: {
      delaysByTrain: { B: 8 },
      perConflict: [{ delayedTrainId: 'B', resourceId: 'J1', additionalDelayMinutes: 8 }],
    },
  });
  assert.equal(alerts.length, 2);
  assert.ok(alerts.some((a) => a.type === 'conflict'));
  assert.ok(alerts.some((a) => a.type === 'delay'));
});

test('alertGenerator.js source contains no hardcoded train/station/resource-id branching', async () => {
  const fs = await import('node:fs');
  const { fileURLToPath } = await import('node:url');
  const sourcePath = fileURLToPath(new URL('../engine/alertGenerator.js', import.meta.url));
  const source = fs.readFileSync(sourcePath, 'utf8');

  assert.ok(!/trainId\s*===\s*['"`]/.test(source), 'found a literal trainId === "..." comparison');
  assert.ok(!/resourceId\s*===\s*['"`]/.test(source), 'found a literal resourceId === "..." comparison');
});

// ---------------------------------------------------------------------
// Integration: services/alertService.js + GET /api/alerts
// ---------------------------------------------------------------------

let server;
let baseUrl;

test.before(async () => {
  const app = createApp();
  app.use(cors());
  registerAlertRoutes(app);

  await new Promise((resolve) => {
    server = app.listen(0, resolve);
  });
  const { port } = server.address();
  baseUrl = `http://localhost:${port}`;
});

test.after(() => {
  server.close();
});

// 6. /api/alerts still returns a valid array --------------------------------
test('GET /api/alerts returns 200 with a valid alerts array', async () => {
  const res = await fetch(`${baseUrl}/api/alerts`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.ok(Array.isArray(body.alerts));
});

test('alertService.getAllAlerts() returns an array whose entries are well-formed', () => {
  const alerts = getAllAlerts();
  assert.ok(Array.isArray(alerts));
  for (const alert of alerts) {
    assert.ok('id' in alert, 'alert missing id');
    assert.ok(typeof alert.id === 'string' && alert.id.length > 0);
  }
});

test('alertService output matches what generateAlerts computes directly from the real seed engine run', () => {
  const simulationResult = simulateRailwayState({ trains: INITIAL_TRAINS, resources: RESOURCES, findTrack });
  const expectedEngineAlerts = generateAlerts(simulationResult);

  const alerts = getAllAlerts();

  if (expectedEngineAlerts.length > 0) {
    // Engine has something to report for the real seed data -> the
    // service must surface exactly that (not the static seed fallback).
    assert.deepEqual(
      alerts.map((a) => a.id).sort(),
      expectedEngineAlerts.map((a) => a.id).sort()
    );
  } else {
    // Nothing detected -> backward-compatible fallback to the seed alert.
    assert.ok(alerts.length > 0, 'expected the seed fallback when the engine reports nothing');
  }
});

test('the real seed fleet/network produces at least one engine-driven alert (conflict and/or delay)', () => {
  // Sanity check that this chunk is actually exercising the engine
  // against real data, not just trivially passing on empty input. The
  // Phase 2 Chunk 3/6 seed data is known to contain a genuine resource
  // conflict/delay.
  const simulationResult = simulateRailwayState({ trains: INITIAL_TRAINS, resources: RESOURCES, findTrack });
  const engineAlerts = generateAlerts(simulationResult);
  assert.ok(engineAlerts.length > 0, 'expected the real seed data to produce at least one engine-driven alert');
});
