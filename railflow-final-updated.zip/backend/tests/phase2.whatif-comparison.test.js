// tests/phase2.whatif-comparison.test.js
//
// Focused tests for PHASE 2 CHUNK 12B (WHAT-IF RESULT COMPARISON):
// engine/whatIfComparison.js, services/simulationService.js's
// getWhatIfComparison(), and POST /api/simulation/what-if. Does NOT
// re-test Chunk 12A's intervention validation/apply/run behavior — see
// tests/phase2.whatif.test.js for that. Uses Node's built-in test
// runner (`node --test`).

import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp, cors } from '../utils/router.js';
import { registerHealthRoutes } from '../routes/health.js';
import { registerTrainRoutes } from '../routes/trains.js';
import { registerNetworkRoutes } from '../routes/network.js';
import { registerAlertRoutes } from '../routes/alerts.js';
import { registerSimulationRoutes } from '../routes/simulation.js';
import { computeNetworkDelay, compareWhatIfResults } from '../engine/whatIfComparison.js';
import { getWhatIfComparison, getSimulationResult } from '../services/simulationService.js';
import { runWhatIfSimulation } from '../engine/whatIf.js';
import { simulateRailwayState } from '../engine/index.js';
import { INITIAL_TRAINS } from '../data/trains.js';
import { findTrack, RESOURCES } from '../data/network.js';
import { parseTime as parseTimeToMinutes } from '../engine/timeUtils.js';

// ---------------------------------------------------------------------
// Synthetic fixture, same shape as phase2.whatif.test.js's makeState():
// two trains sharing a capacity-1 resource, so an intervention has a
// real, predictable effect to compare against.
// ---------------------------------------------------------------------
function makeState() {
  const trains = [
    { id: 'TA', priority: 2, path: ['A', 'B'], scheduledDeparture: '10:00', stops: [], delay: 0 },
    { id: 'TB', priority: 1, path: ['A', 'B'], scheduledDeparture: '10:00', stops: [], delay: 0 },
  ];
  const resources = [
    { id: 'JCT-A', label: 'Junction A', stationId: 'A', type: 'junction', capacity: 1, headwaySeconds: 90 },
  ];
  const findTrackFixture = (from, to) => {
    if ((from === 'A' && to === 'B') || (from === 'B' && to === 'A')) {
      return { id: 'TRACK-A-B', travelMinutes: 20 };
    }
    return null;
  };
  return { trains, resources, findTrack: findTrackFixture };
}

function realState() {
  return { trains: INITIAL_TRAINS, resources: RESOURCES, findTrack };
}

// ===========================================================================
// engine/whatIfComparison.js — unit level
// ===========================================================================

test('computeNetworkDelay sums totalDelay across every eta', () => {
  const etas = [
    { trainId: 'TA', totalDelay: 5 },
    { trainId: 'TB', totalDelay: 0 },
    { trainId: 'TC', totalDelay: 12 },
  ];
  assert.equal(computeNetworkDelay(etas), 17);
});

test('compareWhatIfResults: changedTrains lists only trains whose predictedETA differs', () => {
  const base = {
    etas: [
      { trainId: 'TA', predictedETA: '10:20', totalDelay: 0 },
      { trainId: 'TB', predictedETA: '10:20', totalDelay: 0 },
    ],
    conflicts: [],
  };
  const whatIf = {
    etas: [
      { trainId: 'TA', predictedETA: '10:50', totalDelay: 30 },
      { trainId: 'TB', predictedETA: '10:20', totalDelay: 0 },
    ],
    conflicts: [],
  };
  const impact = compareWhatIfResults(base, whatIf);
  assert.deepEqual(impact.changedTrains, ['TA']);
});

test('compareWhatIfResults: additionalDelay is the network-delay difference (whatIf minus base)', () => {
  const base = {
    etas: [
      { trainId: 'TA', predictedETA: '10:20', totalDelay: 0 },
      { trainId: 'TB', predictedETA: '10:20', totalDelay: 0 },
    ],
    conflicts: [],
  };
  const whatIf = {
    etas: [
      { trainId: 'TA', predictedETA: '10:50', totalDelay: 30 },
      { trainId: 'TB', predictedETA: '10:25', totalDelay: 5 },
    ],
    conflicts: [],
  };
  assert.equal(compareWhatIfResults(base, whatIf).additionalDelay, 35);
});

test('compareWhatIfResults: conflictChange is conflicts(whatIf) minus conflicts(base), and can be negative', () => {
  const base = { etas: [], conflicts: [{ id: 'C1' }] };
  const whatIfMore = { etas: [], conflicts: [{ id: 'C1' }, { id: 'C2' }] };
  const whatIfFewer = { etas: [], conflicts: [] };

  assert.equal(compareWhatIfResults(base, whatIfMore).conflictChange, 1);
  assert.equal(compareWhatIfResults(base, whatIfFewer).conflictChange, -1);
});

test('compareWhatIfResults reflects a real engine run: delaying TA past its conflict with TB changes TA, clears the conflict, and still reports the requested delay as net impact', () => {
  const state = makeState();
  const baseResult = simulateRailwayState(state);
  // Base: TA and TB depart at the same time and contend for JCT-A, so TA
  // (lower precedence) picks up propagated delay and one conflict is
  // detected. Pushing TA's own departure 30 minutes later removes the
  // contention entirely (TB has long since cleared JCT-A by the time TA
  // arrives), so the conflict clears and TA's *propagated* delay
  // (`totalDelay`, engine/etaCalculator.js) drops back to zero. But TA's
  // predictedETA still moves ~30 minutes later on its new schedule, and
  // `additionalDelay` is defined against absolute predictedETA (see
  // engine/whatIfComparison.js's computeNetArrivalImpact) precisely so
  // that a self-imposed delay is never hidden just because it also
  // cleared the conflict that used to inflate `totalDelay`.
  assert.equal(baseResult.conflicts.length, 1);

  const whatIfResult = runWhatIfSimulation({ type: 'delay', trainId: 'TA', minutes: 30 }, state);
  const impact = compareWhatIfResults(baseResult, whatIfResult);

  assert.deepEqual(impact.changedTrains, ['TA']);
  assert.equal(impact.conflictChange, -1);

  // additionalDelay = change in TA's predictedETA (its requested +30 min,
  // net of the ~5.5 min of propagated conflict delay TA no longer picks
  // up) + change in TB's predictedETA (0, TB is untouched) — clearly
  // positive, reflecting the intervention's real net impact, unlike the
  // old totalDelay-based metric which could report this as negative.
  const baseTA = baseResult.etas.find((e) => e.trainId === 'TA');
  const whatIfTA = whatIfResult.etas.find((e) => e.trainId === 'TA');
  assert.ok(impact.additionalDelay > 0, 'a 30-minute self-imposed delay must show as a positive net impact');
  assert.equal(
    impact.additionalDelay,
    parseTimeToMinutes(whatIfTA.predictedETA) - parseTimeToMinutes(baseTA.predictedETA)
  );
});

test('engine/whatIfComparison.js source contains no reimplemented conflict/occupancy/propagation/ETA algorithm', async () => {
  const fs = await import('node:fs');
  const { fileURLToPath } = await import('node:url');
  const sourcePath = fileURLToPath(new URL('../engine/whatIfComparison.js', import.meta.url));
  const source = fs.readFileSync(sourcePath, 'utf8');

  assert.ok(!/function\s+detectConflicts/.test(source));
  assert.ok(!/function\s+computeResourceOccupancy/.test(source));
  assert.ok(!/function\s+computeConflictDelays/.test(source));
  assert.ok(!/function\s+computeFleetETAs/.test(source));
  assert.ok(!/function\s+generateAllEvents/.test(source));
});

// ===========================================================================
// services/simulationService.js — getWhatIfComparison(), unit level
// ===========================================================================

test('getWhatIfComparison returns the required top-level shape', () => {
  const trainId = INITIAL_TRAINS[0].id;
  const result = getWhatIfComparison({ type: 'delay', trainId, minutes: 15 });

  assert.ok('intervention' in result);
  assert.ok('base' in result);
  assert.ok('whatIf' in result);
  assert.ok('impact' in result);

  for (const side of [result.base, result.whatIf]) {
    assert.ok(Array.isArray(side.etas));
    assert.ok(Array.isArray(side.conflicts));
    assert.equal(typeof side.networkDelay, 'number');
  }

  assert.ok(Array.isArray(result.impact.changedTrains));
  assert.equal(typeof result.impact.additionalDelay, 'number');
  assert.equal(typeof result.impact.conflictChange, 'number');
});

test('getWhatIfComparison.base matches the real current getSimulationResult() etas/conflicts', () => {
  const trainId = INITIAL_TRAINS[0].id;
  const result = getWhatIfComparison({ type: 'delay', trainId, minutes: 15 });
  const currentSimulation = getSimulationResult();

  assert.deepEqual(result.base.etas, currentSimulation.etas);
  assert.deepEqual(result.base.conflicts, currentSimulation.conflicts);
});

test('getWhatIfComparison.whatIf matches runWhatIfSimulation() run directly on the same state', () => {
  const trainId = INITIAL_TRAINS[1].id;
  const intervention = { type: 'hold', trainId, minutes: 20 };
  const result = getWhatIfComparison(intervention);

  const direct = runWhatIfSimulation(intervention, realState());

  assert.deepEqual(result.whatIf.etas, direct.etas);
  assert.deepEqual(result.whatIf.conflicts, direct.conflicts);
});

test('getWhatIfComparison never mutates the real base railway state (INITIAL_TRAINS)', () => {
  const before = structuredClone(INITIAL_TRAINS);
  getWhatIfComparison({ type: 'priority', trainId: INITIAL_TRAINS[2].id, priority: 1 });
  assert.deepEqual(INITIAL_TRAINS, before);
});

test('getWhatIfComparison propagates InvalidInterventionError for bad input (existing Chunk 12A validation still runs)', async () => {
  const { InvalidInterventionError } = await import('../engine/whatIf.js');
  assert.throws(() => getWhatIfComparison({ type: 'reroute', trainId: 'NOT-REAL' }), InvalidInterventionError);
});

// PHASE 2 CHUNK 19 FIX — a 'delay' intervention's requested minutes must
// show up in the reported network-delay change: whatIf.networkDelay is
// always base.networkDelay + impact.additionalDelay, and for a train
// with no conflicts to begin with, additionalDelay is at least the
// requested minutes (it can only be larger, never smaller, since the
// intervention cannot reduce a delay that didn't exist).
test('getWhatIfComparison: a delay intervention is reflected in whatIf.networkDelay, not absorbed by the new schedule', () => {
  const trainId = INITIAL_TRAINS[0].id;
  const minutes = 25;
  const result = getWhatIfComparison({ type: 'delay', trainId, minutes });

  assert.equal(result.whatIf.networkDelay, result.base.networkDelay + result.impact.additionalDelay);
  assert.ok(
    result.impact.additionalDelay >= minutes - 0.5, // allow for formatTime's minute-level rounding
    `expected the ${minutes}-minute intervention to be reflected in additionalDelay (got ${result.impact.additionalDelay})`
  );
});

// ===========================================================================
// POST /api/simulation/what-if — HTTP level
// ===========================================================================

let server;
let baseUrl;

test.before(async () => {
  const app = createApp();
  app.use(cors());
  registerHealthRoutes(app);
  registerTrainRoutes(app);
  registerNetworkRoutes(app);
  registerAlertRoutes(app);
  registerSimulationRoutes(app);

  await new Promise((resolve) => {
    server = app.listen(0, resolve);
  });
  const { port } = server.address();
  baseUrl = `http://localhost:${port}`;
});

test.after(() => {
  server.close();
});

test('POST /api/simulation/what-if returns HTTP 200 for a valid intervention', async () => {
  const trainId = INITIAL_TRAINS[0].id;
  const res = await fetch(`${baseUrl}/api/simulation/what-if`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'delay', trainId, minutes: 10 }),
  });
  assert.equal(res.status, 200);
});

test('POST /api/simulation/what-if response contains base, whatIf, and impact', async () => {
  const trainId = INITIAL_TRAINS[0].id;
  const res = await fetch(`${baseUrl}/api/simulation/what-if`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'delay', trainId, minutes: 10 }),
  });
  const body = await res.json();

  assert.ok(body.intervention);
  assert.ok(body.base && Array.isArray(body.base.etas) && Array.isArray(body.base.conflicts));
  assert.equal(typeof body.base.networkDelay, 'number');
  assert.ok(body.whatIf && Array.isArray(body.whatIf.etas) && Array.isArray(body.whatIf.conflicts));
  assert.equal(typeof body.whatIf.networkDelay, 'number');
  assert.ok(body.impact);
  assert.ok(Array.isArray(body.impact.changedTrains));
  assert.equal(typeof body.impact.additionalDelay, 'number');
  assert.equal(typeof body.impact.conflictChange, 'number');
});

test('POST /api/simulation/what-if: a delay intervention on the real fleet changes that train and matches the networkDelay difference', async () => {
  const trainId = INITIAL_TRAINS[0].id;
  const res = await fetch(`${baseUrl}/api/simulation/what-if`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'delay', trainId, minutes: 25 }),
  });
  const body = await res.json();

  assert.ok(body.impact.changedTrains.includes(trainId));
  // additionalDelay is defined as networkDelay(whatIf) - networkDelay(base) —
  // it can be negative when an intervention clears a conflict, so assert
  // the relationship itself rather than a fixed sign.
  assert.equal(body.impact.additionalDelay, body.whatIf.networkDelay - body.base.networkDelay);
});

test('POST /api/simulation/what-if returns 400 for an invalid intervention (unknown trainId)', async () => {
  const res = await fetch(`${baseUrl}/api/simulation/what-if`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'delay', trainId: 'NOT-REAL', minutes: 10 }),
  });
  assert.equal(res.status, 400);
  const body = await res.json();
  assert.ok(body.error);
});

test('POST /api/simulation/what-if returns 400 for an unsupported intervention type', async () => {
  const res = await fetch(`${baseUrl}/api/simulation/what-if`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'reroute', trainId: INITIAL_TRAINS[0].id }),
  });
  assert.equal(res.status, 400);
});

test('GET /api/simulation still works unchanged alongside the new What-If endpoint', async () => {
  const res = await fetch(`${baseUrl}/api/simulation`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.ok(Array.isArray(body.etas));
  assert.equal(body.etas.length, INITIAL_TRAINS.length);
});
