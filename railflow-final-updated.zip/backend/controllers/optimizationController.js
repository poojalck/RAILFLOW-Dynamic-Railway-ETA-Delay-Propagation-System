// controllers/optimizationController.js
//
// PHASE 2 CHUNK 13B — GET /api/optimization
//
// Matches the existing controller pattern (simulationController.js): thin
// HTTP glue only, no algorithm here.

import { getOptimizationResult } from '../services/optimizationService.js';

export function getOptimization(req, res) {
  res.json(getOptimizationResult());
}
