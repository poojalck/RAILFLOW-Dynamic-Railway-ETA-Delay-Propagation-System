import { getNetworkTopology } from '../services/networkService.js';

export function getNetwork(req, res) {
  res.json(getNetworkTopology());
}
