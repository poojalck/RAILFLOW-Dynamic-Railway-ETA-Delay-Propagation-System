import { getAllTrains, getTrainById } from '../services/trainService.js';

export function listTrains(req, res) {
  res.json({ trains: getAllTrains() });
}

export function getTrain(req, res) {
  const train = getTrainById(req.params.id);
  if (!train) {
    res.status(404).json({ error: `No train with id '${req.params.id}'` });
    return;
  }
  res.json({ train });
}
