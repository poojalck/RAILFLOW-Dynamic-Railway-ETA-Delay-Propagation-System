import { getAllAlerts } from '../services/alertService.js';

export function listAlerts(req, res) {
  res.json({ alerts: getAllAlerts() });
}
