import { getSimulationResult, getWhatIfComparison, getOptimizationRun } from '../services/simulationService.js';
import { InvalidInterventionError } from '../engine/whatIf.js';

export function getSimulation(req, res) {
  res.json(getSimulationResult());
}

// PHASE 2 CHUNK 12B — POST /api/simulation/what-if
export function postWhatIf(req, res) {
  try {
    const intervention = req.body || {};
    res.json(getWhatIfComparison(intervention));
  } catch (err) {
    if (err instanceof InvalidInterventionError) {
      res.status(400).json({ error: err.message });
      return;
    }
    throw err;
  }
}

// PHASE 2 CHUNK 14 — POST /api/simulation/optimize
export function postOptimize(req, res) {
  const body = req.body || {};

  if (body.candidates !== undefined && !Array.isArray(body.candidates)) {
    res.status(400).json({ error: 'candidates must be an array of intervention objects' });
    return;
  }

  try {
    res.json(getOptimizationRun(body.candidates));
  } catch (err) {
    if (err instanceof InvalidInterventionError) {
      res.status(400).json({ error: err.message });
      return;
    }
    throw err;
  }
}
