export function getHealth(req, res) {
  res.json({
    status: 'ok',
    service: 'railflow-backend',
    phase: 1,
    timestamp: new Date().toISOString(),
  });
}
