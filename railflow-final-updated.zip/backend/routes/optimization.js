import { getOptimization } from '../controllers/optimizationController.js';

export function registerOptimizationRoutes(app) {
  app.get('/api/optimization', getOptimization);
}
