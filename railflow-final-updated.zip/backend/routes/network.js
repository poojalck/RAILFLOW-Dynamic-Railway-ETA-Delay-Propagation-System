import { getNetwork } from '../controllers/networkController.js';

export function registerNetworkRoutes(app) {
  app.get('/api/network', getNetwork);
}
