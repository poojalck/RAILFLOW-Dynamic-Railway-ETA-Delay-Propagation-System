import { getHealth } from '../controllers/healthController.js';

export function registerHealthRoutes(app) {
  app.get('/api/health', getHealth);
}
