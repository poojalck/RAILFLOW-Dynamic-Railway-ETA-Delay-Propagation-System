import { listTrains, getTrain } from '../controllers/trainController.js';

export function registerTrainRoutes(app) {
  app.get('/api/trains', listTrains);
  app.get('/api/trains/:id', getTrain);
}
