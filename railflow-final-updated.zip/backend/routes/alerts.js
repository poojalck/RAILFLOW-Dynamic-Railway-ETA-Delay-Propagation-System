import { listAlerts } from '../controllers/alertController.js';

export function registerAlertRoutes(app) {
  app.get('/api/alerts', listAlerts);
}
