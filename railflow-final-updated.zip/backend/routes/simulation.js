import { getSimulation, postWhatIf, postOptimize } from '../controllers/simulationController.js';

export function registerSimulationRoutes(app) {
  app.get('/api/simulation', getSimulation);
  app.post('/api/simulation/what-if', postWhatIf);
  app.post('/api/simulation/optimize', postOptimize);
}
