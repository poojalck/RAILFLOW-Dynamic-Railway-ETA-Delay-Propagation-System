// data/trains.js
//
// Static train fleet — ported 1:1 from the frontend's src/data/mockTrains.js
// (same ids, routeLabel, path, scheduledETA) so the existing UI components
// keep receiving the exact fields they already render.
//
// PHASE 1 note: `delay`/`status`/`predictedETA` below are still just the
// original illustrative seed values. From Phase 2 onward these become
// *derived* fields, computed by the engine from the timetable + resource
// occupancy model, not hand-set numbers.
//
// PHASE 2 CHUNK 1 additions — schedule input for the engine:
//
//   `scheduledDeparture` — "HH:MM" departure time from the FIRST station
//   in `path`. This is the single source of truth the event-generation
//   engine (backend/engine/eventGenerator.js) walks forward from; it does
//   not read `scheduledETA`/`predictedETA` at all.
//
//   `stops` — the subset of intermediate stations (i.e. stations in
//   `path` that are neither the first nor the last) where this train
//   actually stops, each with a `dwellMinutes`:
//
//     stops: [ { stationId: '...', dwellMinutes: 3 } ]
//
//   A station that appears in `path` but NOT in `stops` is a pass-through
//   — the train's timetable does not dwell there, it just continues onto
//   the next track leg the instant it arrives. The origin and final
//   station of `path` are never listed in `stops`; they get their own
//   dedicated `departure` / `finalArrival` events instead.
//
//   `priority` (already present below) — operational precedence, where
//   `priority 1 = highest operational precedence` (dispatched/prioritized
//   ahead of higher-numbered priorities). This chunk does NOT use
//   `priority` for anything yet — no conflict resolution exists yet.
//   It's carried on the data now so Phase 3+ conflict resolution has it
//   available without another data migration.
//
//   Scheduling authority: event/occupancy timing is derived ONLY from
//   `scheduledDeparture` + `track.travelMinutes` (from data/network.js)
//   + `stops[].dwellMinutes`. `train.speed` is NOT used for scheduling —
//   it remains a Phase 1 display/illustrative field only.

export const INITIAL_TRAINS = [
  {
    id: '12601',
    routeLabel: 'Guntur \u2192 Vijayawada \u2192 Eluru',
    path: ['GNT', 'VJA', 'ELR'],
    speed: 46,
    delay: 0,
    status: 'onTime',
    scheduledETA: '10:42',
    predictedETA: '10:42',
    priority: 2,
    scheduledDeparture: '10:08',
    stops: [{ stationId: 'VJA', dwellMinutes: 3 }],
  },
  {
    id: '12602',
    routeLabel: 'Tenali \u2192 Vijayawada \u2192 Gudivada',
    path: ['TEL', 'VJA', 'GDV'],
    speed: 38,
    delay: 7,
    status: 'delayed',
    scheduledETA: '10:42',
    predictedETA: '10:49',
    priority: 3,
    scheduledDeparture: '10:10',
    stops: [{ stationId: 'VJA', dwellMinutes: 4 }],
  },
  {
    id: '16722',
    routeLabel: 'Chirala \u2192 Bapatla \u2192 Tenali \u2192 Vijayawada',
    path: ['CLX', 'BPT', 'TEL', 'VJA'],
    speed: 34,
    delay: 4,
    status: 'atRisk',
    scheduledETA: '10:50',
    predictedETA: '10:54',
    priority: 3,
    scheduledDeparture: '10:15',
    // TEL is a pass-through on this working — only BPT gets a dwell.
    stops: [{ stationId: 'BPT', dwellMinutes: 2 }],
  },
  {
    id: '12814',
    routeLabel: 'Rajahmundry \u2192 Eluru \u2192 Vijayawada',
    path: ['RJY', 'ELR', 'VJA'],
    speed: 52,
    delay: 0,
    status: 'onTime',
    scheduledETA: '11:05',
    predictedETA: '11:05',
    priority: 1,
    scheduledDeparture: '10:35',
    stops: [{ stationId: 'ELR', dwellMinutes: 3 }],
  },
  {
    id: '12603',
    routeLabel: 'Vijayawada \u2192 Guntur',
    path: ['VJA', 'GNT'],
    speed: 58,
    delay: 0,
    status: 'onTime',
    scheduledETA: '10:58',
    predictedETA: '10:58',
    priority: 2,
    scheduledDeparture: '10:41',
    // Direct two-station run — no intermediate stations at all.
    stops: [],
  },
  {
    id: '12604',
    routeLabel: 'Vijayawada \u2192 Tenali',
    path: ['VJA', 'TEL'],
    speed: 64,
    delay: 2,
    status: 'onTime',
    scheduledETA: '11:02',
    predictedETA: '11:04',
    priority: 2,
    scheduledDeparture: '10:46',
    stops: [],
  },
  {
    id: '12605',
    routeLabel: 'Machilipatnam \u2192 Vijayawada \u2192 Guntur',
    path: ['MTM', 'VJA', 'GNT'],
    speed: 40,
    delay: 0,
    status: 'onTime',
    scheduledETA: '11:10',
    predictedETA: '11:10',
    priority: 2,
    scheduledDeparture: '10:33',
    stops: [{ stationId: 'VJA', dwellMinutes: 5 }],
  },
  {
    id: '12606',
    routeLabel: 'Gudivada \u2192 Tenali \u2192 Bapatla',
    path: ['GDV', 'TEL', 'BPT'],
    speed: 30,
    delay: 5,
    status: 'delayed',
    scheduledETA: '11:15',
    predictedETA: '11:20',
    priority: 3,
    scheduledDeparture: '10:56',
    // TEL is a pass-through on this working.
    stops: [],
  },
  {
    id: '12607',
    routeLabel: 'Eluru \u2192 Vijayawada \u2192 Machilipatnam',
    path: ['ELR', 'VJA', 'MTM'],
    speed: 44,
    delay: 0,
    status: 'onTime',
    scheduledETA: '11:20',
    predictedETA: '11:20',
    priority: 2,
    scheduledDeparture: '10:48',
    stops: [{ stationId: 'VJA', dwellMinutes: 3 }],
  },
  {
    id: '12608',
    routeLabel: 'Bapatla \u2192 Tenali \u2192 Vijayawada \u2192 Eluru \u2192 Rajahmundry',
    path: ['BPT', 'TEL', 'VJA', 'ELR', 'RJY'],
    speed: 36,
    delay: 3,
    status: 'atRisk',
    scheduledETA: '11:25',
    predictedETA: '11:28',
    priority: 1,
    scheduledDeparture: '10:27',
    // TEL is a pass-through; VJA and ELR are worked stops.
    stops: [
      { stationId: 'VJA', dwellMinutes: 4 },
      { stationId: 'ELR', dwellMinutes: 2 },
    ],
  },
  {
    id: '12609',
    routeLabel: 'Vijayawada \u2192 Tenali \u2192 Bapatla \u2192 Chirala',
    path: ['VJA', 'TEL', 'BPT', 'CLX'],
    speed: 48,
    delay: 0,
    status: 'onTime',
    scheduledETA: '11:12',
    predictedETA: '11:12',
    priority: 2,
    scheduledDeparture: '10:37',
    // BPT is a pass-through on this working.
    stops: [{ stationId: 'TEL', dwellMinutes: 2 }],
  },
];

export const STATUS_META = {
  onTime: { label: 'ON TIME', color: 'signal.normal' },
  delayed: { label: 'DELAYED', color: 'signal.delay' },
  atRisk: { label: 'AT RISK', color: 'signal.warning' },
  conflict: { label: 'CONFLICT', color: 'signal.danger' },
};
