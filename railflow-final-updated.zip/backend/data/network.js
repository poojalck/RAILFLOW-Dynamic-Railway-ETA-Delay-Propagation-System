// data/network.js
//
// Static railway topology — ported 1:1 from the frontend's
// src/data/mockNetwork.js so the map keeps rendering exactly the same
// schematic. This is PHASE 1: topology only. Schedule/resource-occupancy
// data (needed for conflict detection) is added in Phase 2.

export const STATIONS = [
  { id: 'VJA', name: 'Vijayawada Jn', short: 'VJA', x: 620, y: 460, kind: 'junction', platforms: ['P1', 'P2', 'P3', 'P4'] },
  { id: 'ELR', name: 'Eluru', short: 'ELR', x: 620, y: 150, kind: 'station' },
  { id: 'RJY', name: 'Rajahmundry', short: 'RJY', x: 880, y: 30, kind: 'station' },
  { id: 'GNT', name: 'Guntur', short: 'GNT', x: 230, y: 680, kind: 'station' },
  { id: 'MTM', name: 'Machilipatnam', short: 'MTM', x: 40, y: 780, kind: 'station' },
  { id: 'TEL', name: 'Tenali Jn', short: 'TEL', x: 1010, y: 680, kind: 'station' },
  { id: 'GDV', name: 'Gudivada', short: 'GDV', x: 1240, y: 430, kind: 'station' },
  { id: 'BPT', name: 'Bapatla', short: 'BPT', x: 1010, y: 900, kind: 'station' },
  { id: 'CLX', name: 'Chirala', short: 'CLX', x: 1010, y: 1090, kind: 'station' },
];

export const STATION_MAP = STATIONS.reduce((acc, s) => {
  acc[s.id] = s;
  return acc;
}, {});

// travelMinutes: the nominal (unimpeded) running time for this leg, used
// by the earliest-feasible-time engine (Phase 4). Distances are not to
// real-world scale; minutes are chosen to give a plausible, demonstrable
// schedule (roughly 1 minute per ~25 flow-space units, rounded).
export const TRACKS = [
  { id: 'VJA-ELR', source: 'VJA', target: 'ELR', kind: 'main', curve: null, travelMinutes: 14 },
  { id: 'VJA-GNT', source: 'VJA', target: 'GNT', kind: 'main', curve: { x: 400, y: 520 }, travelMinutes: 17 },
  { id: 'VJA-TEL', source: 'VJA', target: 'TEL', kind: 'main', curve: { x: 840, y: 520 }, travelMinutes: 16 },
  { id: 'TEL-BPT', source: 'TEL', target: 'BPT', kind: 'main', curve: null, travelMinutes: 9 },
  { id: 'BPT-CLX', source: 'BPT', target: 'CLX', kind: 'branch', curve: null, travelMinutes: 8 },
  { id: 'ELR-RJY', source: 'ELR', target: 'RJY', kind: 'branch', curve: { x: 820, y: 60 }, travelMinutes: 13 },
  { id: 'VJA-MTM', source: 'VJA', target: 'MTM', kind: 'branch', curve: { x: 260, y: 560 }, travelMinutes: 15 },
  { id: 'VJA-GDV', source: 'VJA', target: 'GDV', kind: 'branch', curve: { x: 1000, y: 380 }, travelMinutes: 12 },
  { id: 'TEL-GDV', source: 'TEL', target: 'GDV', kind: 'branch', curve: { x: 1160, y: 600 }, travelMinutes: 10 },
];

export const TRACK_MAP = TRACKS.reduce((acc, t) => {
  acc[`${t.source}|${t.target}`] = t;
  acc[`${t.target}|${t.source}`] = t;
  return acc;
}, {});

export function findTrack(fromId, toId) {
  return TRACK_MAP[`${fromId}|${toId}`] || null;
}

// Constrained, shared infrastructure resources. `capacity` is how many
// trains may legitimately occupy the resource at once (1 = exclusive —
// a single track through a junction, a single platform face).
// `headwaySeconds` is the minimum safety separation required between one
// train releasing the resource and the next being allowed to enter it.
export const RESOURCES = [
  { id: 'J1', label: 'Junction J1', stationId: 'VJA', type: 'junction', capacity: 1, headwaySeconds: 90 },
  { id: 'P3', label: 'Platform P3', stationId: 'VJA', type: 'platform', capacity: 1, headwaySeconds: 120 },
];

export const RESOURCE_MAP = RESOURCES.reduce((acc, r) => {
  acc[r.id] = r;
  return acc;
}, {});
